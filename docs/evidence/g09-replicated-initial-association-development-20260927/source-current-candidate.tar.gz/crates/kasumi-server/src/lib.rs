//! Authenticated network adapters. All data operations delegate to kasumi-engine.
pub mod administration;
pub mod api;
mod audit_cli;
pub mod audit_destination;
pub mod auth;
pub mod authority_client;
mod authority_node_enrollment;
pub mod authority_runtime;
mod backup_cli;
mod backup_destination_installation;
pub mod cluster;
mod control_genesis;
mod data_node_enrollment;
mod installed_clients;
#[cfg(test)]
mod json_literal_tests;
pub mod lifecycle_runtime;
pub mod local_auth;
pub mod local_recovery;
pub mod logging;
pub mod mcp;
mod node_enrollment;
mod node_provision;
mod observability;
mod persistent_disk;
mod readiness;
mod readiness_probe;
mod recovery_cli;
pub mod recovery_runtime;
pub mod rpc;
pub mod runtime;
#[cfg(test)]
mod runtime_cluster_storage;
mod runtime_drain;
mod runtime_memory;
#[cfg(test)]
mod runtime_storage_fixtures;
mod runtime_worker;
mod serving_owner;
pub mod serving_runtime;
pub mod standalone;
pub mod standalone_cli;
pub mod standalone_key_backup;
mod startup_owner;
mod startup_preparation;
mod startup_resources;
pub mod tls;
pub mod tls_reload;
mod tls_tasks;

mod target_phase_runtime;
pub mod target_runtime_config;

pub mod target_journal_installation;
pub mod target_runtime;

mod control_signer_runtime;
pub mod signer_publication_runtime;
pub mod signer_runtime;
