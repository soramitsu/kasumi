//! Concrete installed Control and issuer channels. No caller-supplied signed DTO
//! can stand in for the current Control quorum observation used here.
use crate::{
    runtime::{parse_certificate_pin, read_bounded},
    serving_runtime::{CredentialSource, RuntimeLease, ServingAuthorityConfig},
};
use anyhow::{Context, Result, ensure};
use kasumi_client::{
    KasumiAuthorityPool, KasumiClientConfig, KasumiLifecyclePool, KasumiRecoveryPool,
};
use kasumi_engine::{
    InitialDispatchReservation, TargetJournal, TargetLifecycleInvocation, TargetOperation,
    TargetOperationScope, TargetRequestAdmission,
};
use kasumi_serving::{
    AuthorityTrust, ControlTrust, LifecycleBoot, LifecycleGate, NodeIdentity, VerifiedControlIntent,
};
use kasumi_types::{
    Action, LifecyclePhase, RecoveryPhaseRequest, RequestContext, TargetInitialDispatchIdentity,
    TargetRuntimeRequest,
};
#[cfg(test)]
use std::sync::atomic::{AtomicU64, Ordering};
use std::{sync::Arc, time::Duration};
use tokio::sync::Mutex as AsyncMutex;
use uuid::Uuid;
use zeroize::Zeroizing;

/// Fresh installed-Control authorization for one still-unresolved exact
/// initial packet. Retained rows and caller-supplied originals are not inputs.
#[allow(clippy::too_many_arguments)]
pub(crate) async fn observe_initial_dispatch_from_control(
    configured: &super::target_runtime_config::TargetRecoveryConfig,
    reader_context: &RequestContext,
    reader_bearer: &Zeroizing<String>,
    request: &TargetRuntimeRequest,
    identity: &TargetInitialDispatchIdentity,
    target_incarnation: Uuid,
    admission: &TargetRequestAdmission,
    #[cfg(test)] marked_read_count: &AtomicU64,
) -> Result<(VerifiedControlIntent, kasumi_types::RecoveryPhaseRecord)> {
    admission.require_context(reader_context)?;
    reader_context.authorization.check_live()?;
    reader_context
        .authorization
        .require_control(&configured.control_root.control_incarnation.to_string())?;
    ensure!(
        reader_context.tenant == "__kasumi_control"
            && reader_context.scopes.contains(&Action::Admin),
        "current installed Control Admin required"
    );
    identity.validate_for(configured.node.node_id, request)?;

    let connections = configured.control_connections()?;
    let trust = ControlTrust::install(configured.control_root.clone())?;
    let credential = reader_bearer.clone();
    let mut control = KasumiLifecyclePool::new(
        connections.clone(),
        trust,
        Arc::new(move || Ok(credential.clone())),
    )?;
    let original = admission
        .run(async {
            Ok(control
                .observe_intent(request.command_id, admission.remaining_response()?)
                .await?)
        })
        .await?;
    let intent = &original.observation().intent;
    ensure!(
        intent.request.target_incarnation == target_incarnation
            && intent.request.tenant == request.tenant,
        "historical target generation differs from signed Control intent"
    );
    let committed_node = intent
        .request
        .target_nodes
        .get(&configured.node.node_id)
        .context("historical target node absent from signed Control intent")?;
    ensure!(
        committed_node.node_id == configured.node.node_id
            && committed_node.verifier == configured.node.verifier
            && committed_node.principal == configured.node.principal
            && committed_node.certificate_sha256 == configured.node.certificate_sha256,
        "historical signed Control intent differs from installed target"
    );

    let credential = reader_bearer.clone();
    let mut recovery =
        KasumiRecoveryPool::new(connections, Arc::new(move || Ok(credential.clone())))?;
    let marked = admission
        .run(async {
            Ok(recovery
                .read_phase(
                    &RecoveryPhaseRequest {
                        operation_id: identity.operation_id,
                        phase_id: identity.phase_id,
                    },
                    admission.remaining_response()?,
                )
                .await?)
        })
        .await?;
    identity.validate_marked_phase(
        &configured.control_root,
        configured.node.node_id,
        request,
        intent,
        &marked,
    )?;
    admission.check()?;
    #[cfg(test)]
    marked_read_count.fetch_add(1, Ordering::AcqRel);
    Ok((original, marked))
}

pub(crate) struct RuntimeTargetPhase {
    scope: Arc<TargetOperationScope>,
    serving: Option<Arc<RuntimeLease>>,
    control: AsyncMutex<KasumiLifecyclePool>,
    original: VerifiedControlIntent,
    authority: AsyncMutex<KasumiAuthorityPool>,
    authority_admin: AsyncMutex<KasumiAuthorityPool>,
    boot: LifecycleBoot,
    renewal: Arc<crate::runtime_worker::RuntimeWorker>,
    drain_report: AsyncMutex<kasumi_types::drain::DrainReport>,
}
enum ObservationBudget<'a> {
    Admission(&'a TargetRequestAdmission),
    Operation(&'a TargetOperation),
    Renewal(&'a LifecycleGate),
}
impl ObservationBudget<'_> {
    fn remaining(&self) -> Result<Duration> {
        Ok(match self {
            Self::Admission(admission) => admission.remaining_response()?,
            Self::Operation(operation) => operation.remaining_response()?,
            Self::Renewal(gate) => gate.remaining()?,
        })
    }
}
impl Drop for RuntimeTargetPhase {
    fn drop(&mut self) {
        self.scope.close();
        self.renewal.close();
    }
}
impl RuntimeTargetPhase {
    pub(crate) fn seal_admission(&self) {
        self.scope.seal_admission();
    }
    pub(crate) async fn drain_detached(&self) {
        self.scope.drain_detached().await;
    }
    pub(crate) async fn shutdown(&self) -> kasumi_types::drain::DrainResult {
        use kasumi_types::drain::DrainCompletion;
        self.seal_admission();
        self.renewal.close();
        let mut report = self.drain_report.lock().await;
        let mut retained = None;
        if let Err(error) = self.renewal.drain().await {
            report.merge(&error);
            if error.completion() == DrainCompletion::Retained {
                retained = Some(error);
            }
        }
        if retained.is_some() {
            return report.outcome(retained);
        }
        // A replica's group registration survives finite operation work and
        // releases only when the replica closes. Keep both storage gates live
        // through that owned drain, including a canceled shutdown waiter.
        self.scope.drain().await;
        self.close();
        if let Some(serving) = &self.serving
            && let Err(error) = serving.shutdown().await
        {
            report.merge(&error);
            if error.completion() == DrainCompletion::Retained {
                retained = Some(error);
            }
        }
        report.outcome(retained)
    }
    pub(crate) fn close(&self) {
        self.scope.close();
        // Close both capabilities before waiting. Every original finite renewal
        // retains its owner until it completes; shutdown never grants more time.
        if let Some(serving) = &self.serving {
            serving.close();
        }
        self.renewal.close();
    }
    #[allow(clippy::too_many_arguments)]
    pub(crate) async fn acquire(
        configured: &super::target_runtime_config::TargetRecoveryConfig,
        journal: &TargetJournal,
        authority: &ServingAuthorityConfig,
        trust: AuthorityTrust,
        credential: CredentialSource,
        node_id: u64,
        original_context: RequestContext,
        original_bearer: Zeroizing<String>,
        request: &TargetRuntimeRequest,
        initial_dispatch: Option<&TargetInitialDispatchIdentity>,
        #[cfg(test)] marked_read_count: &AtomicU64,
        admission: &TargetRequestAdmission,
    ) -> Result<(Arc<Self>, Option<kasumi_engine::VerifiedInitialMembership>)> {
        admission.require_context(&original_context)?;
        original_context.authorization.check_live()?;
        original_context
            .authorization
            .require_control(&configured.control_root.control_incarnation.to_string())?;
        ensure!(
            original_context.tenant == "__kasumi_control"
                && original_context.scopes.contains(&Action::Admin),
            "current installed Control Admin required"
        );
        authority.validate()?;
        let control_connections = configured.control_connections()?;
        let recovery_connections = initial_dispatch.map(|_| control_connections.clone());
        let control_trust = ControlTrust::install(configured.control_root.clone())?;
        let original_credential = original_bearer.clone();
        let mut control = KasumiLifecyclePool::new(
            control_connections,
            control_trust,
            Arc::new(move || Ok(original_credential.clone())),
        )?;
        let original = admission
            .run(async {
                Ok(control
                    .observe_intent(request.command_id, admission.remaining_response()?)
                    .await?)
            })
            .await?;
        let intent = &original.observation().intent;
        ensure!(
            intent.original_principal == original_context.principal,
            "current invocation differs from original phase actor"
        );
        let partition = authority.manifest.partition(&intent.request.tenant)?;
        ensure!(
            authority.manifest.control_partition(partition)?
                == original.observation().authority_partition
                && authority
                    .manifest
                    .lifecycle_controls
                    .get(&intent.control_incarnation)
                    == Some(&configured.control_root.public_key),
            "phase belongs to another installed issuer"
        );
        let endpoints = &authority.endpoints[&partition];
        let tls = authority.tls.load()?;
        let node = NodeIdentity {
            node_id,
            verifier: trust.verifier_identity()?,
            principal: authority.principal.clone(),
            certificate_sha256: hex::encode(tls.certificate_pin()),
        };
        let committed_node = intent
            .request
            .target_nodes
            .get(&node_id)
            .context("target node not approved")?;
        ensure!(
            configured.node == node
                && committed_node.verifier == node.verifier
                && committed_node.principal == node.principal
                && committed_node.certificate_sha256 == node.certificate_sha256,
            "actual target TLS identity differs from committed placement"
        );
        let mut initial_start = None;
        if let Some(identity) = initial_dispatch {
            // These installed TLS endpoints are the same Control members used
            // for the signed lifecycle read. ReadPhase crosses their live
            // quorum barrier; an envelope alone never authenticates a marker.
            let original_credential = original_bearer.clone();
            let mut recovery = KasumiRecoveryPool::new(
                recovery_connections.context("installed Control recovery route absent")?,
                Arc::new(move || Ok(original_credential.clone())),
            )?;
            let marked = admission
                .run(async {
                    Ok(recovery
                        .read_phase(
                            &RecoveryPhaseRequest {
                                operation_id: identity.operation_id,
                                phase_id: identity.phase_id,
                            },
                            admission.remaining_response()?,
                        )
                        .await?)
                })
                .await?;
            identity.validate_marked_phase(
                &configured.control_root,
                node_id,
                request,
                intent,
                &marked,
            )?;
            admission.check()?;
            #[cfg(test)]
            marked_read_count.fetch_add(1, Ordering::AcqRel);
            let decision = journal.reserve_initial_dispatch(
                &configured.control_root,
                &marked,
                intent,
                request,
            )?;
            let InitialDispatchReservation::NewlyAccepted(prebind) = decision else {
                anyhow::bail!(
                    "accepted first-membership dispatch is status-only; historical resolution required"
                )
            };
            admission.check()?;
            initial_start =
                Some(prebind.verify_initial_membership(node_id, LifecyclePhase::Initialize)?);
        }
        let connections = endpoints
            .iter()
            .map(|(id, endpoint)| {
                Ok((
                    *id,
                    KasumiClientConfig {
                        endpoint: endpoint.endpoint.clone(),
                        identity: tls.clone(),
                        trusted_ca_pem: read_bounded(&authority.server_ca, 1 << 20)?,
                        server_certificate_pins: endpoint
                            .certificate_pins
                            .iter()
                            .map(|p| parse_certificate_pin(p))
                            .collect::<Result<_>>()?,
                    },
                ))
            })
            .collect::<Result<_>>()?;
        ensure!(
            trust.manifest() == &authority.manifest,
            "installed live phase verifier differs"
        );
        let path = authority.bearer_files[&partition].clone();
        let source = credential.clone();
        let mut issuer =
            KasumiAuthorityPool::new(connections, trust.clone(), Arc::new(move || source(&path)))?;
        let accepted = kasumi_serving::LifecycleAuthorityRequest::AcceptIntent(Box::new(
            original.signed().clone(),
        ));
        let admin_env = configured
            .issuer_admin_bearer_file
            .get(&authority.manifest.authority_id)
            .context("installed issuer control-admission credential missing")?;
        let path = admin_env.clone();
        let source = credential.clone();
        let mut issuer_admin = issuer
            .clone()
            .with_credential(Arc::new(move || source(&path)));
        // Give the original one-shot issuer effect more time to resolve through
        // its exact receipt. The enclosing admission still enforces the original
        // target deadline and credential lifetime; this does not replay an effect.
        admission
            .run(async {
                Ok(issuer_admin
                    .execute_lifecycle(&accepted, Duration::from_secs(15))
                    .await?)
            })
            .await?;
        let boot = LifecycleBoot::new(trust.clone(), node)?;
        // Anchored before credential acquisition and dispatch; retries construct
        // distinct attempts, never reset the deadline of an earlier response.
        let attempt = boot.begin(&original)?;
        let lease = admission
            .run(async {
                Ok(issuer
                    .acquire_lifecycle(
                        &attempt,
                        Duration::from_millis(authority.manifest.max_lease_ms.min(5000)),
                    )
                    .await?)
            })
            .await?;
        let purpose = lease.signed().claims.application_purpose;
        let gate = LifecycleGate::new(original_context, lease)?;
        let scope = TargetOperationScope::new(TargetLifecycleInvocation::from_verified(gate)?)?;
        let serving = if intent.request.phase == LifecyclePhase::StopLocal {
            None
        } else {
            let purpose = purpose.context("issuer phase has no application role")?;
            Some(
                admission
                    .run(RuntimeLease::acquire(
                        authority,
                        trust,
                        credential.clone(),
                        &intent.request.tenant,
                        intent.request.target_incarnation,
                        node_id,
                        purpose,
                    ))
                    .await?,
            )
        };
        let runtime = Arc::new(Self {
            scope,
            serving,
            control: AsyncMutex::new(control),
            original,
            authority: AsyncMutex::new(issuer),
            boot,
            authority_admin: AsyncMutex::new(issuer_admin),
            renewal: Default::default(),
            drain_report: Default::default(),
        });
        let budget = ObservationBudget::Admission(admission);
        admission.run(runtime.check_current(&budget)).await?;
        let weak = Arc::downgrade(&runtime);
        let wake = runtime.renewal.wake();
        let partition = runtime
            .boot
            .authority()
            .manifest()
            .partition(&runtime.original.observation().intent.request.tenant)?;
        runtime.boot.authority().start_background_work(
            partition,
            runtime.renewal.work(),
            async move {
                let mut failed = false;
                loop {
                    let delay = {
                        let Some(runtime) = weak.upgrade() else { break };
                        if runtime.renewal.is_closed() {
                            break;
                        }
                        let Ok(remaining) = runtime.scope.invocation().gate().remaining() else {
                            break;
                        };
                        if failed {
                            (remaining / 4).min(Duration::from_millis(100))
                        } else {
                            remaining / 3
                        }
                    };
                    tokio::select! {
                        _ = wake.notified() => {},
                        _ = tokio::time::sleep(delay) => {},
                    }
                    let Some(runtime) = weak.upgrade() else { break };
                    #[cfg(test)]
                    runtime.renewal.after_upgrade().await;
                    if runtime.renewal.is_closed() {
                        break;
                    }
                    let Ok(remaining) = runtime.scope.invocation().gate().remaining() else {
                        runtime.scope.close();
                        break;
                    };
                    failed = !matches!(
                        tokio::time::timeout(remaining, runtime.renew()).await,
                        Ok(Ok(()))
                    );
                    if runtime.scope.invocation().check().is_err() {
                        runtime.scope.close();
                        break;
                    }
                }
            },
        )?;
        admission.check()?;
        Ok((runtime, initial_start))
    }
    pub(crate) fn scope(&self) -> &Arc<TargetOperationScope> {
        &self.scope
    }
    pub(crate) fn original(&self) -> &VerifiedControlIntent {
        &self.original
    }
    pub(crate) fn original_expires_at_ms(&self) -> u64 {
        self.original
            .observation()
            .intent
            .original_credential_expires_at_ms
    }
    pub(crate) fn access(&self) -> Result<kasumi_store::StorageAccess> {
        self.scope.invocation().check()?;
        kasumi_store::StorageAccess::target_phase(
            self.serving
                .as_ref()
                .context("cleanup cannot open target payload")?
                .gate()
                .clone(),
            self.scope.invocation().gate().clone(),
        )
    }
    /// This live check uses the exact installed Control route and original
    /// credential, not a historical signature or a renewable node lease alone.
    async fn check_current(&self, budget: &ObservationBudget<'_>) -> Result<()> {
        self.scope.invocation().check()?;
        let mut control = self.control.lock().await;
        let fresh = control
            .observe_intent(
                self.original.observation().intent.request.command_id,
                budget.remaining()?,
            )
            .await?;
        ensure!(
            fresh.observation().intent == self.original.observation().intent
                && fresh.observation().root == self.original.observation().root
                && fresh.observation().authority_partition
                    == self.original.observation().authority_partition,
            "current Control phase differs"
        );
        self.scope.invocation().check()?;
        Ok(())
    }
    pub(crate) async fn check_request(
        &self,
        admission: &TargetRequestAdmission,
        context: &RequestContext,
        bearer: &str,
    ) -> Result<()> {
        admission.require_context(context)?;
        context.authorization.require_control(
            &self
                .original
                .observation()
                .root
                .control_incarnation
                .to_string(),
        )?;
        ensure!(
            context.principal == self.original.observation().intent.original_principal
                && context.tenant == "__kasumi_control"
                && context.scopes.contains(&Action::Admin),
            "current request actor or resource differs"
        );
        let budget = ObservationBudget::Admission(admission);
        admission.run(self.check_current(&budget)).await?;
        admission.run(self.observe_with(bearer, &budget)).await?;
        admission.check()?;
        Ok(())
    }
    pub(crate) async fn check_operation(
        &self,
        operation: &TargetOperation,
        bearer: &str,
    ) -> Result<()> {
        operation.check()?;
        ensure!(
            Arc::ptr_eq(
                operation.invocation().gate(),
                self.scope.invocation().gate()
            ),
            "operation belongs to another target phase"
        );
        let budget = ObservationBudget::Operation(operation);
        operation.run(self.check_current(&budget)).await?;
        operation.run(self.observe_with(bearer, &budget)).await?;
        operation.check()
    }
    async fn observe_with(&self, bearer: &str, budget: &ObservationBudget<'_>) -> Result<()> {
        let credential = Zeroizing::new(bearer.to_owned());
        let mut control = self
            .control
            .lock()
            .await
            .clone()
            .with_credential(Arc::new(move || Ok(credential.clone())));
        let fresh = control
            .observe_intent(
                self.original.observation().intent.request.command_id,
                budget.remaining()?,
            )
            .await?;
        ensure!(
            fresh.observation().intent == self.original.observation().intent
                && fresh.observation().root == self.original.observation().root
                && fresh.observation().authority_partition
                    == self.original.observation().authority_partition,
            "fresh request Control observation differs"
        );
        Ok(())
    }
    pub(crate) async fn activation_receipt(
        &self,
        id: Uuid,
    ) -> Result<kasumi_serving::SignedAuthorityReceipt> {
        self.scope.invocation().check()?;
        let mut issuer = self.authority_admin.lock().await;
        let signed = issuer
            .receipt(
                &self.original.observation().intent.request.tenant,
                id,
                Duration::from_secs(5),
            )
            .await?
            .context("issuer activation outcome not retained")?;
        self.scope
            .invocation()
            .gate()
            .current()?
            .authority()
            .verify_activation(signed.clone())?;
        self.scope.invocation().check()?;
        Ok(signed)
    }
    pub(crate) async fn target_stop(
        &self,
        operation: &TargetOperation,
        reference: &kasumi_serving::TargetStopReference,
    ) -> Result<kasumi_serving::VerifiedTargetStop> {
        operation.check()?;
        let proof = operation
            .run(async {
                let mut issuer = self.authority_admin.lock().await;
                Ok(issuer
                    .verify_target_stop(reference, Duration::from_secs(5))
                    .await?)
            })
            .await?;
        operation.check()?;
        Ok(proof)
    }
    async fn renew(&self) -> Result<()> {
        let budget = ObservationBudget::Renewal(self.scope.invocation().gate());
        self.check_current(&budget).await?;
        let mut issuer = self.authority.lock().await;
        let attempt = self.boot.begin(&self.original)?;
        let lease = issuer
            .acquire_lifecycle(
                &attempt,
                self.scope
                    .invocation()
                    .gate()
                    .remaining()?
                    .min(Duration::from_secs(5)),
            )
            .await?;
        self.scope.invocation().gate().renew(lease)?;
        Ok(())
    }
}

/// Read the original immutable cause through installed current Control channels.
/// The active operation supplies the fresh inspection authority and deadline;
/// expired Start/Initialize caps remain historical inputs only.
pub(crate) async fn observe_initial_inspection_from_control(
    configured: &super::target_runtime_config::TargetRecoveryConfig,
    context: &RequestContext,
    bearer: &Zeroizing<String>,
    input: &kasumi_types::TargetInitialMembershipStatusInput,
    current: &VerifiedControlIntent,
    admission: &TargetRequestAdmission,
) -> Result<VerifiedControlIntent> {
    admission.require_context(context)?;
    context.authorization.check_live()?;
    context
        .authorization
        .require_control(&configured.control_root.control_incarnation.to_string())?;
    ensure!(
        context.tenant == "__kasumi_control" && context.scopes.contains(&Action::Admin),
        "initial inspection requires current installed Control Admin"
    );
    input.digest()?;
    let connections = configured.control_connections()?;
    let credential = bearer.clone();
    let mut control = KasumiLifecyclePool::new(
        connections.clone(),
        ControlTrust::install(configured.control_root.clone())?,
        Arc::new(move || Ok(credential.clone())),
    )?;
    let verified = admission
        .run(async {
            Ok(control
                .observe_intent(
                    current.observation().intent.request.command_id,
                    admission.remaining_response()?,
                )
                .await?)
        })
        .await?;
    ensure!(
        verified.observation().root == configured.control_root
            && verified.observation().intent == current.observation().intent
            && verified.observation().intent.request.phase
                == LifecyclePhase::InspectInitialMembership
            && verified.observation().intent.request.phase_input_sha256 == input.digest()?,
        "initial inspection current lifecycle differs from authenticated Control read"
    );
    let node = input
        .original_intent
        .request
        .target_nodes
        .get(&configured.node.node_id)
        .context("initial inspection original target node absent")?;
    ensure!(
        node.node_id == configured.node.node_id
            && node.verifier == configured.node.verifier
            && node.principal == configured.node.principal
            && node.certificate_sha256 == configured.node.certificate_sha256,
        "initial inspection original installed node differs"
    );
    let credential = bearer.clone();
    let mut recovery =
        KasumiRecoveryPool::new(connections, Arc::new(move || Ok(credential.clone())))?;
    for expected in input
        .starts
        .values()
        .chain(std::iter::once(&input.initialize))
    {
        let current = admission
            .run(async {
                Ok(recovery
                    .read_phase(
                        &RecoveryPhaseRequest {
                            operation_id: expected.operation_id,
                            phase_id: expected.phase_id,
                        },
                        admission.remaining_response()?,
                    )
                    .await?)
            })
            .await?;
        ensure!(
            &current == expected,
            "initial inspection original phase differs from current Control read"
        );
    }
    admission.check()?;
    Ok(verified)
}
