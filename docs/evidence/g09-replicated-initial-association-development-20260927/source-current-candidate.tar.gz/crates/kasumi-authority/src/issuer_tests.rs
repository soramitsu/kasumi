//! Reducer/lease fixtures explicitly sign immutable Control commitments. The
//! native end-to-end test separately proves actual control-quorum signing.
use super::*;
use kasumi_types::*;
use ring::signature::{Ed25519KeyPair, KeyPair};
struct ControlFixture {
    root: ControlSigningRoot,
    key: Ed25519KeyPair,
}
impl ControlFixture {
    fn new() -> Self {
        let bytes = Ed25519KeyPair::generate_pkcs8(&ring::rand::SystemRandom::new()).unwrap();
        let key = Ed25519KeyPair::from_pkcs8(bytes.as_ref()).unwrap();
        Self {
            root: ControlSigningRoot {
                control_incarnation: Uuid::new_v4(),
                public_key: hex::encode(key.public_key().as_ref()),
            },
            key,
        }
    }
    async fn issuer(&self) -> Fixture {
        Fixture::with_controls(BTreeMap::from([(
            self.root.control_incarnation,
            self.root.public_key.clone(),
        )]))
        .await
    }
    fn intent(&self, f: &Fixture, t: &RecoveryTarget, expiry: u64) -> SignedControlIntent {
        let request = CommitLifecycleIntent {
            command_id: Uuid::new_v4(),
            expected_policy_epoch: 1,
            installation_sha256: "ab".repeat(32),
            authority_partition: f.installation.manifest.control_partition(0).unwrap().key(),
            tenant: "city".into(),
            source_incarnation: Uuid::parse_str(&t.checkpoint.source_incarnation).unwrap(),
            source_authority_epoch: 1,
            target_incarnation: t.incarnation,
            checkpoint: t.checkpoint.clone(),
            target_nodes: t
                .nodes
                .iter()
                .map(|n| {
                    (
                        n.node_id,
                        LifecycleNode {
                            node_id: n.node_id,
                            verifier: n.verifier.clone(),
                            principal: n.principal.clone(),
                            certificate_sha256: n.certificate_sha256.clone(),
                            attestation_public_key: format!("{:064x}", n.node_id + 100),
                        },
                    )
                })
                .collect(),
            phase: LifecyclePhase::Materialize,
            phase_input_sha256: "cd".repeat(32),
            resume_origin: None,
        };
        let mut signed = SignedControlIntent {
            observation: ControlIntentCommitment {
                intent: LifecycleIntent {
                    control_incarnation: self.root.control_incarnation,
                    installation_generation: 1,
                    request_sha256: digest(&request).unwrap(),
                    request,
                    original_principal: "control-admin".into(),
                    original_credential_expires_at_ms: expiry,
                    accepted_at_ms: 1_000_000,
                    revision: 2,
                },
                root: self.root.clone(),
                authority_partition: f.installation.manifest.control_partition(0).unwrap(),
                partition_set_sha256: "ef".repeat(32),
                observed_policy_epoch: 1,
                observed_revision: 2,
                observed_term: 1,
            },
            signature: String::new(),
        };
        self.sign_intent(&mut signed);
        signed
    }
    fn sign_intent(&self, signed: &mut SignedControlIntent) {
        signed.signature = hex::encode(
            self.key
                .sign(
                    &serde_json::to_vec(&(
                        "kasumi.committed-control-intent.v1",
                        &signed.observation,
                    ))
                    .unwrap(),
                )
                .as_ref(),
        );
    }
    fn stop(&self, signed: &SignedControlIntent) -> SignedControlChange {
        let obs = &signed.observation;
        let observation = ControlChangeCommitment {
            root: self.root.clone(),
            stop: ControlEpochStop {
                control_incarnation: self.root.control_incarnation,
                control_policy_epoch: 1,
                installation_sha256: obs.intent.request.installation_sha256.clone(),
                installation_generation: 1,
                change_id: Uuid::new_v4(),
                change_sha256: "12".repeat(32),
                authority_partition: obs.authority_partition.clone(),
                partition_set_sha256: obs.partition_set_sha256.clone(),
            },
            accepted_revision: 3,
            observed_policy_epoch: 1,
            observed_revision: 3,
            observed_term: 1,
        };
        let signature = hex::encode(
            self.key
                .sign(
                    &serde_json::to_vec(&("kasumi.committed-control-change.v1", &observation))
                        .unwrap(),
                )
                .as_ref(),
        );
        SignedControlChange {
            observation,
            signature,
        }
    }
}
fn request(s: &SignedControlIntent) -> LifecycleAuthorityRequest {
    LifecycleAuthorityRequest::AcceptIntent(Box::new(s.clone()))
}
fn node(f: &Fixture) -> AuthenticatedNode {
    AuthenticatedNode::from_verified_transport(
        f.context("node-1"),
        nodes().first().unwrap().certificate_sha256.clone(),
    )
    .unwrap()
}
async fn prepared(f: &Fixture, service: &Arc<IndependentAuthority>) -> RecoveryTarget {
    let source = f.enroll(service).await;
    let target = target(source);
    service
        .execute(
            f.context("operator"),
            f.command(AuthorityAction::PrepareTarget {
                source_incarnation: source,
                source_epoch: 1,
                target: target.clone(),
            }),
        )
        .await
        .unwrap();
    target
}
fn inspect_control_stop_drain(
    fixture: &Fixture,
    service: &IndependentAuthority,
    witness: &str,
    expected: (u64, u64, u64),
    waiting: bool,
    result: Result<(SignedControlEpochStop, AuthorityResponseFence)>,
) -> Result<(SignedControlEpochStop, AuthorityResponseFence)> {
    let observed = service
        .drains
        .lock()
        .map(|drains| {
            drains
                .get(witness)
                .map(|drain| (drain.term, drain.started, drain.last))
        })
        .map_err(|error| error.to_string());
    let expected_witness = Some((
        expected.0,
        Duration::from_millis(expected.1),
        Duration::from_millis(expected.2),
    ));
    let expected_outcome = match (&result, waiting) {
        (Err(error), true) => {
            error.code == ErrorCode::Unavailable
                && error.message == "exact fence drain has not completed; retry the same identity"
        }
        (Ok(_), false) => true,
        _ => false,
    };
    assert!(
        observed == Ok(expected_witness) && expected_outcome,
        "control stop drain: local={} witness={witness} clock={} expected={expected_witness:?} waiting={waiting} observed={observed:?} error={:?}; members={:?}",
        service.local_node_id,
        fixture.clock.0.load(Ordering::SeqCst),
        result.as_ref().err(),
        fixture
            .services
            .iter()
            .map(|member| {
                let metrics = member.group.raft().metrics().borrow().clone();
                let access = member.group.check_access();
                format!("metrics={metrics:?}, access={access:?}")
            })
            .collect::<Vec<_>>()
    );
    result
}
#[tokio::test]
async fn control_epoch_stop_preserves_exact_identity_replay_and_restarts_full_drain() {
    let control = ControlFixture::new();
    let mut f = control.issuer().await;
    let service = f.leader().await;
    let t = prepared(&f, &service).await;
    let signed = control.intent(&f, &t, 1_050_000);
    let original = request(&signed);
    drop(service);
    let (service, accepted) = accepted_on_current_leader(&f, original.clone()).await;
    service
        .backend
        .lifecycle_receipt(&original.reference())
        .unwrap()
        .unwrap();
    let mut refresh = signed.clone();
    refresh.observation.observed_revision = 10;
    control.sign_intent(&mut refresh);
    let replay = service
        .execute_lifecycle(f.context("operator"), request(&refresh))
        .await
        .unwrap()
        .0;
    assert_eq!(
        replay.receipt.accepted_revision,
        accepted.receipt.accepted_revision
    );
    refresh.signature = "00".repeat(64);
    assert!(
        service
            .execute_lifecycle(f.context("operator"), request(&refresh))
            .await
            .is_err()
    );
    let mut changed = signed.clone();
    changed.observation.intent.original_credential_expires_at_ms += 1;
    control.sign_intent(&mut changed);
    assert_eq!(
        service
            .execute_lifecycle(f.context("operator"), request(&changed))
            .await
            .err()
            .unwrap()
            .code,
        ErrorCode::Conflict
    );
    let proof = ControlTrust::install(control.root.clone())
        .unwrap()
        .verify_intent(&signed)
        .unwrap();
    let boot = LifecycleBoot::with_clock(
        f.trust.clone(),
        nodes().first().unwrap().clone(),
        f.clock.clone(),
    )
    .unwrap();
    let attempt = boot.begin(&proof).unwrap();
    service
        .backend
        .lifecycle_lease_view(attempt.request())
        .unwrap();
    let (lease, fence) = service
        .acquire_lifecycle(node(&f), attempt.request().clone())
        .await
        .unwrap();
    let lease = attempt.verify(lease).unwrap();
    fence.release().await.unwrap();
    let stop = control.stop(&signed);
    let stopped = LifecycleAuthorityRequest::StopEpoch(Box::new(stop.clone()));
    service
        .execute_lifecycle(f.context("operator"), stopped.clone())
        .await
        .unwrap();
    assert!(fence.release().await.is_err());
    assert!(
        service
            .acquire_lifecycle(node(&f), boot.begin(&proof).unwrap().request().clone())
            .await
            .is_err()
    );
    let witness = format!("control/{}", stopped.digest().unwrap());
    let initial_term = service.term();
    assert!(
        inspect_control_stop_drain(
            &f,
            &service,
            &witness,
            (initial_term, 0, 0),
            true,
            service
                .verify_control_stop(f.context("operator"), stopped.reference())
                .await,
        )
        .is_err()
    );
    f.clock.0.store(999, Ordering::SeqCst);
    assert!(
        inspect_control_stop_drain(
            &f,
            &service,
            &witness,
            (initial_term, 0, 999),
            true,
            service
                .verify_control_stop(f.context("operator"), stopped.reference())
                .await,
        )
        .is_err()
    );
    f.clock.0.store(1000, Ordering::SeqCst);
    assert!(lease.check().is_err());
    let (drained, _) = inspect_control_stop_drain(
        &f,
        &service,
        &witness,
        (initial_term, 0, 1000),
        false,
        service
            .verify_control_stop(f.context("operator"), stopped.reference())
            .await,
    )
    .unwrap();
    verify_control_epoch_stop(&stop.observation.stop, &drained).unwrap();
    use kasumi_raft::StateMachineBackend;
    let mut snapshot = Vec::new();
    service.backend.snapshot(&mut snapshot).unwrap();
    service
        .backend
        .validate_snapshot(&mut snapshot.as_slice())
        .unwrap();
    drop(fence);
    drop(service);
    f.reopen().await;
    let service = f.leader().await;
    let restarted_term = service.term();
    assert!(
        inspect_control_stop_drain(
            &f,
            &service,
            &witness,
            (restarted_term, 1000, 1000),
            true,
            service
                .verify_control_stop(f.context("operator"), stopped.reference())
                .await,
        )
        .is_err()
    );
    f.clock.0.store(1999, Ordering::SeqCst);
    assert!(
        inspect_control_stop_drain(
            &f,
            &service,
            &witness,
            (restarted_term, 1000, 1999),
            true,
            service
                .verify_control_stop(f.context("operator"), stopped.reference())
                .await,
        )
        .is_err()
    );
    f.clock.0.store(2000, Ordering::SeqCst);
    inspect_control_stop_drain(
        &f,
        &service,
        &witness,
        (restarted_term, 1000, 2000),
        false,
        service
            .verify_control_stop(f.context("operator"), stopped.reference())
            .await,
    )
    .unwrap();
    let retained = service
        .read_lifecycle_receipt(f.context("operator"), original.reference())
        .await
        .unwrap()
        .0
        .unwrap();
    assert_eq!(
        retained.receipt.accepted_revision,
        accepted.receipt.accepted_revision
    );
    let late = request(&control.intent(&f, &t, 1_050_000));
    let context = f.context("operator");
    let mut service = f.leader().await;
    // Raft elections use real time, independently of the fixture clock. Resolve
    // only this original intent after observed route movement, within the same
    // five-second wait and without replacing its verified authorization.
    tokio::time::timeout(Duration::from_secs(5), async {
        loop {
            for member in &f.services {
                member
                    .group
                    .check_access()
                    .expect("late-intent resolution requires healthy actual Raft owners");
            }
            let before = service.group.raft().metrics().borrow().clone();
            let result = service
                .execute_lifecycle(context.clone(), late.clone())
                .await;
            for member in &f.services {
                member
                    .group
                    .check_access()
                    .expect("late-intent resolution must not mask a failed Raft owner");
            }
            match result {
                Ok(_) => panic!("stopped control epoch accepted a new intent"),
                Err(error) if error.code == ErrorCode::Conflict => {
                    assert_eq!(error.message, "control epoch permanently stopped");
                    break;
                }
                Err(error) => {
                    let after = service.group.raft().metrics().borrow().clone();
                    assert!(
                        matches!(
                            error.code,
                            ErrorCode::Unavailable | ErrorCode::UnknownOutcome
                        ) && (after.current_term != before.current_term
                            || after.current_leader != before.current_leader
                            || after.state != before.state),
                        "late-intent failure without observed route movement: \
                         error={error:?}; before={before:?}; after={after:?}"
                    );
                }
            }
            service = f.leader().await;
        }
    })
    .await
    .expect("exact stopped-epoch rejection was not resolved within five seconds");
    f.close().await;
}
#[tokio::test]
async fn control_stop_before_intent_and_reserved_capacity_defeat_late_publication() {
    let c = ControlFixture::new();
    let f = Fixture::with_control_capacity(
        BTreeMap::from([(c.root.control_incarnation, c.root.public_key.clone())]),
        (256 << 10) + 16_000,
    )
    .await;
    let service = f.leader().await;
    let signed = c.intent(&f, &target(Uuid::new_v4()), 1_050_000);
    service
        .execute_lifecycle(f.context("operator"), request(&signed))
        .await
        .unwrap();
    let mut exhausted = false;
    for _ in 0..30 {
        match service
            .execute_lifecycle(
                f.context("operator"),
                request(&c.intent(&f, &target(Uuid::new_v4()), 1_050_000)),
            )
            .await
        {
            Ok(_) => {}
            Err(error) => {
                assert_eq!(error.code, ErrorCode::ResourceExhausted);
                exhausted = true;
                break;
            }
        }
    }
    assert!(exhausted, "ordinary lifecycle byte budget must exhaust");
    let stop = LifecycleAuthorityRequest::StopEpoch(Box::new(c.stop(&signed)));
    service
        .execute_lifecycle(f.context("operator"), stop)
        .await
        .unwrap();
    f.close().await;
    let f = c.issuer().await;
    let service = f.leader().await;
    let signed = c.intent(&f, &target(Uuid::new_v4()), 1_050_000);
    service
        .execute_lifecycle(
            f.context("operator"),
            LifecycleAuthorityRequest::StopEpoch(Box::new(c.stop(&signed))),
        )
        .await
        .unwrap();
    assert_eq!(
        service
            .execute_lifecycle(f.context("operator"), request(&signed))
            .await
            .err()
            .unwrap()
            .code,
        ErrorCode::Conflict
    );
    assert!(
        service
            .read_lifecycle_receipt(f.context("operator"), request(&signed).reference())
            .await
            .unwrap()
            .0
            .is_none()
    );
    f.close().await;
}
#[tokio::test]
async fn lifecycle_original_deadline_survives_queued_acceptance_delayed_reply_and_clock_regression()
{
    let c = ControlFixture::new();
    let f = c.issuer().await;
    let service = f.leader().await;
    let t = prepared(&f, &service).await;
    let signed = c.intent(&f, &t, 1_000_500);
    let proof = ControlTrust::install(c.root.clone())
        .unwrap()
        .verify_intent(&signed)
        .unwrap();
    drop(service);
    let (service, _) = accepted_on_current_leader(&f, request(&signed)).await;
    let boot = LifecycleBoot::with_clock(
        f.trust.clone(),
        nodes().first().unwrap().clone(),
        f.clock.clone(),
    )
    .unwrap();
    let attempt = boot.begin(&proof).unwrap();
    service
        .backend
        .lifecycle_lease_view(attempt.request())
        .unwrap();
    let (response, _) = service
        .acquire_lifecycle(node(&f), attempt.request().clone())
        .await
        .unwrap();
    assert_eq!(response.claims.credential_lifetime_ms, 500);
    let held = attempt.verify(response.clone()).unwrap();
    f.clock.0.store(500, Ordering::SeqCst);
    assert!(attempt.clone().verify(response.clone()).is_err());
    assert!(held.check().is_err());
    assert!(boot.begin(&proof).unwrap().verify(response).is_err());
    assert!(
        service
            .acquire_lifecycle(node(&f), boot.begin(&proof).unwrap().request().clone())
            .await
            .is_err()
    );
    let queued = c.intent(&f, &t, 1_000_600);
    let gate = service.proposal.lock().await;
    let task = {
        let service = service.clone();
        let ctx = f.context("operator");
        let request = request(&queued);
        tokio::spawn(async move { service.execute_lifecycle(ctx, request).await })
    };
    tokio::task::yield_now().await;
    f.clock.0.store(600, Ordering::SeqCst);
    drop(gate);
    assert_eq!(
        task.await.unwrap().err().unwrap().code,
        ErrorCode::Unauthorized
    );
    assert!(
        service
            .read_lifecycle_receipt(f.context("operator"), request(&queued).reference())
            .await
            .unwrap()
            .0
            .is_none()
    );
    f.clock.0.store(400, Ordering::SeqCst);
    assert!(held.check().is_err());
    f.clock.0.store(700, Ordering::SeqCst);
    assert!(boot.begin(&proof).is_err());
    f.close().await;
}

#[tokio::test]
async fn lifecycle_byte_exhaustion_preserves_reserved_epoch_stop_and_exact_snapshot_history() {
    let c = ControlFixture::new();
    let f = Fixture::with_control_capacity(
        BTreeMap::from([(c.root.control_incarnation, c.root.public_key.clone())]),
        (256 << 10) + 16000,
    )
    .await;
    let service = f.leader().await;
    let t = target(Uuid::new_v4());
    let first = c.intent(&f, &t, 1_050_000);
    service
        .execute_lifecycle(f.context("operator"), request(&first))
        .await
        .unwrap();
    let mut exhausted = false;
    for _ in 0..20 {
        let next = c.intent(&f, &t, 1_050_000);
        match service
            .execute_lifecycle(f.context("operator"), request(&next))
            .await
        {
            Ok(_) => {}
            Err(error) => {
                assert_eq!(error.code, ErrorCode::ResourceExhausted);
                exhausted = true;
                break;
            }
        }
    }
    assert!(
        exhausted,
        "small byte budget must exhaust before count quota"
    );
    let stop = LifecycleAuthorityRequest::StopEpoch(Box::new(c.stop(&first)));
    service
        .execute_lifecycle(f.context("operator"), stop.clone())
        .await
        .unwrap();
    use kasumi_raft::StateMachineBackend;
    let mut snapshot = Vec::new();
    service.backend.snapshot(&mut snapshot).unwrap();
    service
        .backend
        .validate_snapshot(&mut snapshot.as_slice())
        .unwrap();
    let key = stop.reference().key().unwrap();
    let modified = crate::state::snapshot::rewrite_for_test(&snapshot, |value| {
        if value["type"] == "Entry" && value["value"][0] == key {
            value["value"][1]["record"]["original_principal"] =
                serde_json::json!("substituted-admin");
        }
    });
    assert!(
        service
            .backend
            .prepare_restore(
                &crate::state::restore_test_context(&modified),
                &mut modified.as_slice()
            )
            .is_err()
    );
    let context = f.context("operator");
    let reference = stop.reference();
    // Snapshot validation can span an election under the concurrent workspace
    // suite. Read the same permanent receipt through the current leader using
    // the original credential, rather than requiring the earlier leader to stay.
    let retained = tokio::time::timeout(Duration::from_secs(20), async {
        loop {
            match f
                .leader()
                .await
                .read_lifecycle_receipt(context.clone(), reference.clone())
                .await
            {
                Ok((Some(receipt), fence)) => {
                    fence.check().unwrap();
                    break receipt;
                }
                Err(error) if error.code == ErrorCode::Unavailable => {
                    tokio::time::sleep(Duration::from_millis(20)).await;
                }
                other => panic!(
                    "exact retained lifecycle receipt unavailable: {:?}",
                    other.err()
                ),
            }
        }
    })
    .await
    .unwrap();
    assert_eq!(retained.receipt.original_principal, "operator");
    f.close().await;
}

// Test helper for initial setup, not production retry policy. Preserve the
// original verified invocation and permanent command identity across uncertainty.
async fn accepted_on_current_leader(
    f: &Fixture,
    request: LifecycleAuthorityRequest,
) -> (Arc<IndependentAuthority>, SignedLifecycleAuthorityReceipt) {
    let context = f.context("operator");
    tokio::time::timeout(Duration::from_secs(20), async {
        loop {
            let service = f.leader().await;
            match service
                .execute_lifecycle(context.clone(), request.clone())
                .await
            {
                Ok((receipt, fence)) => {
                    if fence.release().await.is_ok() {
                        return (service, receipt);
                    }
                }
                Err(error)
                    if matches!(
                        error.code,
                        ErrorCode::Unavailable | ErrorCode::UnknownOutcome
                    ) => {}
                Err(error) => panic!("definitive setup rejection: {error:?}"),
            }
            // A retry uses the same exact original command. No absent/read error
            // is interpreted as a stop or rollback of a possibly committed result.
            tokio::time::sleep(Duration::from_millis(25)).await;
        }
    })
    .await
    .expect("bounded setup recovery did not obtain current-quorum receipt")
}

#[path = "activation_gate_tests.rs"]
mod activation_gate_tests;

#[path = "target_materialization_tests.rs"]
mod target_materialization_tests;

include!("signer_roster_tests.rs");

#[path = "control_signer_tests.rs"]
mod control_signer_tests;
