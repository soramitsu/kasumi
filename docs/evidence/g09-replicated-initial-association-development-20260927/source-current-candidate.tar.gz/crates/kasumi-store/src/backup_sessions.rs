//! Immutable authenticated full-backup session control and narrowly scoped GC.
use crate::{
    AdmittedBackupBundle, BackupDestination, BackupUpload, EncryptedBackup, KeyProvider,
    StorageAccess, TenantStore,
};
use anyhow::{Context, Result, ensure};
use kasumi_types::*;
use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};
use std::sync::Arc;
use uuid::Uuid;
#[path = "backup_sessions_fs.rs"]
pub(crate) mod filesystem;

pub const MAX_SESSION_RECORD_BYTES: usize = 64 << 10;
pub const MAX_SESSION_GC_OBJECTS: usize = 256;
/// Control records live outside the only deletable subtree.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum BackupSessionSlot {
    Intent,
    Outcome,
    Object(Uuid),
}
impl BackupSessionSlot {
    pub(crate) fn relative(self, session: Uuid) -> Result<String> {
        ensure!(!session.is_nil(), "nil backup session");
        let leaf = match self {
            Self::Intent => "intent.kasumi".to_owned(),
            Self::Outcome => "outcome.kasumi".to_owned(),
            Self::Object(id) => {
                ensure!(!id.is_nil(), "nil backup object");
                format!("objects/{id}.kasumi")
            }
        };
        Ok(format!("sessions/{session}/{leaf}"))
    }
}
/// One exact reclaimable object. S3 selectors include a version ID for both
/// object versions and delete markers; the literal `null` is a version ID.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(tag = "storage", rename_all = "snake_case", deny_unknown_fields)]
pub enum BackupSessionObject {
    File { id: Uuid },
    S3Version { id: Uuid, version_id: String },
}
impl BackupSessionObject {
    pub fn id(&self) -> Uuid {
        match self {
            Self::File { id } | Self::S3Version { id, .. } => *id,
        }
    }
}
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct BackupSessionObjectPage {
    pub objects: Vec<BackupSessionObject>,
    /// More objects were observed. A new pass always starts at the namespace head.
    pub more: bool,
}
/// A caller cannot mint cleanup authority from an untrusted wire outcome. This
/// proof follows fresh decryption and exact intent/outcome binding at destination.
#[derive(Clone)]
pub struct VerifiedBackupAbort {
    session: Uuid,
    outcome_sha256: String,
    access: StorageAccess,
    request_guard: Option<Arc<dyn Fn() -> Result<()> + Send + Sync>>,
}
impl VerifiedBackupAbort {
    pub fn session_id(&self) -> Uuid {
        self.session
    }
    /// Adds a stricter live request gate to already verified abort authority.
    /// Cloned filesystem workers retain this gate and its owned work resources.
    pub fn with_request_guard(mut self, guard: Arc<dyn Fn() -> Result<()> + Send + Sync>) -> Self {
        self.request_guard = Some(match self.request_guard.take() {
            Some(previous) => Arc::new(move || {
                previous()?;
                guard()
            }),
            None => guard,
        });
        self
    }
    pub(crate) fn check(&self) -> Result<()> {
        self.access.check()?;
        if let Some(guard) = &self.request_guard {
            guard()?;
        }
        Ok(())
    }
    pub(crate) fn matches_outcome(&self, bytes: &[u8]) -> Result<()> {
        self.check()?;
        ensure!(
            hex::encode(Sha256::digest(bytes)) == self.outcome_sha256,
            "abort publication differs before cleanup"
        );
        Ok(())
    }
}
pub struct VerifiedBackupSession {
    intent: BackupSessionIntent,
    outcome: Option<BackupSessionOutcome>,
    intent_ciphertext_sha256: String,
    outcome_ciphertext_sha256: Option<String>,
    access: StorageAccess,
    owner: Arc<TenantStore>,
    source_purpose: crate::StoragePurpose,
    intent_bytes: Vec<u8>,
    key_catalog_sha256: String,
}
impl VerifiedBackupSession {
    pub async fn encrypt_outcome(
        &self,
        value: &BackupSessionOutcome,
        provider: Arc<dyn KeyProvider>,
    ) -> Result<AdmittedBackupBundle> {
        let owner = self.owner.as_ref();
        value.validate(&self.intent, &self.intent_ciphertext_sha256)?;
        self.access.check()?;
        let bytes = serde_json::to_vec(value)?;
        ensure!(
            bytes.len() <= MAX_SESSION_RECORD_BYTES,
            "backup outcome exceeds limit"
        );
        let original =
            EncryptedBackup::from_bytes(&self.intent_bytes, MAX_SESSION_RECORD_BYTES, owner)?;
        original
            .encrypt_related(&bytes, provider, owner)
            .await?
            .to_bytes()
    }
    pub fn key_catalog_sha256(&self) -> &str {
        &self.key_catalog_sha256
    }
    pub fn source_purpose(&self) -> &crate::StoragePurpose {
        &self.source_purpose
    }
    pub fn intent(&self) -> &BackupSessionIntent {
        &self.intent
    }
    pub fn outcome(&self) -> Option<&BackupSessionOutcome> {
        self.outcome.as_ref()
    }
    pub fn intent_ciphertext_sha256(&self) -> &str {
        &self.intent_ciphertext_sha256
    }

    pub fn aborted(&self) -> Result<VerifiedBackupAbort> {
        ensure!(
            matches!(self.outcome, Some(BackupSessionOutcome::Aborted { .. })),
            "session is not permanently aborted"
        );
        Ok(VerifiedBackupAbort {
            session: self.intent.session_id,
            request_guard: None,
            access: self.access.clone(),
            outcome_sha256: self
                .outcome_ciphertext_sha256
                .clone()
                .context("abort ciphertext missing")?,
        })
    }
}
async fn decode<T: serde::de::DeserializeOwned>(
    bytes: &[u8],
    owner: &TenantStore,
    provider: Arc<dyn KeyProvider>,
) -> Result<(T, crate::StoragePurpose, u64, String)> {
    let envelope = EncryptedBackup::from_bytes(bytes, MAX_SESSION_RECORD_BYTES, owner)?;
    let contents = envelope.decrypt(owner.tenant(), provider, owner).await?;
    Ok((
        serde_json::from_slice(&contents.snapshot)?,
        envelope.source_purpose().clone(),
        contents.revision,
        contents.key_catalog_sha256,
    ))
}
pub async fn verify_backup_session(
    destination: &dyn BackupDestination,
    session: Uuid,
    owner: &Arc<TenantStore>,
    provider: Arc<dyn KeyProvider>,
) -> Result<Option<VerifiedBackupSession>> {
    owner.check_access()?;
    let tenant = owner.tenant();
    let access = owner.storage_access();
    let Some(intent_bytes) = destination
        .session_get(
            session,
            BackupSessionSlot::Intent,
            MAX_SESSION_RECORD_BYTES + crate::backup::HEADER_LIMIT + 84,
        )
        .await?
    else {
        return Ok(None);
    };
    let (intent, source_purpose, revision, key_catalog_sha256): (BackupSessionIntent, _, _, _) =
        decode(&intent_bytes, owner, provider.clone()).await?;
    intent.validate()?;
    ensure!(
        intent.revision == revision,
        "backup intent revision differs from encrypted record"
    );
    source_purpose.validate_application_identity(tenant, &intent.source_incarnation)?;
    ensure!(
        intent.session_id == session && intent.tenant == tenant,
        "backup intent identity differs"
    );
    let intent_ciphertext_sha256 = hex::encode(Sha256::digest(&intent_bytes));
    let outcome_bytes = destination
        .session_get(
            session,
            BackupSessionSlot::Outcome,
            MAX_SESSION_RECORD_BYTES + crate::backup::HEADER_LIMIT + 84,
        )
        .await?;
    let outcome = if let Some(bytes) = &outcome_bytes {
        let (outcome, purpose, revision, outcome_catalog): (BackupSessionOutcome, _, _, _) =
            decode(bytes, owner, provider).await?;
        ensure!(
            purpose == source_purpose
                && revision == intent.revision
                && outcome_catalog == key_catalog_sha256,
            "backup outcome source purpose or revision differs from intent"
        );
        outcome.validate(&intent, &intent_ciphertext_sha256)?;
        Some(outcome)
    } else {
        None
    };
    access.check()?;
    Ok(Some(VerifiedBackupSession {
        intent,
        outcome,
        access: access.clone(),
        owner: owner.clone(),
        source_purpose,
        intent_bytes,
        key_catalog_sha256,
        intent_ciphertext_sha256,
        outcome_ciphertext_sha256: outcome_bytes
            .as_ref()
            .map(|b| hex::encode(Sha256::digest(b))),
    }))
}
impl TenantStore {
    pub async fn verify_backup_session(
        self: &Arc<Self>,
        destination: &dyn BackupDestination,
        session: Uuid,
    ) -> Result<Option<VerifiedBackupSession>> {
        self.check_access()?;
        let result =
            verify_backup_session(destination, session, self, self.provider.clone()).await?;
        self.check_access()?;
        Ok(result)
    }
    pub async fn encrypt_backup_session_outcome(
        &self,
        session: &VerifiedBackupSession,
        value: &BackupSessionOutcome,
    ) -> Result<AdmittedBackupBundle> {
        self.check_access()?;
        ensure!(
            std::ptr::eq(self, session.owner.as_ref()),
            "backup session differs from installed owner"
        );
        ensure!(
            session.intent().tenant == self.tenant(),
            "backup session tenant differs"
        );
        let bytes = session
            .encrypt_outcome(value, self.provider.clone())
            .await?;
        self.check_access()?;
        Ok(bytes)
    }
    pub fn encrypt_session_record(
        &self,
        revision: u64,
        value: &impl Serialize,
    ) -> Result<AdmittedBackupBundle> {
        let bytes = serde_json::to_vec(value)?;
        ensure!(
            bytes.len() <= MAX_SESSION_RECORD_BYTES,
            "backup session record exceeds limit"
        );
        self.encrypt_backup(revision, &bytes)?.to_bytes()
    }
}

/// A bounded object graph resolves only within its durable session namespace.
/// Archive destinations retain their independent unscoped object namespace.
pub struct BackupSessionObjects<'a> {
    destination: &'a dyn BackupDestination,
    session: Uuid,
}
impl<'a> BackupSessionObjects<'a> {
    pub fn new(destination: &'a dyn BackupDestination, session: Uuid) -> Result<Self> {
        ensure!(!session.is_nil(), "nil backup session");
        Ok(Self {
            destination,
            session,
        })
    }
}
#[async_trait::async_trait]
impl BackupDestination for BackupSessionObjects<'_> {
    /// A session view shares its destination's one physical namespace and its
    /// blocking verification.
    fn namespace_binding(&self) -> Result<BackupNamespaceBinding> {
        self.destination.namespace_binding()
    }
    async fn put(&self, id: Uuid, encrypted: BackupUpload) -> Result<()> {
        self.destination
            .session_put(self.session, BackupSessionSlot::Object(id), encrypted)
            .await
    }
    async fn get(&self, id: Uuid, max_bytes: usize) -> Result<Vec<u8>> {
        self.destination
            .session_get(self.session, BackupSessionSlot::Object(id), max_bytes)
            .await?
            .context("backup session dependency missing")
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::{FilesystemBackupDestination, NodeStore, test_utils::LocalKeyProvider};
    async fn fixture(
        fixture_memory: Arc<dyn crate::NodeDiskMemoryAdmission>,
        fixture_scratch: std::sync::Arc<crate::ScratchDisk>,
    ) -> (
        tempfile::TempDir,
        Arc<TenantStore>,
        Arc<LocalKeyProvider>,
        FilesystemBackupDestination,
    ) {
        let dir = crate::test_utils::private_tempdir().unwrap();
        let keys = Arc::new(LocalKeyProvider::new([71; 32]));
        let store = TenantStore::initialize_catalog_fixture(
            NodeStore::create_new_fixture(
                dir.path().join("node"),
                crate::test_utils::NODE_STORE_ID,
                fixture_memory.clone(),
                fixture_scratch.clone(),
            )
            .unwrap(),
            "tenant".into(),
            keys.clone(),
        )
        .await
        .unwrap();
        let destination = FilesystemBackupDestination::new_fixture(
            dir.path().join("backup"),
            crate::MAX_BACKUP_BUNDLE_BYTES,
            fixture_memory.clone(),
        )
        .unwrap();
        (dir, store, keys, destination)
    }
    pub(super) async fn begin(
        destination: &dyn BackupDestination,
        store: &Arc<TenantStore>,
        keys: Arc<dyn KeyProvider>,
    ) -> VerifiedBackupSession {
        let session = Uuid::new_v4();
        let intent = BackupSessionIntent {
            session_id: session,
            tenant: "tenant".into(),
            source_incarnation: "source".into(),
            revision: 7,
            principal: "admin".into(),
            request_id: "backup-request".into(),
        };
        let bytes = store.encrypt_session_record(7, &intent).unwrap();
        destination
            .session_put(
                session,
                BackupSessionSlot::Intent,
                bytes.try_clone().unwrap().into(),
            )
            .await
            .unwrap();
        assert!(
            destination
                .session_put(session, BackupSessionSlot::Intent, bytes.into())
                .await
                .is_err()
        );
        let verified = verify_backup_session(destination, session, store, keys)
            .await
            .unwrap()
            .unwrap();
        assert_eq!(verified.intent(), &intent);
        assert!(verified.outcome().is_none());
        assert!(verified.aborted().is_err());
        verified
    }
    pub(super) async fn abort(
        destination: &dyn BackupDestination,
        store: &Arc<TenantStore>,
        keys: Arc<dyn KeyProvider>,
        session: &VerifiedBackupSession,
    ) -> VerifiedBackupAbort {
        let value = BackupSessionOutcome::Aborted {
            intent_ciphertext_sha256: session.intent_ciphertext_sha256().into(),
            session_id: session.intent().session_id,
            principal: "admin".into(),
            reason: "operator cancelled".into(),
        };
        destination
            .session_put(
                session.intent().session_id,
                BackupSessionSlot::Outcome,
                store.encrypt_session_record(7, &value).unwrap().into(),
            )
            .await
            .unwrap();
        verify_backup_session(destination, session.intent().session_id, store, keys)
            .await
            .unwrap()
            .unwrap()
            .aborted()
            .unwrap()
    }
    #[tokio::test]
    async fn filesystem_abort_cleanup_is_bounded_repeatable_and_retains_control_and_other_namespaces()
     {
        let fixture_memory = crate::test_utils::TestDiskMemory::new(256 << 20, 4096);
        let scratch_directory = crate::test_utils::private_tempdir().unwrap();
        let fixture_scratch =
            crate::ScratchDisk::fixture(scratch_directory.path(), fixture_memory.clone());
        let (dir, store, keys, destination) =
            fixture(fixture_memory.clone(), fixture_scratch.clone()).await;
        let session = begin(&destination, &store, keys.clone()).await;
        let id = session.intent().session_id;
        let shared = Uuid::new_v4();
        destination
            .put(
                shared,
                BackupUpload::received(b"independent audit archive".to_vec()),
            )
            .await
            .unwrap();
        let other = begin(&destination, &store, keys.clone()).await;
        destination
            .session_put(
                other.intent().session_id,
                BackupSessionSlot::Object(shared),
                BackupUpload::received(b"other session".to_vec()),
            )
            .await
            .unwrap();
        for object in 1..=260 {
            destination
                .session_put(
                    id,
                    BackupSessionSlot::Object(Uuid::from_u128(object)),
                    BackupUpload::received(vec![42]),
                )
                .await
                .unwrap();
        }
        let proof = abort(&destination, &store, keys.clone(), &session).await;
        let page = destination.session_objects(&proof, 256).await.unwrap();
        assert_eq!(page.objects.len(), 256);
        // A mixed or invalid page cannot partially remove its leading valid file.
        for invalid in [
            vec![
                page.objects[0].clone(),
                BackupSessionObject::S3Version {
                    id: page.objects[0].id(),
                    version_id: "null".into(),
                },
            ],
            vec![page.objects[0].clone(), page.objects[0].clone()],
            vec![
                page.objects[0].clone(),
                BackupSessionObject::File { id: Uuid::nil() },
            ],
        ] {
            assert!(destination.session_delete(&proof, &invalid).await.is_err());
        }
        let denied = proof
            .clone()
            .with_request_guard(Arc::new(|| anyhow::bail!("original request revoked")));
        assert!(destination.session_objects(&denied, 1).await.is_err());
        assert!(
            destination
                .session_delete(&denied, &page.objects)
                .await
                .is_err()
        );
        assert_eq!(
            destination
                .session_objects(&proof, 256)
                .await
                .unwrap()
                .objects,
            page.objects
        );
        assert!(page.more);
        let late_id = page.objects[0].id();
        destination
            .session_delete(&proof, &page.objects)
            .await
            .unwrap();
        // An already-admitted upload can publish after the first cleanup pass.
        destination
            .session_put(
                id,
                BackupSessionSlot::Object(late_id),
                BackupUpload::received(vec![99]),
            )
            .await
            .unwrap();
        let tail = destination.session_objects(&proof, 256).await.unwrap();
        assert_eq!(tail.objects.len(), 5);
        assert!(!tail.more);
        destination
            .session_delete(&proof, &tail.objects)
            .await
            .unwrap();
        destination
            .session_put(
                id,
                BackupSessionSlot::Object(late_id),
                BackupUpload::received(vec![88]),
            )
            .await
            .unwrap();
        let late = destination.session_objects(&proof, 256).await.unwrap();
        assert_eq!(
            late.objects,
            vec![BackupSessionObject::File { id: late_id }]
        );
        destination
            .session_delete(&proof, &late.objects)
            .await
            .unwrap();
        destination
            .session_delete(&proof, &late.objects)
            .await
            .unwrap();
        assert!(
            destination
                .session_objects(&proof, 256)
                .await
                .unwrap()
                .objects
                .is_empty()
        );
        assert!(destination.session_objects(&proof, 257).await.is_err());
        assert!(
            verify_backup_session(&destination, id, &store, keys)
                .await
                .unwrap()
                .unwrap()
                .aborted()
                .is_ok()
        );
        assert_eq!(
            destination.get(shared, 1024).await.unwrap(),
            b"independent audit archive"
        );
        assert_eq!(
            destination
                .session_get(
                    other.intent().session_id,
                    BackupSessionSlot::Object(shared),
                    1024
                )
                .await
                .unwrap()
                .unwrap(),
            b"other session"
        );
        assert!(
            dir.path()
                .join(format!("backup/sessions/{id}/intent.kasumi"))
                .is_file()
        );
        assert!(
            dir.path()
                .join(format!("backup/sessions/{id}/outcome.kasumi"))
                .is_file()
        );
    }
    #[tokio::test]
    async fn completion_excludes_abort_and_corrupt_publication_never_grants_cleanup() {
        let fixture_memory = crate::test_utils::TestDiskMemory::new(256 << 20, 4096);
        let scratch_directory = crate::test_utils::private_tempdir().unwrap();
        let fixture_scratch =
            crate::ScratchDisk::fixture(scratch_directory.path(), fixture_memory.clone());
        let (dir, store, keys, destination) =
            fixture(fixture_memory.clone(), fixture_scratch.clone()).await;
        let session = begin(&destination, &store, keys.clone()).await;
        let id = session.intent().session_id;
        let checkpoint = FullBackupCheckpoint {
            tenant: "tenant".into(),
            source_incarnation: "source".into(),
            revision: 7,
            resident_sha256: "a".repeat(64),
            backup_id: id,
            manifest_ciphertext_sha256: "b".repeat(64),
            key_lineage_digest: "c".repeat(64),
        };
        let complete = BackupSessionOutcome::Complete {
            intent_ciphertext_sha256: session.intent_ciphertext_sha256().into(),
            checkpoint,
        };
        destination
            .session_put(
                id,
                BackupSessionSlot::Outcome,
                store.encrypt_session_record(7, &complete).unwrap().into(),
            )
            .await
            .unwrap();
        let verified = verify_backup_session(&destination, id, &store, keys.clone())
            .await
            .unwrap()
            .unwrap();
        assert!(verified.aborted().is_err());
        let abort = BackupSessionOutcome::Aborted {
            intent_ciphertext_sha256: session.intent_ciphertext_sha256().into(),
            session_id: id,
            principal: "admin".into(),
            reason: "cancel".into(),
        };
        assert!(
            destination
                .session_put(
                    id,
                    BackupSessionSlot::Outcome,
                    store.encrypt_session_record(7, &abort).unwrap().into()
                )
                .await
                .is_err()
        );
        let abandoned = begin(&destination, &store, keys.clone()).await;
        let proof = self::abort(&destination, &store, keys.clone(), &abandoned).await;
        let object = Uuid::new_v4();
        destination
            .session_put(
                proof.session_id(),
                BackupSessionSlot::Object(object),
                BackupUpload::received(vec![1]),
            )
            .await
            .unwrap();
        std::fs::write(
            dir.path().join(format!(
                "backup/sessions/{}/outcome.kasumi",
                proof.session_id()
            )),
            b"corrupt",
        )
        .unwrap();
        assert!(destination.session_objects(&proof, 1).await.is_err());
        assert!(
            destination
                .session_delete(&proof, &[BackupSessionObject::File { id: object }])
                .await
                .is_err()
        );
        assert!(
            verify_backup_session(&destination, proof.session_id(), &store, keys)
                .await
                .is_err()
        );
        // Out-of-band extent corruption fences the entire physical owner;
        // another object cannot escape through a still-retained destination.
        assert!(
            destination
                .session_get(proof.session_id(), BackupSessionSlot::Object(object), 1)
                .await
                .is_err()
        );
        assert_eq!(
            std::fs::read(dir.path().join(format!(
                "backup/sessions/{}/objects/{object}.kasumi",
                proof.session_id()
            )))
            .unwrap(),
            [1]
        );
    }

    #[tokio::test]
    async fn visible_session_outcomes_require_durable_readback_before_resolution_or_cleanup() {
        let fixture_memory = crate::test_utils::TestDiskMemory::new(256 << 20, 4096);
        let scratch_directory = crate::test_utils::private_tempdir().unwrap();
        let fixture_scratch =
            crate::ScratchDisk::fixture(scratch_directory.path(), fixture_memory.clone());
        use filesystem::test_sync::{Point, fail};
        let (dir, store, keys, destination) =
            fixture(fixture_memory.clone(), fixture_scratch.clone()).await;
        for complete in [false, true] {
            for point in [Point::ReadFile, Point::ReadDirectory] {
                let session = begin(&destination, &store, keys.clone()).await;
                let id = session.intent().session_id;
                let object = Uuid::new_v4();
                destination
                    .session_put(
                        id,
                        BackupSessionSlot::Object(object),
                        BackupUpload::received(vec![42]),
                    )
                    .await
                    .unwrap();
                let outcome = if complete {
                    BackupSessionOutcome::Complete {
                        intent_ciphertext_sha256: session.intent_ciphertext_sha256().into(),
                        checkpoint: FullBackupCheckpoint {
                            tenant: "tenant".into(),
                            source_incarnation: "source".into(),
                            revision: 7,
                            resident_sha256: "a".repeat(64),
                            backup_id: id,
                            manifest_ciphertext_sha256: "b".repeat(64),
                            key_lineage_digest: "c".repeat(64),
                        },
                    }
                } else {
                    BackupSessionOutcome::Aborted {
                        intent_ciphertext_sha256: session.intent_ciphertext_sha256().into(),
                        session_id: id,
                        principal: "admin".into(),
                        reason: "cancelled publication".into(),
                    }
                };
                let directory = dir.path().join(format!("backup/sessions/{id}"));
                let reserve = directory.join("outcome.reserve");
                let reserve_identity = crate::private_files::file_identity(&reserve).unwrap();
                let reserve_length = std::fs::metadata(&reserve).unwrap().len();
                let fault = fail(
                    &directory,
                    "outcome.kasumi",
                    &[Point::PublishDirectory, point],
                )
                .unwrap();
                let bytes = store.encrypt_session_record(7, &outcome).unwrap();
                assert!(
                    destination
                        .session_put(
                            id,
                            BackupSessionSlot::Outcome,
                            bytes.try_clone().unwrap().into(),
                        )
                        .await
                        .is_err()
                );
                // The actual link exists even though its publication returned
                // failure. Visibility alone cannot produce a verified outcome.
                let published = directory.join("outcome.kasumi");
                let physical = std::fs::read(&published).unwrap();
                assert_eq!(
                    crate::private_files::file_identity(&published).unwrap(),
                    reserve_identity
                );
                assert_eq!(std::fs::metadata(&published).unwrap().len(), reserve_length);
                assert_eq!(
                    filesystem::test_sync::decode_outcome(&physical, id, bytes.len()).unwrap(),
                    bytes.as_bytes()
                );
                assert!(
                    verify_backup_session(&destination, id, &store, keys.clone())
                        .await
                        .is_err()
                );
                drop(fault);
                let verified = verify_backup_session(&destination, id, &store, keys.clone())
                    .await
                    .unwrap()
                    .unwrap();
                assert_eq!(verified.outcome(), Some(&outcome));
                assert_eq!(std::fs::read(&published).unwrap(), physical);
                assert_eq!(
                    crate::private_files::file_identity(&published).unwrap(),
                    reserve_identity
                );
                if complete {
                    assert!(verified.aborted().is_err());
                } else {
                    let proof = verified.aborted().unwrap();
                    // Every cleanup pass independently confirms the retained
                    // abort. Even an older verified proof cannot bypass failure.
                    let fault = fail(&directory, "outcome.kasumi", &[point]).unwrap();
                    assert!(destination.session_objects(&proof, 1).await.is_err());
                    assert!(
                        destination
                            .session_delete(&proof, &[BackupSessionObject::File { id: object }])
                            .await
                            .is_err()
                    );
                    assert_eq!(
                        std::fs::read(directory.join(format!("objects/{object}.kasumi"))).unwrap(),
                        [42],
                    );
                    drop(fault);
                    let page = destination.session_objects(&proof, 1).await.unwrap();
                    assert_eq!(page.objects, vec![BackupSessionObject::File { id: object }]);
                    destination
                        .session_delete(&proof, &page.objects)
                        .await
                        .unwrap();
                }
                assert!(directory.join("intent.kasumi").is_file());
                assert!(directory.join("outcome.kasumi").is_file());
                assert_eq!(
                    directory.join(format!("objects/{object}.kasumi")).is_file(),
                    complete,
                );
            }
        }
        store.shutdown().await.unwrap();
    }

    #[tokio::test]
    async fn recovered_session_root_requires_file_and_directory_sync_before_readback() {
        let fixture_memory = crate::test_utils::TestDiskMemory::new(256 << 20, 4096);
        let scratch_directory = crate::test_utils::private_tempdir().unwrap();
        let fixture_scratch =
            crate::ScratchDisk::fixture(scratch_directory.path(), fixture_memory.clone());
        use filesystem::test_sync::{Point, fail};
        let (dir, store, keys, destination) =
            fixture(fixture_memory.clone(), fixture_scratch.clone()).await;
        for point in [Point::ReadFile, Point::ReadDirectory] {
            let session = begin(&destination, &store, keys.clone()).await;
            let id = session.intent().session_id;
            let directory = dir.path().join(format!("backup/sessions/{id}/objects"));
            let name = format!("{id}.kasumi");
            let fault = fail(&directory, &name, &[Point::PublishDirectory, point]).unwrap();
            assert!(
                destination
                    .session_put(
                        id,
                        BackupSessionSlot::Object(id),
                        BackupUpload::received(vec![41]),
                    )
                    .await
                    .is_err()
            );
            assert_eq!(std::fs::read(directory.join(&name)).unwrap(), [41]);
            assert!(
                destination
                    .session_get(id, BackupSessionSlot::Object(id), 1)
                    .await
                    .is_err()
            );
            drop(fault);
            assert_eq!(
                destination
                    .session_get(id, BackupSessionSlot::Object(id), 1)
                    .await
                    .unwrap(),
                Some(vec![41]),
            );
        }
        store.shutdown().await.unwrap();
    }

    #[tokio::test]
    #[cfg(unix)]
    async fn filesystem_cleanup_rejects_directory_symlink_substitution() {
        let fixture_memory = crate::test_utils::TestDiskMemory::new(256 << 20, 4096);
        let scratch_directory = crate::test_utils::private_tempdir().unwrap();
        let fixture_scratch =
            crate::ScratchDisk::fixture(scratch_directory.path(), fixture_memory.clone());
        use std::os::unix::fs::symlink;
        let (dir, store, keys, destination) =
            fixture(fixture_memory.clone(), fixture_scratch.clone()).await;
        let session = begin(&destination, &store, keys.clone()).await;
        let proof = abort(&destination, &store, keys, &session).await;
        let object = Uuid::new_v4();
        let external = dir.path().join("unrelated");
        std::fs::create_dir(&external).unwrap();
        let external_object = external.join(format!("{object}.kasumi"));
        std::fs::write(&external_object, b"unrelated").unwrap();
        let objects = dir
            .path()
            .join(format!("backup/sessions/{}/objects", proof.session_id()));
        std::fs::remove_dir(&objects).unwrap();
        symlink(&external, &objects).unwrap();
        assert!(destination.session_objects(&proof, 1).await.is_err());
        assert!(
            destination
                .session_delete(&proof, &[BackupSessionObject::File { id: object }])
                .await
                .is_err()
        );
        assert!(
            destination
                .session_put(
                    proof.session_id(),
                    BackupSessionSlot::Object(object),
                    BackupUpload::received(vec![0])
                )
                .await
                .is_err()
        );
        assert_eq!(std::fs::read(external_object).unwrap(), b"unrelated");
    }
    #[tokio::test]
    async fn session_keeps_historical_source_purpose_separate_from_current_access() {
        let fixture_memory = crate::test_utils::TestDiskMemory::new(256 << 20, 4096);
        let scratch_directory = crate::test_utils::private_tempdir().unwrap();
        let fixture_scratch =
            crate::ScratchDisk::fixture(scratch_directory.path(), fixture_memory.clone());
        let dir = crate::test_utils::private_tempdir().unwrap();
        let keys = Arc::new(LocalKeyProvider::new([81; 32]));
        let source_incarnation = Uuid::new_v4();
        let installation = Uuid::new_v4();
        let access = StorageAccess::standalone(installation, "tenant", source_incarnation).unwrap();
        let store = TenantStore::initialize_catalog_fixture_with_access(
            NodeStore::create_new_fixture(
                dir.path().join("source"),
                crate::test_utils::NODE_STORE_ID,
                fixture_memory.clone(),
                fixture_scratch.clone(),
            )
            .unwrap(),
            "tenant".into(),
            keys.clone(),
            access.clone(),
        )
        .await
        .unwrap();
        let destination = FilesystemBackupDestination::new_fixture(
            dir.path().join("backups"),
            crate::MAX_BACKUP_BUNDLE_BYTES,
            fixture_memory.clone(),
        )
        .unwrap();
        let id = Uuid::new_v4();
        let intent = BackupSessionIntent {
            session_id: id,
            tenant: "tenant".into(),
            source_incarnation: source_incarnation.to_string(),
            revision: 7,
            principal: "admin".into(),
            request_id: "historical".into(),
        };
        destination
            .session_put(
                id,
                BackupSessionSlot::Intent,
                store.encrypt_session_record(7, &intent).unwrap().into(),
            )
            .await
            .unwrap();
        let target = StorageAccess::standalone(installation, "tenant", Uuid::new_v4()).unwrap();
        let target_store = TenantStore::initialize_catalog_fixture_with_access(
            NodeStore::create_new_fixture(
                dir.path().join("target"),
                crate::test_utils::NODE_STORE_ID,
                fixture_memory.clone(),
                fixture_scratch.clone(),
            )
            .unwrap(),
            "tenant".into(),
            keys.clone(),
            target.clone(),
        )
        .await
        .unwrap();
        let session = verify_backup_session(&destination, id, &target_store, keys.clone())
            .await
            .unwrap()
            .unwrap();
        assert_eq!(session.source_purpose(), access.purpose());
        assert_ne!(session.source_purpose(), target.purpose());
        let outcome = BackupSessionOutcome::Aborted {
            intent_ciphertext_sha256: session.intent_ciphertext_sha256().into(),
            session_id: id,
            principal: "admin".into(),
            reason: "historical cleanup".into(),
        };
        assert!(
            store
                .encrypt_backup_session_outcome(&session, &outcome)
                .await
                .is_err(),
            "a verified session cannot be resumed under a different store owner"
        );
        destination
            .session_put(
                id,
                BackupSessionSlot::Outcome,
                session
                    .encrypt_outcome(&outcome, keys.clone())
                    .await
                    .unwrap()
                    .into(),
            )
            .await
            .unwrap();
        let verified = verify_backup_session(&destination, id, &target_store, keys.clone())
            .await
            .unwrap()
            .unwrap();
        assert_eq!(verified.source_purpose(), access.purpose());
        assert!(verified.aborted().is_ok());
        let wrong = BackupSessionIntent {
            session_id: Uuid::new_v4(),
            source_incarnation: Uuid::new_v4().to_string(),
            ..intent
        };
        destination
            .session_put(
                wrong.session_id,
                BackupSessionSlot::Intent,
                store.encrypt_session_record(7, &wrong).unwrap().into(),
            )
            .await
            .unwrap();
        assert!(
            verify_backup_session(&destination, wrong.session_id, &target_store, keys)
                .await
                .is_err()
        );
    }
}
