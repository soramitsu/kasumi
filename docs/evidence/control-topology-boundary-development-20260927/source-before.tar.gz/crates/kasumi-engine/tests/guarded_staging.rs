//! Guarded stop behavior against actual encrypted Kasumi execution and restart.
use kasumi_engine::test_utils::{SnapshotFixture, snapshot_accounted_bytes};
mod common;
use kasumi_engine::{Database, SecurityAudit};
use kasumi_store::{NodeStore, TenantStorageSet, test_utils::LocalKeyProvider};
use kasumi_types::*;
use serde_json::json;
use std::{collections::BTreeSet, path::Path, sync::Arc};

fn context() -> RequestContext {
    RequestContext {
        authorization: RequestAuthorization::service_identity(),
        tenant: "guarded".into(),
        principal: "owner".into(),
        request_id: "guarded-stop".into(),
        scopes: BTreeSet::from([Action::Read, Action::Write, Action::Admin]),
    }
}
async fn open(
    physical: &common::PhysicalFixture,
    path: &Path,
    limits: Limits,
    create: bool,
) -> (Arc<Database>, Arc<SecurityAudit>, Arc<NodeStore>) {
    let node = (if create {
        physical
            .storage
            .create_new(path, kasumi_store::test_utils::NODE_STORE_ID)
    } else {
        physical
            .storage
            .open_existing(path, kasumi_store::test_utils::NODE_STORE_ID)
    })
    .unwrap();
    let audit = if create {
        common::security_audit(node.clone(), physical.storage.admission.clone()).await
    } else {
        common::existing_security_audit(node.clone(), physical.storage.admission.clone()).await
    };
    let stores = if create {
        TenantStorageSet::initialize_catalogs_fixture(
            node.clone(),
            context().tenant,
            Arc::new(LocalKeyProvider::new([0x95; 32])),
            Arc::new(LocalKeyProvider::new([0x96; 32])),
        )
        .await
    } else {
        TenantStorageSet::open_existing_fixture(
            node.clone(),
            context().tenant,
            Arc::new(LocalKeyProvider::new([0x95; 32])),
            Arc::new(LocalKeyProvider::new([0x96; 32])),
        )
        .await
    }
    .unwrap();
    let db = kasumi_engine::test_utils::open_fixture(
        stores,
        Policy {
            grants: vec![Grant {
                principal: "owner".into(),
                collection: None,
                actions: context().scopes,
            }],
            strict_read_audit: false,
        },
        limits,
        audit.clone(),
    )
    .await
    .unwrap();
    if db
        .engine()
        .generation()
        .unwrap()
        .state
        .collections
        .is_empty()
    {
        for name in ["authority", "docs", "receipts"] {
            db.administer(
                context(),
                Operation::CreateCollection(CollectionDefinition {
                    name: name.into(),
                    schema: json!({"type":"object"}),
                    indexes: vec![],
                    strict_read_audit: false,
                    retention_class: CollectionRetentionClass::Operational,
                    write_mode: if name == "receipts" {
                        CollectionWriteMode::AppendOnly
                    } else {
                        CollectionWriteMode::Mutable
                    },
                }),
            )
            .await
            .unwrap();
        }
        set_authority(&db, "initial", true).await;
    }
    (db, audit, node)
}
async fn close(db: Arc<Database>, audit: Arc<SecurityAudit>, node: Arc<NodeStore>) {
    db.shutdown().await.unwrap();
    audit.shutdown().await.unwrap();
    node.shutdown().await.unwrap();
}
async fn set_authority(db: &Database, id: &str, enabled: bool) {
    db.mutate(
        context(),
        MutationBatch {
            idempotency_key: id.into(),
            read_set: vec![],
            operations: vec![Mutation::Put {
                collection: "authority".into(),
                id: "session".into(),
                body: json!({"enabled":enabled}),
                expected: Precondition::Any,
            }],
        },
    )
    .await
    .unwrap();
}
fn admission(db: &Database, name: &str) -> Vec<ReadAssertion> {
    let current = db.engine().generation().unwrap();
    vec![
        ReadAssertion::Snapshot {
            incarnation: current.state.incarnation.clone(),
            policy_epoch: current.state.policy_epoch,
            schema_epoch: current.state.schema_epoch,
        },
        ReadAssertion::Before {
            not_after_ms: kasumi_clock::EpochClock::system()
                .unwrap()
                .now_ms()
                .unwrap()
                + 60_000,
        },
        ReadAssertion::Document {
            collection: "authority".into(),
            id: "session".into(),
            expected: ReadPrecondition::Version(
                current.state.collections["authority"].documents["session"].version,
            ),
        },
        ReadAssertion::Document {
            collection: "receipts".into(),
            id: name.into(),
            expected: ReadPrecondition::Absent,
        },
    ]
}
fn original(db: &Database, name: &str) -> (BeginStagedTransaction, StagedChunk) {
    let chunk = StagedChunk {
        read_set: admission(db, name),
        operations: ["docs", "receipts"]
            .into_iter()
            .map(|collection| Mutation::Put {
                collection: collection.into(),
                id: name.into(),
                body: json!({"exact_minor_units":"100"}),
                expected: Precondition::Absent,
            })
            .collect(),
    };
    let begin = BeginStagedTransaction {
        scope: kasumi_types::StagedTransactionScope {
            tenant: context().tenant,
            principal: context().principal,
            incarnation: db.engine().generation().unwrap().state.incarnation.clone(),
        },
        transaction_id: name.into(),
        manifest: StagedManifest::from_chunks(std::slice::from_ref(&chunk)).unwrap(),
        ttl_ms: 60_000,
    };
    (begin, chunk)
}
fn stop(db: &Database, original: &BeginStagedTransaction) -> StopStagedTransaction {
    StopStagedTransaction {
        original: original.clone(),
        admission: admission(db, &original.transaction_id),
    }
}
async fn upload(db: &Database, original: &BeginStagedTransaction, chunk: &StagedChunk) {
    db.begin_staged_transaction(context(), original.clone())
        .await
        .unwrap();
    db.append_staged_chunk(
        context(),
        AppendStagedChunk {
            transaction: original.reference().unwrap(),
            index: 0,
            chunk: chunk.clone(),
        },
    )
    .await
    .unwrap();
}

#[tokio::test]
async fn missing_stop_has_no_upload_lease_and_defeats_delayed_begin_after_encrypted_restart() {
    let directory = kasumi_store::test_utils::private_tempdir().unwrap();
    let path = directory.path().join("node.kv");
    let physical = common::PhysicalFixture::new(&path, Default::default());
    let (db, audit, node) = open(&physical, &path, Limits::default(), true).await;
    let (original, chunk) = original(&db, "missing");
    let saved = db
        .stop_staged_transaction(context(), stop(&db, &original))
        .await
        .unwrap();
    assert!(matches!(saved.outcome, StagedOutcome::Aborted { .. }));
    assert_eq!(saved.expires_at_ms, None);
    assert!(saved.received_chunks.is_empty());
    let mut invalid_wire = serde_json::to_value(&saved).unwrap();
    invalid_wire
        .as_object_mut()
        .unwrap()
        .remove("expires_at_ms");
    assert!(serde_json::from_value::<StagedTransactionStatus>(invalid_wire).is_err());
    close(db, audit, node).await;
    let (db, audit, node) = open(&physical, &path, Limits::default(), false).await;
    set_authority(&db, "fresh-current-authority", true).await;
    let recovered = db
        .stop_staged_transaction(context(), stop(&db, &original))
        .await
        .unwrap();
    assert_eq!(saved.outcome, recovered.outcome);
    assert!(
        db.begin_staged_transaction(context(), original.clone())
            .await
            .is_err()
    );
    assert!(
        db.append_staged_chunk(
            context(),
            AppendStagedChunk {
                transaction: original.reference().unwrap(),
                index: 0,
                chunk
            }
        )
        .await
        .is_err()
    );
    assert!(
        db.finalize_staged_transaction(context(), original.reference().unwrap())
            .await
            .is_err()
    );
    let mut changed = original.clone();
    changed.ttl_ms += 1;
    assert_eq!(
        db.stop_staged_transaction(context(), stop(&db, &changed))
            .await
            .unwrap_err()
            .code,
        ErrorCode::Conflict
    );
    assert!(db.get(&context(), "docs", "missing").await.is_err());
    close(db, audit, node).await;
}

#[tokio::test]
async fn upload_stop_clears_payload_and_permanent_capacity_is_checked_without_active_reservation() {
    let directory = kasumi_store::test_utils::private_tempdir().unwrap();
    let mut limits = Limits::default();
    limits.atomic.max_active_transactions = 1;
    let physical =
        common::PhysicalFixture::new(&directory.path().join("node.kv"), Default::default());
    let (db, audit, node) = open(&physical, &directory.path().join("node.kv"), limits, true).await;
    let (first, chunk) = original(&db, "uploading");
    upload(&db, &first, &chunk).await;
    let (never, _) = original(&db, "never-started");
    let absent = db
        .stop_staged_transaction(context(), stop(&db, &never))
        .await
        .unwrap();
    assert_eq!(absent.expires_at_ms, None);
    assert_eq!(
        db.engine()
            .generation()
            .unwrap()
            .state
            .active_staged_transactions
            .len(),
        1
    );
    let stopped = db
        .stop_staged_transaction(context(), stop(&db, &first))
        .await
        .unwrap();
    assert!(stopped.expires_at_ms.is_some());
    assert!(stopped.received_chunks.is_empty());
    let current = db.engine().generation().unwrap();
    assert!(current.state.active_staged_transactions.is_empty());
    assert!(current.state.staged_transactions.is_empty());
    assert_eq!(current.state.reserved_staged_terminal_bytes, 0);
    assert_eq!(current.state.staged_terminal_head.count, 2);
    let terminal_head = current.state.staged_terminal_head.clone();
    let mut limits = current.state.limits.clone();
    limits.atomic.max_permanent_staged_bytes = current.state.permanent_staged_bytes;
    drop(current);
    // Point reads authenticate the actual terminal rows and validate that their
    // payload/counters are cleared; an empty resident map alone is insufficient.
    for (original, expected) in [(&first, &stopped), (&never, &absent)] {
        let observed = db
            .staged_transaction_status(&context(), &original.reference().unwrap())
            .await
            .unwrap();
        assert_eq!(observed.transaction, original.reference().unwrap());
        assert_eq!(observed.manifest, original.manifest);
        assert_eq!(observed.outcome, expected.outcome);
        assert_eq!(observed.expires_at_ms, expected.expires_at_ms);
        assert!(observed.received_chunks.is_empty());
    }
    db.administer(context(), Operation::SetLimits(limits))
        .await
        .unwrap();
    let (third, _) = original(&db, "quota-denied");
    assert_eq!(
        db.stop_staged_transaction(context(), stop(&db, &third))
            .await
            .unwrap_err()
            .code,
        ErrorCode::QuotaExceeded
    );
    let current = db.engine().generation().unwrap();
    assert!(current.state.staged_transactions.is_empty());
    assert!(current.state.active_staged_transactions.is_empty());
    assert_eq!(current.state.reserved_staged_terminal_bytes, 0);
    assert_eq!(current.state.staged_terminal_head, terminal_head);
    drop(current);
    assert_eq!(
        db.staged_transaction_status(&context(), &third.reference().unwrap())
            .await
            .unwrap_err()
            .code,
        ErrorCode::NotFound
    );
    close(db, audit, node).await;
}

#[tokio::test]
async fn committed_original_survives_receipt_absence_admission_failure_and_fresh_resolution() {
    let directory = kasumi_store::test_utils::private_tempdir().unwrap();
    let physical =
        common::PhysicalFixture::new(&directory.path().join("node.kv"), Default::default());
    let (db, audit, node) = open(
        &physical,
        &directory.path().join("node.kv"),
        Limits::default(),
        true,
    )
    .await;
    let (original, chunk) = original(&db, "committed");
    upload(&db, &original, &chunk).await;
    let before = stop(&db, &original);
    let committed = db
        .finalize_staged_transaction(context(), original.reference().unwrap())
        .await
        .unwrap();
    assert_eq!(
        db.stop_staged_transaction(context(), before)
            .await
            .unwrap_err()
            .code,
        ErrorCode::Conflict
    );
    let receipt = db.get(&context(), "receipts", "committed").await.unwrap();
    let mut current = stop(&db, &original);
    current.admission.retain(
        |a| !matches!(a, ReadAssertion::Document { collection, .. } if collection == "receipts"),
    );
    current.admission.push(ReadAssertion::Document {
        collection: "receipts".into(),
        id: "committed".into(),
        expected: ReadPrecondition::Version(receipt.version),
    });
    let status = db
        .stop_staged_transaction(context(), current)
        .await
        .unwrap();
    assert_eq!(
        status.outcome,
        StagedOutcome::Finished {
            outcome: Ok(committed)
        }
    );
    assert_eq!(
        db.get(&context(), "docs", "committed").await.unwrap().body["exact_minor_units"],
        "100"
    );
    close(db, audit, node).await;
}

#[tokio::test]
async fn stale_authority_cannot_create_stop_and_retained_terminal_release_checks_exact_read_scope()
{
    let directory = kasumi_store::test_utils::private_tempdir().unwrap();
    let physical =
        common::PhysicalFixture::new(&directory.path().join("node.kv"), Default::default());
    let (db, audit, node) = open(
        &physical,
        &directory.path().join("node.kv"),
        Limits::default(),
        true,
    )
    .await;
    let (original, _) = original(&db, "authority");
    let stale = stop(&db, &original);
    set_authority(&db, "revoked", false).await;
    assert_eq!(
        db.stop_staged_transaction(context(), stale)
            .await
            .unwrap_err()
            .code,
        ErrorCode::Conflict
    );
    assert!(
        db.staged_transaction_status(&context(), &original.reference().unwrap())
            .await
            .is_err()
    );
    let current = stop(&db, &original);
    let stopped = db
        .stop_staged_transaction(context(), current.clone())
        .await
        .unwrap();
    let mut read_only = context();
    read_only.scopes.remove(&Action::Write);
    assert_eq!(
        db.stop_staged_transaction(read_only, current.clone())
            .await
            .unwrap_err()
            .code,
        ErrorCode::Forbidden
    );
    let mut write_only = context();
    write_only.scopes.remove(&Action::Read);
    assert_eq!(
        db.stop_staged_transaction(write_only, current)
            .await
            .unwrap_err()
            .code,
        ErrorCode::Forbidden
    );
    assert!(matches!(stopped.outcome, StagedOutcome::Aborted { .. }));
    close(db, audit, node).await;
}

#[tokio::test]
async fn final_response_fence_rechecks_authority_and_preserves_accepted_stop() {
    let directory = kasumi_store::test_utils::private_tempdir().unwrap();
    let physical =
        common::PhysicalFixture::new(&directory.path().join("node.kv"), Default::default());
    let (db, audit, node) = open(
        &physical,
        &directory.path().join("node.kv"),
        Limits::default(),
        true,
    )
    .await;
    let (original, _) = original(&db, "release");
    let request = stop(&db, &original);
    let context = context();
    let fence = db.staged_stop_response_fence(&context, &request).unwrap();
    let accepted = db
        .stop_staged_transaction(context.clone(), request)
        .await
        .unwrap();
    let encoded = serde_json::to_vec(&accepted).unwrap();
    set_authority(&db, "changed-before-encoded-release", false).await;
    assert_eq!(fence.check().unwrap_err().code, ErrorCode::Conflict);
    drop(encoded);
    drop(fence);
    let recovered = db
        .stop_staged_transaction(context, stop(&db, &original))
        .await
        .unwrap();
    assert_eq!(recovered.outcome, accepted.outcome);
    close(db, audit, node).await;
}

#[tokio::test]
async fn concurrent_original_and_stop_keep_exactly_one_permanent_outcome() {
    let directory = kasumi_store::test_utils::private_tempdir().unwrap();
    let physical =
        common::PhysicalFixture::new(&directory.path().join("node.kv"), Default::default());
    let (db, audit, node) = open(
        &physical,
        &directory.path().join("node.kv"),
        Limits::default(),
        true,
    )
    .await;
    for iteration in 0..4 {
        let name = format!("race-{iteration}");
        let (original, chunk) = original(&db, &name);
        upload(&db, &original, &chunk).await;
        let (finished, _stop_attempt) = tokio::join!(
            db.finalize_staged_transaction(context(), original.reference().unwrap()),
            db.stop_staged_transaction(context(), stop(&db, &original))
        );
        let status = db
            .staged_transaction_status(&context(), &original.reference().unwrap())
            .await
            .unwrap();
        match status.outcome {
            StagedOutcome::Finished {
                outcome: Ok(receipt),
            } => {
                assert_eq!(finished.unwrap(), receipt);
                assert!(db.get(&context(), "receipts", &name).await.is_ok());
            }
            StagedOutcome::Aborted { .. } => {
                assert!(finished.is_err());
                assert!(db.get(&context(), "receipts", &name).await.is_err());
            }
            other => panic!("unexpected terminal outcome: {other:?}"),
        }
    }
    close(db, audit, node).await;
}

#[tokio::test]
async fn malformed_fresh_admission_and_changed_manifest_cannot_accept_or_rebind_identity() {
    let directory = kasumi_store::test_utils::private_tempdir().unwrap();
    let physical =
        common::PhysicalFixture::new(&directory.path().join("node.kv"), Default::default());
    let (db, audit, node) = open(
        &physical,
        &directory.path().join("node.kv"),
        Limits::default(),
        true,
    )
    .await;
    let (original, chunk) = original(&db, "closed-input");
    let valid = stop(&db, &original);
    let mut missing_snapshot = valid.clone();
    missing_snapshot
        .admission
        .retain(|assertion| !matches!(assertion, ReadAssertion::Snapshot { .. }));
    let mut missing_deadline = valid.clone();
    missing_deadline
        .admission
        .retain(|assertion| !matches!(assertion, ReadAssertion::Before { .. }));
    let mut duplicate = valid.clone();
    duplicate.admission.push(duplicate.admission[0].clone());
    for request in [missing_snapshot, missing_deadline, duplicate] {
        assert_eq!(
            db.stop_staged_transaction(context(), request)
                .await
                .unwrap_err()
                .code,
            ErrorCode::InvalidArgument
        );
        assert!(
            db.engine()
                .generation()
                .unwrap()
                .state
                .staged_transactions
                .is_empty()
        );
    }
    let accepted = db
        .stop_staged_transaction(context(), valid.clone())
        .await
        .unwrap();
    let mut changed = valid;
    let mut changed_chunk = chunk;
    if let Mutation::Put { body, .. } = &mut changed_chunk.operations[0] {
        *body = json!({"substituted":true});
    }
    changed.original.manifest = StagedManifest::from_chunks(&[changed_chunk]).unwrap();
    assert_eq!(
        db.stop_staged_transaction(context(), changed)
            .await
            .unwrap_err()
            .code,
        ErrorCode::Conflict
    );
    assert_eq!(
        db.stop_staged_transaction(context(), stop(&db, &original))
            .await
            .unwrap()
            .outcome,
        accepted.outcome
    );
    close(db, audit, node).await;
}

#[tokio::test]
async fn stopped_resolution_preserves_original_failed_finalize() {
    let directory = kasumi_store::test_utils::private_tempdir().unwrap();
    let physical =
        common::PhysicalFixture::new(&directory.path().join("node.kv"), Default::default());
    let (db, audit, node) = open(
        &physical,
        &directory.path().join("node.kv"),
        Limits::default(),
        true,
    )
    .await;
    let (original, chunk) = original(&db, "failed-finalize");
    upload(&db, &original, &chunk).await;
    set_authority(&db, "authority-changed", false).await;
    let failure = db
        .finalize_staged_transaction(context(), original.reference().unwrap())
        .await
        .unwrap_err();
    assert_eq!(failure.code, ErrorCode::Conflict);
    let original_status = db
        .staged_transaction_status(&context(), &original.reference().unwrap())
        .await
        .unwrap();
    assert!(matches!(
        original_status.outcome,
        StagedOutcome::Finished { outcome: Err(_) }
    ));
    let resolved = db
        .stop_staged_transaction(context(), stop(&db, &original))
        .await
        .unwrap();
    assert_eq!(resolved.outcome, original_status.outcome);
    assert!(
        db.get(&context(), "receipts", "failed-finalize")
            .await
            .is_err()
    );
    close(db, audit, node).await;
}

#[tokio::test]
async fn retained_snapshot_quota_rejects_missing_stop_without_leaving_partial_identity() {
    let directory = kasumi_store::test_utils::private_tempdir().unwrap();
    let physical =
        common::PhysicalFixture::new(&directory.path().join("node.kv"), Default::default());
    let (db, audit, node) = open(
        &physical,
        &directory.path().join("node.kv"),
        Limits::default(),
        true,
    )
    .await;
    let mut limits = db.engine().generation().unwrap().state.limits.clone();
    limits.max_snapshot_bytes = db.engine().snapshot_bytes().unwrap() as u64 + 8192;
    db.administer(context(), Operation::SetLimits(limits))
        .await
        .unwrap();
    let (_, chunk) = original(&db, "bounded");
    let original = BeginStagedTransaction {
        scope: kasumi_types::StagedTransactionScope {
            tenant: context().tenant,
            principal: context().principal,
            incarnation: db.engine().generation().unwrap().state.incarnation.clone(),
        },
        transaction_id: "snapshot-full".into(),
        ttl_ms: 60_000,
        manifest: StagedManifest::from_chunks(&vec![chunk; 512]).unwrap(),
    };
    let terminal_head = db
        .engine()
        .generation()
        .unwrap()
        .state
        .staged_terminal_head
        .clone();
    assert_eq!(
        db.stop_staged_transaction(context(), stop(&db, &original))
            .await
            .unwrap_err()
            .code,
        ErrorCode::QuotaExceeded
    );
    let generation = db.engine().generation().unwrap();
    assert_eq!(generation.state.staged_terminal_head, terminal_head);
    assert!(generation.state.staged_transactions.is_empty());
    assert!(generation.state.active_staged_transactions.is_empty());
    assert_eq!(
        db.engine().snapshot_bytes().unwrap() as u64,
        snapshot_accounted_bytes(
            &db.engine()
                .fixture_snapshot(&physical.storage.scratch)
                .unwrap(),
        )
        .unwrap()
    );
    drop(generation);
    assert_eq!(
        db.staged_transaction_status(&context(), &original.reference().unwrap())
            .await
            .unwrap_err()
            .code,
        ErrorCode::NotFound
    );
    close(db, audit, node).await;
}

#[tokio::test]
async fn guarded_stop_orders_more_than_one_small_batch_of_authority_dependencies() {
    let directory = kasumi_store::test_utils::private_tempdir().unwrap();
    let physical =
        common::PhysicalFixture::new(&directory.path().join("node.kv"), Default::default());
    let (db, audit, node) = open(
        &physical,
        &directory.path().join("node.kv"),
        Limits::default(),
        true,
    )
    .await;
    for batch in 0..3 {
        db.mutate(
            context(),
            MutationBatch {
                idempotency_key: format!("authority-{batch}"),
                read_set: vec![],
                operations: (batch * 200..(batch + 1) * 200)
                    .map(|index| Mutation::Put {
                        collection: "authority".into(),
                        id: format!("dependency-{index}"),
                        expected: Precondition::Absent,
                        body: json!({"active":true}),
                    })
                    .collect(),
            },
        )
        .await
        .unwrap();
    }
    let (original, _) = original(&db, "large-authority");
    let mut request = stop(&db, &original);
    let generation = db.engine().generation().unwrap();
    request.admission.extend((0..600).map(|index| {
        let id = format!("dependency-{index}");
        ReadAssertion::Document {
            collection: "authority".into(),
            expected: ReadPrecondition::Version(
                generation.state.collections["authority"].documents[&id].version,
            ),
            id,
        }
    }));
    drop(generation);
    assert_eq!(request.admission.len(), 604);
    db.mutate(
        context(),
        MutationBatch {
            idempotency_key: "last-dependency-revoked".into(),
            read_set: vec![],
            operations: vec![Mutation::Put {
                collection: "authority".into(),
                id: "dependency-599".into(),
                expected: Precondition::Any,
                body: json!({"active":false}),
            }],
        },
    )
    .await
    .unwrap();
    assert_eq!(
        db.stop_staged_transaction(context(), request.clone())
            .await
            .unwrap_err()
            .code,
        ErrorCode::Conflict
    );
    assert!(
        db.engine()
            .generation()
            .unwrap()
            .state
            .staged_transactions
            .is_empty()
    );
    *request.admission.last_mut().unwrap() = ReadAssertion::Document {
        collection: "authority".into(), id: "dependency-599".into(),
        expected: ReadPrecondition::Version(db.engine().generation().unwrap().state.collections["authority"].documents["dependency-599"].version),
    };
    assert!(matches!(
        db.stop_staged_transaction(context(), request)
            .await
            .unwrap()
            .outcome,
        StagedOutcome::Aborted { .. }
    ));
    close(db, audit, node).await;
}

#[tokio::test]
async fn encrypted_restore_preserves_original_stage_scope_without_reviving_historical_uploads() {
    let directory = kasumi_store::test_utils::private_tempdir().unwrap();
    let physical =
        common::PhysicalFixture::new(&directory.path().join("source.kv"), Default::default());
    let (db, audit, node) = open(
        &physical,
        &directory.path().join("source.kv"),
        Limits::default(),
        true,
    )
    .await;
    let (finished, finished_chunk) = original(&db, "finished-before-backup");
    upload(&db, &finished, &finished_chunk).await;
    let receipt = db
        .finalize_staged_transaction(context(), finished.reference().unwrap())
        .await
        .unwrap();
    let (mut live, chunk) = original(&db, "historical-upload");
    live.ttl_ms = 86_400_000;
    upload(&db, &live, &chunk).await;
    let backups = Arc::new(
        kasumi_store::FilesystemBackupDestination::new_fixture(
            directory.path().join("backups"),
            8 << 20,
            physical.storage.admission.memory().clone(),
        )
        .unwrap(),
    );
    let checkpoint = db
        .backup_checkpoint(context(), backups.as_ref(), uuid::Uuid::new_v4())
        .await
        .unwrap();
    let source_incarnation = live.scope.incarnation.clone();
    close(db.clone(), audit.clone(), node.clone()).await;
    drop(db);
    drop(audit);
    let node = physical
        .storage
        .create_new(
            directory.path().join("restored.kv"),
            kasumi_store::test_utils::NODE_STORE_ID,
        )
        .unwrap();
    let audit = common::security_audit(node.clone(), physical.storage.admission.clone()).await;
    let stores = TenantStorageSet::initialize_catalogs_fixture(
        node.clone(),
        context().tenant,
        Arc::new(LocalKeyProvider::new([0x95; 32])),
        Arc::new(LocalKeyProvider::new([0x96; 32])),
    )
    .await
    .unwrap();
    // Restore replays into the target, so select its audit placement first.
    kasumi_engine::test_utils::install_fixture_audit_placement(stores.application()).unwrap();
    let db = kasumi_engine::restore_local(
        &kasumi_engine::RestoreSource {
            timeout_ms: 60_000,
            destination_alias: "restored".into(),
            destination: backups,
            keys: Arc::new(LocalKeyProvider::new([0x95; 32])),
        },
        stores,
        common::local_restore_request(context(), checkpoint.checkpoint(), uuid::Uuid::new_v4()),
        audit.admission().clone(),
        audit.clone(),
    )
    .await
    .unwrap();
    db.complete_restore(context()).await.unwrap();
    db.administer(context(), Operation::Suspend(false))
        .await
        .unwrap();
    let incarnation = db.engine().generation().unwrap().state.incarnation.clone();
    assert_ne!(source_incarnation, incarnation);
    let credential = |incarnation: &str| {
        let observation = kasumi_clock::EpochClock::system()
            .unwrap()
            .observe()
            .unwrap();
        RequestContext {
            authorization: RequestAuthorization::from_verified_credential(
                observation.utc_ms() + 60_000,
                &observation,
                CredentialResource::Database {
                    incarnation: uuid::Uuid::parse_str(incarnation).unwrap(),
                },
            )
            .unwrap(),
            ..context()
        }
    };
    let current = credential(&incarnation);
    let old = credential(&source_incarnation);
    assert!(
        db.staged_transaction_status(&old, &live.reference().unwrap())
            .await
            .is_err()
    );
    let observed = db
        .staged_transaction_status(&current, &live.reference().unwrap())
        .await
        .unwrap();
    assert_eq!(observed.transaction, live.reference().unwrap());
    assert_eq!(observed.received_chunks, vec![0]);
    assert!(matches!(observed.outcome, StagedOutcome::Uploading));
    assert_eq!(
        db.begin_staged_transaction(current.clone(), live.clone())
            .await
            .unwrap_err()
            .code,
        ErrorCode::Conflict
    );
    assert_eq!(
        db.append_staged_chunk(
            current.clone(),
            AppendStagedChunk {
                transaction: live.reference().unwrap(),
                index: 0,
                chunk
            }
        )
        .await
        .unwrap_err()
        .code,
        ErrorCode::Conflict
    );
    assert_eq!(
        db.finalize_staged_transaction(current.clone(), live.reference().unwrap())
            .await
            .unwrap_err()
            .code,
        ErrorCode::Conflict
    );
    let mut fabricated = live.clone();
    fabricated.scope.incarnation = incarnation.clone();
    assert_eq!(
        db.begin_staged_transaction(current.clone(), fabricated.clone())
            .await
            .unwrap_err()
            .code,
        ErrorCode::Conflict
    );
    assert_eq!(
        db.stop_staged_transaction(current.clone(), stop(&db, &fabricated))
            .await
            .unwrap_err()
            .code,
        ErrorCode::Conflict
    );
    assert_eq!(
        db.staged_transaction_status(&current, &fabricated.reference().unwrap())
            .await
            .unwrap_err()
            .code,
        ErrorCode::Conflict
    );
    let mut absent_historical = live.clone();
    absent_historical.transaction_id = "absent-historical".into();
    assert_eq!(
        db.begin_staged_transaction(current.clone(), absent_historical.clone())
            .await
            .unwrap_err()
            .code,
        ErrorCode::Conflict
    );
    assert_eq!(
        db.stop_staged_transaction(current.clone(), stop(&db, &absent_historical))
            .await
            .unwrap_err()
            .code,
        ErrorCode::Conflict
    );
    assert_eq!(
        db.staged_transaction_status(&current, &absent_historical.reference().unwrap())
            .await
            .unwrap_err()
            .code,
        ErrorCode::NotFound
    );
    assert_eq!(
        db.begin_staged_transaction(current.clone(), finished.clone())
            .await
            .unwrap(),
        receipt
    );
    assert_eq!(
        db.finalize_staged_transaction(current.clone(), finished.reference().unwrap())
            .await
            .unwrap(),
        receipt
    );
    let renewed = credential(&incarnation);
    let stopped = db
        .stop_staged_transaction(renewed.clone(), stop(&db, &live))
        .await
        .unwrap();
    assert_eq!(stopped.transaction, live.reference().unwrap());
    assert!(matches!(stopped.outcome, StagedOutcome::Aborted { .. }));
    assert_eq!(
        db.staged_transaction_status(&renewed, &live.reference().unwrap())
            .await
            .unwrap()
            .outcome,
        stopped.outcome
    );
    assert!(
        !db.engine().generation().unwrap().state.collections["docs"]
            .documents
            .contains_key("historical-upload")
    );
    let staged = db.engine().generation().unwrap();
    assert!(staged.state.staged_transactions.is_empty());
    assert_eq!(staged.state.staged_terminal_head.count, 2);
    drop(staged);
    // Both permanent outcomes must remain point-addressable under the source
    // scope after restore; the resident map owns only unfinished uploads.
    let finished_status = db
        .staged_transaction_status(&renewed, &finished.reference().unwrap())
        .await
        .unwrap();
    assert_eq!(finished_status.transaction, finished.reference().unwrap());
    assert_eq!(
        finished_status.transaction.scope.incarnation,
        source_incarnation
    );
    assert_eq!(
        finished_status.outcome,
        StagedOutcome::Finished {
            outcome: Ok(receipt)
        }
    );
    assert_eq!(stopped.transaction.scope.incarnation, source_incarnation);
    close(db, audit, node).await;
}
