use kasumi_engine::test_utils::{SnapshotFixture, reserved_payload_bytes};
mod common;
use kasumi_engine::{Database, SecurityAudit};
use kasumi_store::{
    BackupDestination, FilesystemBackupDestination, NodeStore, TenantStore,
    test_utils::LocalKeyProvider,
};
use kasumi_types::*;
use serde_json::json;
use sha2::{Digest, Sha256};
use std::{collections::BTreeSet, sync::Arc};

fn context() -> RequestContext {
    RequestContext {
        authorization: kasumi_types::RequestAuthorization::service_identity(),
        tenant: "checkpoint".into(),
        principal: "owner".into(),
        scopes: BTreeSet::from([Action::Read, Action::Write, Action::Admin]),
        request_id: "backup-proof-test".into(),
    }
}
#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn captured_and_historical_backup_verification_fit_fixed_production_workspace() {
    let maximum = 480 << 20;
    let fixture = Fixture::with_admission(
        Limits {
            max_batch_bytes: 1 << 20,
            max_result_bytes: 1 << 20,
            ..Limits::default()
        },
        kasumi_engine::admission::AdmissionConfig {
            max_inflight_bytes: Some(maximum),
            ..Default::default()
        },
        true,
    )
    .await;
    for index in 0..40 {
        let id = format!("large-{index}");
        fixture
            .db
            .mutate(
                context(),
                MutationBatch {
                    idempotency_key: id.clone(),
                    read_set: vec![],
                    operations: vec![Mutation::Put {
                        collection: "journal".into(),
                        id,
                        body: json!({"payload": "x".repeat(768 << 10)}),
                        expected: Precondition::Absent,
                    }],
                },
            )
            .await
            .unwrap();
    }
    let resident = fixture
        .db
        .engine()
        .fixture_snapshot(fixture.store.scratch_disk())
        .unwrap()
        .len();
    // Both production archival lanes and the service ledger are installed.
    // The former proportional verifier cannot fit alongside those same reserves.
    assert!(fixture.db.audit_maintenance_status().is_some());
    assert!(resident * 3 + (256 << 20) + 2 * AuditRetentionBudget::MAINTENANCE_BYTES > maximum);
    let production_payload = fixture.production_payload_baseline();
    let proof = fixture
        .db
        .backup_checkpoint_named(context(), "approved", uuid::Uuid::new_v4())
        .await
        .unwrap();
    assert_eq!(proof.checkpoint().tenant, "checkpoint");
    let published_payload = fixture.reserved_payload();
    assert!(
        published_payload >= production_payload
            && published_payload - production_payload <= 1 << 20,
        "committed proof metadata stays bounded independently of the backup payload"
    );
    let independently_verified = fixture
        .db
        .verify_backup_checkpoint_named(context(), "approved", proof.checkpoint().backup_id)
        .await
        .unwrap();
    assert_eq!(independently_verified.checkpoint(), proof.checkpoint());
    assert_eq!(fixture.reserved_payload(), published_payload);
    fixture.close().await;
}

#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn restore_hands_off_verified_workspace_with_production_and_destination_reserves() {
    let fixture = Fixture::with_admission(
        Limits::default(),
        kasumi_engine::admission::AdmissionConfig {
            max_inflight_bytes: Some(640 << 20),
            ..Default::default()
        },
        true,
    )
    .await;
    fixture.write("retained").await;
    let checkpoint = fixture
        .db
        .backup_checkpoint_named(context(), "approved", uuid::Uuid::new_v4())
        .await
        .unwrap()
        .checkpoint()
        .clone();
    let admission = fixture.audit.admission().clone();
    assert!(fixture.db.audit_maintenance_status().is_some());
    let production_payload = fixture.production_payload_baseline();
    // Keep the real service/tenant maintenance pools plus the native destination
    // charge installed throughout verification, materialization and publication.
    let destination_workspace = admission.reserve(128 << 20, None).unwrap();
    let previous_verification = admission.reserve(128 << 20, None).unwrap();
    assert!(
        admission.reserve((64 << 20) + 1, None).is_err(),
        "the previous additive materialization strategy must not fit"
    );
    drop(previous_verification);
    let node = fixture
        .physical
        .storage
        .create_new(
            fixture.directory.path().join("restore-budget.kv"),
            kasumi_store::test_utils::NODE_STORE_ID,
        )
        .unwrap();
    let target = TenantStore::initialize_catalog_fixture(
        node.clone(),
        "checkpoint".into(),
        Arc::new(LocalKeyProvider::new([0xD8; 32])),
    )
    .await
    .unwrap();
    let domains = kasumi_store::test_utils::initialize_custody_fixture(
        target.clone(),
        Arc::new(LocalKeyProvider::new([241; 32])),
    )
    .await
    .unwrap();
    let source = kasumi_engine::RestoreSource {
        destination_alias: "approved".into(),
        destination: fixture.destination.clone(),
        keys: Arc::new(LocalKeyProvider::new([0xD8; 32])),
        timeout_ms: 60_000,
    };
    let restored = kasumi_engine::restore_local(
        &source,
        domains.clone(),
        common::local_restore_request(context(), &checkpoint, uuid::Uuid::new_v4()),
        admission.clone(),
        fixture.audit.clone(),
    )
    .await
    .unwrap();
    assert_eq!(
        restored.engine().generation().unwrap().state.document_count,
        1
    );
    let proposal_metadata = Database::fixture_proposal_metadata_bytes().unwrap();
    let expected_live =
        production_payload + (128 << 20) + snapshot_owner_bytes() + proposal_metadata;
    let restored_payload = fixture.reserved_payload();
    assert!(
        restored_payload >= expected_live && restored_payload - expected_live <= 1 << 20,
        "target node metadata remains bounded"
    );
    let restore_metadata = restored_payload - expected_live;
    // Restore's mandatory audit proposal installs its own fixed registry. A
    // successful drain releases that registry while the group facade stays live.
    restored.shutdown().await.unwrap();
    assert_eq!(
        fixture.reserved_payload(),
        production_payload + (128 << 20) + snapshot_owner_bytes() + restore_metadata
    );
    domains.custody().store().shutdown().await.unwrap();
    target.shutdown().await.unwrap();
    node.shutdown().await.unwrap();
    drop(restored);
    drop(domains);
    drop(target);
    let before_reopen_payload = fixture.reserved_payload();
    let before_reopen_reservations = admission.snapshot().live_reservations;
    let node = fixture
        .physical
        .storage
        .open_existing(
            fixture.directory.path().join("restore-budget.kv"),
            kasumi_store::test_utils::NODE_STORE_ID,
        )
        .unwrap();
    let before_catalog_open = fixture.reserved_payload();
    let before_catalog_reservations = admission.snapshot().live_reservations;
    // Reopening each decoded catalog retains its typed allocation charge with
    // its owner. The restored catalog's shape can differ from the source.
    let target = TenantStore::open_existing_fixture(
        node.clone(),
        "checkpoint".into(),
        Arc::new(LocalKeyProvider::new([0xD8; 32])),
    )
    .await
    .unwrap();
    let after_application_catalog = fixture.reserved_payload();
    let application_catalog_charge = after_application_catalog
        .checked_sub(before_catalog_open)
        .expect("application catalog charge cannot reduce installed memory");
    assert!(application_catalog_charge > 0 && application_catalog_charge <= 1 << 20);
    assert_eq!(
        admission.snapshot().live_reservations,
        before_catalog_reservations + 1
    );
    let domains = kasumi_store::test_utils::open_existing_custody_fixture(
        target,
        Arc::new(LocalKeyProvider::new([241; 32])),
    )
    .await
    .unwrap();
    let custody_catalog_charge = fixture
        .reserved_payload()
        .checked_sub(after_application_catalog)
        .expect("custody catalog charge cannot reduce installed memory");
    assert!(custody_catalog_charge > 0 && custody_catalog_charge <= 1 << 20);
    assert_eq!(
        admission.snapshot().live_reservations,
        before_catalog_reservations + 2
    );
    let reopened =
        kasumi_engine::open_local(domains, policy(), Limits::default(), fixture.audit.clone())
            .await
            .unwrap();
    assert_eq!(
        reopened.engine().generation().unwrap().state.document_count,
        1
    );
    assert_eq!(
        fixture.reserved_payload(),
        production_payload
            + (128 << 20)
            + snapshot_owner_bytes()
            + restore_metadata
            + application_catalog_charge
            + custody_catalog_charge
    );
    reopened.shutdown().await.unwrap();
    node.shutdown().await.unwrap();
    drop(reopened);
    assert_eq!(fixture.reserved_payload(), before_reopen_payload);
    assert_eq!(
        admission.snapshot().live_reservations,
        before_reopen_reservations
    );
    drop(destination_workspace);
    assert_eq!(fixture.reserved_payload(), production_payload);
    fixture.close().await;
}

#[tokio::test]
async fn cancelled_restore_publication_keeps_storage_and_workspace_until_write_drains() {
    use std::sync::{
        Mutex,
        atomic::{AtomicBool, Ordering},
    };
    type Pause = (
        tokio::sync::oneshot::Sender<()>,
        std::sync::mpsc::Receiver<()>,
    );
    #[derive(Clone, Debug)]
    struct PausedBackend {
        inner: kasumi_store::test_utils::FaultBackend,
        pause: Arc<Mutex<Option<Pause>>>,
        blocked: Arc<AtomicBool>,
    }
    impl kasumi_kv::StorageBackend for PausedBackend {
        fn len(&self) -> std::io::Result<u64> {
            self.inner.len()
        }
        fn read(&self, offset: u64, bytes: &mut [u8]) -> std::io::Result<()> {
            self.inner.read(offset, bytes)
        }
        fn set_len(&self, length: u64) -> std::io::Result<()> {
            self.inner.set_len(length)
        }
        fn sync_data(&self) -> std::io::Result<()> {
            self.inner.sync_data()
        }
        fn write(&self, offset: u64, bytes: &[u8]) -> std::io::Result<()> {
            let pause = self.pause.lock().unwrap().take();
            if let Some((started, release)) = pause {
                self.blocked.store(true, Ordering::SeqCst);
                let _ = started.send(());
                // A regression to synchronous runtime I/O must fail instead of
                // hanging the test process indefinitely.
                let result = release.recv_timeout(std::time::Duration::from_secs(5));
                self.blocked.store(false, Ordering::SeqCst);
                result.map_err(std::io::Error::other)?;
            }
            self.inner.write(offset, bytes)
        }

        fn close(&self) -> kasumi_kv::BackendCloseOutcome {
            self.inner.close()
        }
    }
    let fixture = Fixture::with_admission(Limits::default(), Default::default(), true).await;
    fixture.write("retained").await;
    let checkpoint = fixture
        .db
        .backup_checkpoint_named(context(), "approved", uuid::Uuid::new_v4())
        .await
        .unwrap()
        .checkpoint()
        .clone();
    let admission = fixture.audit.admission().clone();
    let production_payload = fixture.production_payload_baseline();
    let backend = PausedBackend {
        inner: kasumi_store::test_utils::FaultBackend::new(),
        pause: Arc::new(Mutex::new(None)),
        blocked: Arc::new(AtomicBool::new(false)),
    };
    let node = NodeStore::open_fixture_backend_on_disk(
        backend.clone(),
        kasumi_store::test_utils::storage_admission(),
        fixture.physical.storage.persistent.clone(),
        fixture.store.scratch_disk().clone(),
    )
    .unwrap();
    let target = TenantStore::initialize_catalog_fixture(
        node,
        "checkpoint".into(),
        Arc::new(LocalKeyProvider::new([0xD8; 32])),
    )
    .await
    .unwrap();
    let weak = Arc::downgrade(&target);
    let domains = kasumi_store::test_utils::initialize_custody_fixture(
        target,
        Arc::new(LocalKeyProvider::new([241; 32])),
    )
    .await
    .unwrap();
    let (started_tx, started_rx) = tokio::sync::oneshot::channel();
    let (release_tx, release_rx) = std::sync::mpsc::channel();
    *backend.pause.lock().unwrap() = Some((started_tx, release_rx));
    let source = kasumi_engine::RestoreSource {
        destination_alias: "approved".into(),
        destination: fixture.destination.clone(),
        keys: Arc::new(LocalKeyProvider::new([0xD8; 32])),
        timeout_ms: 30_000,
    };
    let audit = fixture.audit.clone();
    let owned_admission = admission.clone();
    let request = common::local_restore_request(context(), &checkpoint, uuid::Uuid::new_v4());
    let task = tokio::spawn(async move {
        kasumi_engine::restore_local(&source, domains, request, owned_admission, audit).await
    });
    started_rx.await.unwrap();
    assert!(
        backend.blocked.load(Ordering::SeqCst),
        "publication blocked the async executor"
    );
    // This is a single-thread runtime; this timer can run only if the storage
    // write belongs to a separate owned worker.
    tokio::time::sleep(std::time::Duration::from_millis(10)).await;
    assert!(backend.blocked.load(Ordering::SeqCst));
    task.abort();
    assert!(matches!(task.await, Err(error) if error.is_cancelled()));
    assert!(weak.upgrade().is_some());
    assert!(fixture.reserved_payload() > production_payload);
    release_tx.send(()).unwrap();
    tokio::time::timeout(std::time::Duration::from_secs(5), async {
        while weak.upgrade().is_some() || fixture.reserved_payload() != production_payload {
            tokio::task::yield_now().await;
        }
    })
    .await
    .unwrap();
    // Cancellation before the final manifest cannot publish a partial genesis.
    let node = NodeStore::open_fixture_backend_on_disk(
        backend,
        kasumi_store::test_utils::storage_admission(),
        fixture.physical.storage.persistent.clone(),
        fixture.store.scratch_disk().clone(),
    )
    .unwrap();
    let reopened = TenantStore::open_existing_fixture(
        node,
        "checkpoint".into(),
        Arc::new(LocalKeyProvider::new([0xD8; 32])),
    )
    .await
    .unwrap();
    assert!(
        reopened
            .get("engine.bootstrap", b"manifest")
            .unwrap()
            .is_none()
    );
    reopened.shutdown().await.unwrap();
    fixture.close().await;
}

fn policy() -> Policy {
    Policy {
        grants: vec![Grant {
            principal: "owner".into(),
            collection: None,
            actions: context().scopes,
        }],
        strict_read_audit: false,
    }
}
fn snapshot_owner_bytes() -> u64 {
    kasumi_raft::SnapshotBufferOwner::required_bytes(kasumi_raft::SNAPSHOT_BUFFER_SLOTS).unwrap()
}

struct Fixture {
    directory: tempfile::TempDir,
    physical: common::PhysicalFixture,
    db: Arc<Database>,
    audit: Arc<SecurityAudit>,
    store: Arc<TenantStore>,
    node: Arc<NodeStore>,
    destination: Arc<FilesystemBackupDestination>,
}
impl Fixture {
    fn reserved_payload(&self) -> u64 {
        reserved_payload_bytes(self.audit.admission())
            .checked_sub(self.physical.initial_disk_metadata_bytes)
            .expect("actual installed disk metadata remains charged")
    }
    fn production_payload_baseline(&self) -> u64 {
        let bytes = self.reserved_payload();
        assert!(
            bytes >= 3 * AuditRetentionBudget::MAINTENANCE_BYTES + snapshot_owner_bytes(),
            "production maintenance lanes and the serving snapshot inventory stay charged"
        );
        bytes
    }
    async fn new() -> Self {
        Self::with_limits(Limits::default()).await
    }
    async fn with_limits(limits: Limits) -> Self {
        Self::with_admission(limits, Default::default(), false).await
    }
    async fn with_admission(
        limits: Limits,
        config: kasumi_engine::admission::AdmissionConfig,
        production: bool,
    ) -> Self {
        let directory = kasumi_store::test_utils::private_tempdir().unwrap();
        let config = kasumi_engine::test_utils::admission_config_with_bookkeeping(config).unwrap();
        let physical = common::PhysicalFixture::new(&directory.path().join("node.kv"), config);
        let admission = physical.storage.admission.clone();
        let node = physical
            .storage
            .create_new(
                directory.path().join("node.kv"),
                kasumi_store::test_utils::NODE_STORE_ID,
            )
            .unwrap();
        let audit = common::security_audit(node.clone(), admission.clone()).await;
        let store = TenantStore::initialize_catalog_fixture(
            node.clone(),
            "checkpoint".into(),
            Arc::new(LocalKeyProvider::new([0xD8; 32])),
        )
        .await
        .unwrap();
        let stores = kasumi_store::test_utils::initialize_custody_fixture(
            store.clone(),
            std::sync::Arc::new(kasumi_store::test_utils::LocalKeyProvider::new([241; 32])),
        )
        .await
        .unwrap();
        let db = if production {
            kasumi_engine::open_local(stores, policy(), limits, audit.clone())
                .await
                .unwrap()
        } else {
            kasumi_engine::test_utils::open_fixture(stores, policy(), limits, audit.clone())
                .await
                .unwrap()
        };
        db.administer(
            context(),
            Operation::CreateCollection(CollectionDefinition {
                name: "journal".into(),
                write_mode: CollectionWriteMode::AppendOnly,
                retention_class: CollectionRetentionClass::ArchivableHistory,
                schema: json!({"type":"object"}),
                indexes: vec![],
                strict_read_audit: false,
            }),
        )
        .await
        .unwrap();
        let destination = Arc::new(
            FilesystemBackupDestination::new(
                directory.path().join("backups"),
                16 << 20,
                physical.storage.persistent.clone(),
            )
            .unwrap(),
        );
        db.install_archive_destination("approved".into(), destination.clone())
            .unwrap();
        Self {
            directory,
            physical,
            db,
            audit,
            store,
            node,
            destination,
        }
    }
    async fn write(&self, id: &str) -> WriteReceipt {
        self.db
            .mutate(
                context(),
                MutationBatch {
                    idempotency_key: id.into(),
                    read_set: vec![],
                    operations: vec![Mutation::Put {
                        collection: "journal".into(),
                        id: id.into(),
                        body: serde_json::from_str(
                            r#"{"amount":90071992547409931234567890.123456789}"#,
                        )
                        .unwrap(),
                        expected: Precondition::Absent,
                    }],
                },
            )
            .await
            .unwrap()
    }
    async fn close(&self) {
        self.db.shutdown().await.unwrap();
        self.audit.shutdown().await.unwrap();
        self.node.shutdown().await.unwrap();
    }
}

#[tokio::test]
async fn checkpoint_binds_actual_generation_complete_graph_keys_and_encrypted_restart() {
    let fixture = Fixture::new().await;
    let first = fixture.write("first").await;
    fixture
        .db
        .archive_history(
            context(),
            ArchiveHistory {
                archive_id: "period-one".into(),
                collection: "journal".into(),
                cutoff_revision: first.revision,
                destination: "approved".into(),
            },
        )
        .await
        .unwrap();
    let first_proof = fixture
        .db
        .backup_checkpoint(
            context(),
            fixture.destination.as_ref(),
            uuid::Uuid::new_v4(),
        )
        .await
        .unwrap();
    fixture.store.rotate_data_key().await.unwrap();
    let second = fixture.write("second").await;
    let snapshot = fixture
        .db
        .engine()
        .fixture_snapshot(fixture.store.scratch_disk())
        .unwrap();
    let state = fixture.db.engine().generation().unwrap();
    let revision = state.state.revision;
    let incarnation = state.state.incarnation.clone();
    drop(state);
    let proof = fixture
        .db
        .backup_checkpoint_named(context(), "approved", uuid::Uuid::new_v4())
        .await
        .unwrap();
    assert_eq!(proof.tenant(), "checkpoint");
    assert_eq!(proof.source_incarnation(), incarnation);
    assert_eq!(proof.revision(), revision);
    assert!(proof.revision() >= second.revision);
    assert_eq!(proof.resident_sha256(), snapshot.sha256());
    let bytes = fixture
        .destination
        .session_get(
            proof.backup_id(),
            kasumi_store::BackupSessionSlot::Object(proof.backup_id()),
            8 << 20,
        )
        .await
        .unwrap()
        .unwrap();
    assert_eq!(
        proof.manifest_ciphertext_sha256(),
        hex::encode(Sha256::digest(&bytes))
    );
    assert_ne!(
        first_proof.key_lineage_digest(),
        proof.key_lineage_digest(),
        "rotation changes actual wrapped-key dependencies"
    );
    let verified = fixture
        .db
        .verify_backup_checkpoint_named(context(), "approved", proof.backup_id())
        .await
        .unwrap();
    assert_eq!(verified.checkpoint(), proof.checkpoint());
    // Mutating live state never changes the identity of an already published backup.
    fixture.write("third").await;
    assert_eq!(
        fixture
            .db
            .verify_backup_checkpoint(context(), fixture.destination.as_ref(), proof.backup_id())
            .await
            .unwrap()
            .checkpoint(),
        proof.checkpoint()
    );
    let path = fixture.directory.path().join("node.kv");
    let destination = fixture.destination.clone();
    fixture.close().await;
    let Fixture {
        directory,
        physical,
        db,
        audit,
        store,
        node,
        ..
    } = fixture;
    drop(db);
    drop(audit);
    drop(store);
    drop(node);
    let node = physical
        .storage
        .open_existing(&path, kasumi_store::test_utils::NODE_STORE_ID)
        .unwrap();
    let audit =
        common::existing_security_audit(node.clone(), physical.storage.admission.clone()).await;
    let store = TenantStore::open_existing_fixture(
        node.clone(),
        "checkpoint".into(),
        Arc::new(LocalKeyProvider::new([0xD8; 32])),
    )
    .await
    .unwrap();
    let db = kasumi_engine::test_utils::open_fixture(
        kasumi_store::test_utils::open_existing_custody_fixture(
            store,
            std::sync::Arc::new(kasumi_store::test_utils::LocalKeyProvider::new([241; 32])),
        )
        .await
        .unwrap(),
        policy(),
        Limits::default(),
        audit.clone(),
    )
    .await
    .unwrap();
    assert_eq!(
        db.verify_backup_checkpoint(context(), destination.as_ref(), proof.backup_id())
            .await
            .unwrap()
            .checkpoint(),
        proof.checkpoint()
    );
    db.shutdown().await.unwrap();
    audit.shutdown().await.unwrap();
    node.shutdown().await.unwrap();
    drop(db);
    drop(audit);
    drop(directory);
}

#[derive(Clone, Copy)]
enum ObjectReadFault {
    Missing,
    Corrupt,
}

// Model one faulty remote response without mutating an enrolled local file.
// The healthy destination still performs its original bounded read; only the
// selected session/object response changes, and all other errors propagate.
struct FaultyObjectRead {
    inner: Arc<FilesystemBackupDestination>,
    session: uuid::Uuid,
    object: uuid::Uuid,
    fault: ObjectReadFault,
    reads: std::sync::atomic::AtomicUsize,
}
impl FaultyObjectRead {
    fn new(
        inner: Arc<FilesystemBackupDestination>,
        session: uuid::Uuid,
        object: uuid::Uuid,
        fault: ObjectReadFault,
    ) -> Self {
        Self {
            inner,
            session,
            object,
            fault,
            reads: std::sync::atomic::AtomicUsize::new(0),
        }
    }

    fn assert_read(&self) {
        assert!(self.reads.swap(0, std::sync::atomic::Ordering::Relaxed) > 0);
    }
}
#[async_trait::async_trait]
impl BackupDestination for FaultyObjectRead {
    fn namespace_binding(&self) -> anyhow::Result<kasumi_types::BackupNamespaceBinding> {
        self.inner.namespace_binding()
    }
    async fn put(&self, id: uuid::Uuid, bytes: kasumi_store::BackupUpload) -> anyhow::Result<()> {
        self.inner.put(id, bytes).await
    }
    async fn get(&self, id: uuid::Uuid, limit: usize) -> anyhow::Result<Vec<u8>> {
        self.inner.get(id, limit).await
    }
    async fn session_put(
        &self,
        session: uuid::Uuid,
        slot: kasumi_store::BackupSessionSlot,
        bytes: kasumi_store::BackupUpload,
    ) -> anyhow::Result<()> {
        self.inner.session_put(session, slot, bytes).await
    }
    async fn session_get(
        &self,
        session: uuid::Uuid,
        slot: kasumi_store::BackupSessionSlot,
        limit: usize,
    ) -> anyhow::Result<Option<Vec<u8>>> {
        let mut value = self.inner.session_get(session, slot, limit).await?;
        if session == self.session && slot == kasumi_store::BackupSessionSlot::Object(self.object) {
            let bytes = value
                .as_mut()
                .ok_or_else(|| anyhow::anyhow!("fault fixture object is missing"))?;
            let last = bytes
                .last_mut()
                .ok_or_else(|| anyhow::anyhow!("fault fixture object is empty"))?;
            self.reads
                .fetch_add(1, std::sync::atomic::Ordering::Relaxed);
            match self.fault {
                ObjectReadFault::Missing => value = None,
                ObjectReadFault::Corrupt => *last ^= 1,
            }
        }
        Ok(value)
    }
}

#[tokio::test]
async fn missing_corrupt_resident_or_cold_dependency_and_history_subset_never_yield_proof() {
    let fixture = Fixture::new().await;
    let receipt = fixture.write("cold").await;
    fixture
        .db
        .archive_history(
            context(),
            ArchiveHistory {
                archive_id: "period".into(),
                collection: "journal".into(),
                cutoff_revision: receipt.revision,
                destination: "approved".into(),
            },
        )
        .await
        .unwrap();
    let archive = fixture
        .db
        .engine()
        .generation()
        .unwrap()
        .state
        .history_archives["period"]
        .clone();
    let proof = fixture
        .db
        .backup_checkpoint(
            context(),
            fixture.destination.as_ref(),
            uuid::Uuid::new_v4(),
        )
        .await
        .unwrap();
    assert_eq!(
        fixture
            .db
            .verify_backup_checkpoint(
                context(),
                fixture.destination.as_ref(),
                uuid::Uuid::parse_str(&archive.manifest_object_id).unwrap()
            )
            .await
            .unwrap_err()
            .code,
        ErrorCode::NotFound
    );
    let manifest = fixture
        .destination
        .session_get(
            proof.backup_id(),
            kasumi_store::BackupSessionSlot::Object(proof.backup_id()),
            8 << 20,
        )
        .await
        .unwrap();
    let manifest = manifest.unwrap();
    let contents = fixture
        .store
        .decrypt_backup_object(&manifest, proof.backup_id(), 4 << 20)
        .await
        .unwrap();
    let value: serde_json::Value = serde_json::from_slice(&contents.snapshot).unwrap();
    let page_id = uuid::Uuid::parse_str(value["last_page"]["object_id"].as_str().unwrap()).unwrap();
    let encrypted_page = fixture
        .destination
        .session_get(
            proof.backup_id(),
            kasumi_store::BackupSessionSlot::Object(page_id),
            8 << 20,
        )
        .await
        .unwrap()
        .unwrap();
    let page = fixture
        .store
        .decrypt_backup_object(&encrypted_page, page_id, 4 << 20)
        .await
        .unwrap();
    let page: serde_json::Value = serde_json::from_slice(&page.snapshot).unwrap();
    let resident = page["chunks"][0]["object_id"].as_str().unwrap();
    for object in [resident, archive.manifest.chunks[0].object_id.as_str()] {
        let object = uuid::Uuid::parse_str(object).unwrap();
        for (fault, expected) in [
            (ObjectReadFault::Missing, ErrorCode::Unavailable),
            (ObjectReadFault::Corrupt, ErrorCode::Corruption),
        ] {
            let destination = FaultyObjectRead::new(
                fixture.destination.clone(),
                proof.backup_id(),
                object,
                fault,
            );
            assert_eq!(
                fixture
                    .db
                    .verify_backup_checkpoint(context(), &destination, proof.backup_id())
                    .await
                    .unwrap_err()
                    .code,
                expected
            );
            destination.assert_read();
        }
    }
    assert_eq!(
        fixture
            .db
            .verify_backup_checkpoint(context(), fixture.destination.as_ref(), proof.backup_id())
            .await
            .unwrap()
            .checkpoint(),
        proof.checkpoint()
    );
    fixture.close().await;
}

struct PausedRead {
    destination: Arc<FilesystemBackupDestination>,
    entered: tokio::sync::Notify,
    release: tokio::sync::Notify,
}
#[async_trait::async_trait]
impl BackupDestination for PausedRead {
    fn namespace_binding(&self) -> anyhow::Result<kasumi_types::BackupNamespaceBinding> {
        self.destination.namespace_binding()
    }
    async fn session_put(
        &self,
        session: uuid::Uuid,
        slot: kasumi_store::BackupSessionSlot,
        bytes: kasumi_store::BackupUpload,
    ) -> anyhow::Result<()> {
        kasumi_store::BackupDestination::session_put(
            self.destination.as_ref(),
            session,
            slot,
            bytes,
        )
        .await
    }
    async fn session_get(
        &self,
        session: uuid::Uuid,
        slot: kasumi_store::BackupSessionSlot,
        limit: usize,
    ) -> anyhow::Result<Option<Vec<u8>>> {
        if matches!(slot, kasumi_store::BackupSessionSlot::Object(_)) {
            self.entered.notify_one();
            self.release.notified().await;
        }
        kasumi_store::BackupDestination::session_get(
            self.destination.as_ref(),
            session,
            slot,
            limit,
        )
        .await
    }

    async fn put(&self, id: uuid::Uuid, bytes: kasumi_store::BackupUpload) -> anyhow::Result<()> {
        self.destination.put(id, bytes).await
    }
    async fn get(&self, id: uuid::Uuid, limit: usize) -> anyhow::Result<Vec<u8>> {
        self.entered.notify_one();
        self.release.notified().await;
        self.destination.get(id, limit).await
    }
}
#[tokio::test]
async fn verification_requires_current_global_admin_and_rechecks_policy_during_readback() {
    let fixture = Fixture::new().await;
    let proof = fixture
        .db
        .backup_checkpoint(
            context(),
            fixture.destination.as_ref(),
            uuid::Uuid::new_v4(),
        )
        .await
        .unwrap();
    let mut read_only = context();
    read_only.scopes = BTreeSet::from([Action::Read]);
    assert_eq!(
        fixture
            .db
            .verify_backup_checkpoint(read_only, fixture.destination.as_ref(), proof.backup_id())
            .await
            .unwrap_err()
            .code,
        ErrorCode::Forbidden
    );
    let fence = fixture
        .db
        .backup_checkpoint_response_fence(&context(), &proof)
        .unwrap();
    let paused = Arc::new(PausedRead {
        destination: fixture.destination.clone(),
        entered: Default::default(),
        release: Default::default(),
    });
    let task = tokio::spawn({
        let db = fixture.db.clone();
        let paused = paused.clone();
        async move {
            db.verify_backup_checkpoint(context(), paused.as_ref(), proof.backup_id())
                .await
        }
    });
    tokio::time::timeout(std::time::Duration::from_secs(5), paused.entered.notified())
        .await
        .unwrap();
    fixture
        .db
        .administer(
            context(),
            Operation::SetPolicy(Policy {
                grants: vec![Grant {
                    principal: "replacement".into(),
                    collection: None,
                    actions: BTreeSet::from([Action::Admin]),
                }],
                strict_read_audit: true,
            }),
        )
        .await
        .unwrap();
    assert_eq!(fence.check().unwrap_err().code, ErrorCode::Conflict);
    drop(fence);
    paused.release.notify_one();
    assert!(matches!(
        task.await.unwrap().unwrap_err().code,
        ErrorCode::Conflict | ErrorCode::Forbidden
    ));
    fixture.close().await;
}

#[tokio::test]
async fn shutdown_cancels_pending_checkpoint_read_and_releases_database_work() {
    let fixture = Fixture::new().await;
    let proof = fixture
        .db
        .backup_checkpoint(
            context(),
            fixture.destination.as_ref(),
            uuid::Uuid::new_v4(),
        )
        .await
        .unwrap();
    let paused = Arc::new(PausedRead {
        destination: fixture.destination.clone(),
        entered: Default::default(),
        release: Default::default(),
    });
    let task = tokio::spawn({
        let db = fixture.db.clone();
        let paused = paused.clone();
        async move {
            db.verify_backup_checkpoint(context(), paused.as_ref(), proof.backup_id())
                .await
        }
    });
    tokio::time::timeout(std::time::Duration::from_secs(5), paused.entered.notified())
        .await
        .unwrap();
    tokio::time::timeout(std::time::Duration::from_secs(5), fixture.db.shutdown())
        .await
        .unwrap()
        .unwrap();
    assert!(task.await.unwrap().is_err());
    fixture.audit.shutdown().await.unwrap();
}

struct SessionFault {
    inner: Arc<FilesystemBackupDestination>,
    fail_objects: bool,
    fail_outcome: bool,
    lose_outcome_ack: bool,
}
#[async_trait::async_trait]
impl BackupDestination for SessionFault {
    fn namespace_binding(&self) -> anyhow::Result<kasumi_types::BackupNamespaceBinding> {
        self.inner.namespace_binding()
    }
    async fn put(&self, id: uuid::Uuid, bytes: kasumi_store::BackupUpload) -> anyhow::Result<()> {
        self.inner.put(id, bytes).await
    }
    async fn get(&self, id: uuid::Uuid, limit: usize) -> anyhow::Result<Vec<u8>> {
        self.inner.get(id, limit).await
    }
    async fn session_get(
        &self,
        session: uuid::Uuid,
        slot: kasumi_store::BackupSessionSlot,
        limit: usize,
    ) -> anyhow::Result<Option<Vec<u8>>> {
        self.inner.session_get(session, slot, limit).await
    }
    async fn session_put(
        &self,
        session: uuid::Uuid,
        slot: kasumi_store::BackupSessionSlot,
        bytes: kasumi_store::BackupUpload,
    ) -> anyhow::Result<()> {
        if (self.fail_objects && matches!(slot, kasumi_store::BackupSessionSlot::Object(_)))
            || (self.fail_outcome && matches!(slot, kasumi_store::BackupSessionSlot::Outcome))
        {
            anyhow::bail!("injected publication failure");
        }
        self.inner.session_put(session, slot, bytes).await?;
        if self.lose_outcome_ack && matches!(slot, kasumi_store::BackupSessionSlot::Outcome) {
            anyhow::bail!("completion committed but acknowledgement lost");
        }
        Ok(())
    }
}

#[tokio::test]
async fn durable_session_resolves_lost_ack_and_never_reclaims_completed_graph() {
    let fixture = Fixture::new().await;
    fixture.write("before-backup").await;
    let session = uuid::Uuid::new_v4();
    let fault = SessionFault {
        inner: fixture.destination.clone(),
        fail_objects: false,
        fail_outcome: false,
        lose_outcome_ack: true,
    };
    let proof = fixture
        .db
        .backup_checkpoint(context(), &fault, session)
        .await
        .unwrap();
    fixture.write("after-backup").await;
    let retry = fixture
        .db
        .backup_checkpoint_named(context(), "approved", session)
        .await
        .unwrap();
    assert_eq!(proof.checkpoint(), retry.checkpoint());
    let status = fixture
        .db
        .abort_backup_session(
            context(),
            AbortBackupSession {
                destination: "approved".into(),
                session_id: session,
                reason: "operator reconciliation".into(),
            },
        )
        .await
        .unwrap();
    assert!(
        matches!(status.outcome, Some(BackupSessionOutcome::Complete { checkpoint, .. }) if checkpoint == *proof.checkpoint())
    );
    let error = fixture
        .db
        .cleanup_backup_session(
            context(),
            CleanupBackupSession {
                destination: "approved".into(),
                session_id: session,
                max_objects: 1,
            },
        )
        .await
        .unwrap_err();
    assert_eq!(error.code, ErrorCode::Conflict);
    fixture
        .db
        .verify_backup_checkpoint_named(context(), "approved", session)
        .await
        .unwrap();
    fixture.close().await;
}

#[tokio::test]
async fn aborted_session_cleanup_is_bounded_and_catches_late_uploads() {
    let fixture = Fixture::new().await;
    let session = uuid::Uuid::new_v4();
    let fault = SessionFault {
        inner: fixture.destination.clone(),
        fail_objects: true,
        fail_outcome: false,
        lose_outcome_ack: false,
    };
    let error = fixture
        .db
        .backup_checkpoint(context(), &fault, session)
        .await
        .unwrap_err();
    assert_eq!(error.code, ErrorCode::UnknownOutcome);
    let status = fixture
        .db
        .abort_backup_session(
            context(),
            AbortBackupSession {
                destination: "approved".into(),
                session_id: session,
                reason: "failed upload".into(),
            },
        )
        .await
        .unwrap();
    assert!(matches!(
        status.outcome,
        Some(BackupSessionOutcome::Aborted { .. })
    ));
    for _ in 0..3 {
        fixture
            .destination
            .session_put(
                session,
                kasumi_store::BackupSessionSlot::Object(uuid::Uuid::new_v4()),
                kasumi_store::BackupUpload::received(vec![12; 100]),
            )
            .await
            .unwrap();
    }
    let request = CleanupBackupSession {
        destination: "approved".into(),
        session_id: session,
        max_objects: 2,
    };
    let first = fixture
        .db
        .cleanup_backup_session(context(), request.clone())
        .await
        .unwrap();
    assert_eq!(first.deleted_objects, 2);
    assert!(first.more_objects_observed);
    assert_eq!(
        fixture
            .db
            .cleanup_backup_session(context(), request.clone())
            .await
            .unwrap()
            .deleted_objects,
        1
    );
    fixture
        .destination
        .session_put(
            session,
            kasumi_store::BackupSessionSlot::Object(uuid::Uuid::new_v4()),
            kasumi_store::BackupUpload::received(vec![13; 100]),
        )
        .await
        .unwrap();
    assert_eq!(
        fixture
            .db
            .cleanup_backup_session(context(), request.clone())
            .await
            .unwrap()
            .deleted_objects,
        1
    );
    assert_eq!(
        fixture
            .db
            .cleanup_backup_session(context(), request)
            .await
            .unwrap()
            .deleted_objects,
        0
    );
    let status = fixture
        .db
        .backup_session_status(
            context(),
            BackupSessionRequest {
                destination: "approved".into(),
                session_id: session,
            },
        )
        .await
        .unwrap();
    assert!(matches!(
        status.outcome,
        Some(BackupSessionOutcome::Aborted { .. })
    ));
    assert_eq!(
        fixture
            .db
            .backup_checkpoint_named(context(), "approved", session)
            .await
            .unwrap_err()
            .code,
        ErrorCode::Conflict
    );
    fixture.close().await;
}

#[tokio::test]
async fn abort_resolves_published_root_before_considering_cleanup() {
    let fixture = Fixture::new().await;
    let session = uuid::Uuid::new_v4();
    let fault = SessionFault {
        inner: fixture.destination.clone(),
        fail_objects: false,
        fail_outcome: true,
        lose_outcome_ack: false,
    };
    assert_eq!(
        fixture
            .db
            .backup_checkpoint(context(), &fault, session)
            .await
            .unwrap_err()
            .code,
        ErrorCode::UnknownOutcome
    );
    assert_eq!(
        fixture
            .db
            .verify_backup_checkpoint_named(context(), "approved", session)
            .await
            .unwrap_err()
            .code,
        ErrorCode::UnknownOutcome
    );
    let status = fixture
        .db
        .abort_backup_session(
            context(),
            AbortBackupSession {
                destination: "approved".into(),
                session_id: session,
                reason: "resolve interrupted completion".into(),
            },
        )
        .await
        .unwrap();
    assert!(matches!(
        status.outcome,
        Some(BackupSessionOutcome::Complete { .. })
    ));
    fixture
        .db
        .verify_backup_checkpoint_named(context(), "approved", session)
        .await
        .unwrap();
    fixture.close().await;
}

#[tokio::test]
async fn local_restore_binds_exact_source_purpose_even_without_cold_archives() {
    let fixture = Fixture::new().await;
    let proof = fixture
        .db
        .backup_checkpoint_named(context(), "approved", uuid::Uuid::new_v4())
        .await
        .unwrap();
    let node = fixture
        .physical
        .storage
        .create_new(
            fixture.directory.path().join("restore.kv"),
            kasumi_store::test_utils::NODE_STORE_ID,
        )
        .unwrap();
    let target = TenantStore::initialize_catalog_fixture(
        node.clone(),
        "checkpoint".into(),
        Arc::new(LocalKeyProvider::new([0xD8; 32])),
    )
    .await
    .unwrap();
    let domains = kasumi_store::test_utils::initialize_custody_fixture(
        target,
        Arc::new(LocalKeyProvider::new([241; 32])),
    )
    .await
    .unwrap();
    let source = kasumi_engine::RestoreSource {
        destination_alias: "approved".into(),
        destination: fixture.destination.clone(),
        keys: Arc::new(LocalKeyProvider::new([0xD8; 32])),
        timeout_ms: 60_000,
    };
    let request =
        common::local_restore_request(context(), proof.checkpoint(), uuid::Uuid::new_v4());
    let mut wrong =
        common::local_restore_request(context(), proof.checkpoint(), request.target_incarnation);
    wrong.source_purpose = kasumi_store::StoragePurpose::Standalone {
        installation_id: uuid::Uuid::new_v4(),
        tenant: "checkpoint".into(),
        incarnation: uuid::Uuid::parse_str(proof.source_incarnation()).unwrap(),
    };
    let error = kasumi_engine::restore_local(
        &source,
        domains.clone(),
        wrong,
        fixture.audit.admission().clone(),
        fixture.audit.clone(),
    )
    .await
    .err()
    .unwrap();
    assert!(format!("{error:#}").contains("local backup source purpose differs"));
    let restored = kasumi_engine::restore_local(
        &source,
        domains,
        request,
        fixture.audit.admission().clone(),
        fixture.audit.clone(),
    )
    .await
    .unwrap();
    restored.shutdown().await.unwrap();
    node.shutdown().await.unwrap();
    fixture.close().await;
}

#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn archived_audit_backup_is_self_contained_and_source_unavailable_restore_preserves_exact_chain()
 {
    let fixture = Fixture::with_limits(Limits {
        audit_retention: AuditRetentionBudget {
            hot_bytes: 128 << 10,
            archive_bytes: 8 << 20,
        },
        ..Limits::default()
    })
    .await;
    for round in 0..2 {
        while {
            let generation = fixture.db.engine().generation().unwrap();
            generation.state.audit_retention.hot_bytes
                < generation.state.limits.audit_retention.starts_at()
        } {
            let revision = fixture.db.engine().generation().unwrap().state.revision;
            let command = Command {
                context: context(),
                timestamp_ms: 1_000,
                operation: Operation::Audit(AuditEvent {
                    event_id: format!("{round}/{revision}/{}", "x".repeat(2_000)),
                    principal: "owner".into(),
                    action: "read".into(),
                    request_id: context().request_id,
                    timestamp_ms: 1_000,
                    data_revision: Some(revision),
                    outcome: "authorized_release".into(),
                    collection: None,
                }),
            };
            let result = fixture
                .db
                .raft_group()
                .write(serde_json::to_vec(&command).unwrap())
                .await
                .unwrap();
            serde_json::from_slice::<Result<WriteReceipt>>(&result)
                .unwrap()
                .unwrap();
        }
        let engine = fixture.db.engine().clone();
        let command = tokio::task::spawn_blocking(move || engine.prepare_audit_prune())
            .await
            .unwrap()
            .unwrap()
            .unwrap();
        let result = fixture.db.raft_group().write(command).await.unwrap();
        serde_json::from_slice::<Result<()>>(&result)
            .unwrap()
            .unwrap();
    }
    let retained = fixture
        .db
        .engine()
        .generation()
        .unwrap()
        .state
        .audit_retention
        .clone();
    assert_eq!(retained.archive_segments, 2);
    let proof = fixture
        .db
        .backup_checkpoint_named(context(), "approved", uuid::Uuid::new_v4())
        .await
        .unwrap();
    let head = retained.archive_head.as_ref().unwrap();
    let objects =
        kasumi_store::BackupSessionObjects::new(fixture.destination.as_ref(), proof.backup_id())
            .unwrap();
    let ciphertext = objects
        .get(head.object.object_id, MAX_AUDIT_SEGMENT_BYTES)
        .await
        .unwrap();
    assert_eq!(
        hex::encode(Sha256::digest(&ciphertext)),
        head.object.ciphertext_sha256
    );
    let missing = Arc::new(FaultyObjectRead::new(
        fixture.destination.clone(),
        proof.backup_id(),
        head.object.object_id,
        ObjectReadFault::Missing,
    ));
    assert!(
        fixture
            .db
            .verify_backup_checkpoint(context(), missing.as_ref(), proof.backup_id())
            .await
            .is_err()
    );
    missing.assert_read();
    // Restore must neither consult a live source quorum nor its local cache.
    fixture.close().await;
    let target_directory = kasumi_store::test_utils::private_tempdir().unwrap();
    let target_physical = common::PhysicalFixture::new(
        &target_directory.path().join("target.kv"),
        Default::default(),
    );
    let node = target_physical
        .storage
        .create_new(
            target_directory.path().join("target.kv"),
            kasumi_store::test_utils::NODE_STORE_ID,
        )
        .unwrap();
    let target_audit =
        common::security_audit(node.clone(), target_physical.storage.admission.clone()).await;
    let target = TenantStore::initialize_catalog_fixture(
        node.clone(),
        "checkpoint".into(),
        Arc::new(LocalKeyProvider::new([0xD8; 32])),
    )
    .await
    .unwrap();
    // Assemble the target domains without any tenant audit placement; the
    // placement is installed explicitly only after a rejected restore below.
    let custody = TenantStore::initialize_catalog_fixture(
        node.clone(),
        kasumi_store::CustodyStore::catalog_name("checkpoint"),
        Arc::new(LocalKeyProvider::new([241; 32])),
    )
    .await
    .unwrap();
    let domains = kasumi_store::test_utils::with_domains(target.clone(), custody).unwrap();
    let source = kasumi_engine::RestoreSource {
        destination_alias: "approved".into(),
        destination: missing.clone(),
        keys: Arc::new(LocalKeyProvider::new([0xD8; 32])),
        timeout_ms: 60_000,
    };
    let target_incarnation = uuid::Uuid::new_v4();
    assert!(
        kasumi_engine::restore_local(
            &source,
            domains.clone(),
            common::local_restore_request(context(), proof.checkpoint(), target_incarnation),
            target_audit.admission().clone(),
            target_audit.clone()
        )
        .await
        .is_err()
    );
    missing.assert_read();
    assert!(target.scan("engine.bootstrap").unwrap().is_empty());
    let corrupt = Arc::new(FaultyObjectRead::new(
        fixture.destination.clone(),
        proof.backup_id(),
        head.object.object_id,
        ObjectReadFault::Corrupt,
    ));
    let source = kasumi_engine::RestoreSource {
        destination: corrupt.clone(),
        ..source
    };
    assert!(
        kasumi_engine::restore_local(
            &source,
            domains.clone(),
            common::local_restore_request(context(), proof.checkpoint(), target_incarnation),
            target_audit.admission().clone(),
            target_audit.clone(),
        )
        .await
        .is_err()
    );
    corrupt.assert_read();
    assert!(target.scan("engine.bootstrap").unwrap().is_empty());
    // A later healthy response resolves the remote fault without replacing an
    // enrolled inode or changing the authenticated completed backup graph.
    let source = kasumi_engine::RestoreSource {
        destination: fixture.destination.clone(),
        ..source
    };
    // Source verification alone is insufficient: an independently installed
    // target provider must also retain every original historical archive key.
    let wrong_directory = kasumi_store::test_utils::private_tempdir().unwrap();
    let wrong_physical =
        common::PhysicalFixture::new(&wrong_directory.path().join("wrong.kv"), Default::default());
    let wrong_node = wrong_physical
        .storage
        .create_new(
            wrong_directory.path().join("wrong.kv"),
            kasumi_store::test_utils::NODE_STORE_ID,
        )
        .unwrap();
    let wrong_audit =
        common::security_audit(wrong_node.clone(), wrong_physical.storage.admission.clone()).await;
    let wrong_store = TenantStore::initialize_catalog_fixture(
        wrong_node.clone(),
        "checkpoint".into(),
        Arc::new(LocalKeyProvider::new([0x47; 32])),
    )
    .await
    .unwrap();
    let wrong_domains = kasumi_store::test_utils::initialize_custody_fixture(
        wrong_store.clone(),
        Arc::new(LocalKeyProvider::new([241; 32])),
    )
    .await
    .unwrap();
    assert!(
        kasumi_engine::restore_local(
            &source,
            wrong_domains,
            common::local_restore_request(context(), proof.checkpoint(), uuid::Uuid::new_v4()),
            wrong_audit.admission().clone(),
            wrong_audit.clone(),
        )
        .await
        .is_err()
    );
    assert!(wrong_store.scan("engine.bootstrap").unwrap().is_empty());
    wrong_store.shutdown().await.unwrap();
    wrong_audit.shutdown().await.unwrap();
    wrong_node.shutdown().await.unwrap();
    // A healthy source still cannot restore archived audit dependencies into
    // a target whose placement was never installed: nothing is published and
    // no default placement is selected.
    let unplaced = kasumi_engine::restore_local(
        &source,
        domains.clone(),
        common::local_restore_request(context(), proof.checkpoint(), target_incarnation),
        target_audit.admission().clone(),
        target_audit.clone(),
    )
    .await
    .err()
    .unwrap();
    assert!(
        unplaced.chain().any(|cause| cause
            .downcast_ref::<Error>()
            .is_some_and(|error| error.code == ErrorCode::Unavailable)),
        "{unplaced:#}"
    );
    assert!(target.scan("engine.bootstrap").unwrap().is_empty());
    assert!(target.scan("engine.audit.placement").unwrap().is_empty());
    assert!(
        !target_directory
            .path()
            .join("tenant-audit-archives")
            .exists()
    );
    target.install_fixture_tenant_audit_archive().unwrap();
    let restored = kasumi_engine::restore_local(
        &source,
        domains,
        common::local_restore_request(context(), proof.checkpoint(), target_incarnation),
        target_audit.admission().clone(),
        target_audit.clone(),
    )
    .await
    .unwrap();
    let after = restored
        .engine()
        .generation()
        .unwrap()
        .state
        .audit_retention
        .clone();
    assert_eq!(after.archive_head, retained.archive_head);
    assert_eq!(after.archive_segments, retained.archive_segments);
    assert_eq!(
        target
            .tenant_audit_archive()
            .unwrap()
            .cache()
            .read_blocking(&head.object)
            .unwrap(),
        ciphertext
    );
    let copied = restored
        .backup_checkpoint_named(context(), "approved", uuid::Uuid::new_v4())
        .await
        .unwrap();
    restored
        .verify_backup_checkpoint_named(context(), "approved", copied.backup_id())
        .await
        .unwrap();
    restored.shutdown().await.unwrap();
    target_audit.shutdown().await.unwrap();
    drop(restored);
    drop(target);
    drop(target_audit);
    node.shutdown().await.unwrap();
    drop(node);
    assert_eq!(target_physical.storage.persistent.snapshot().open_files, 0);
    target_physical.storage.persistent.pause().unwrap();
    let cache_path = target_directory
        .path()
        .join("tenant-audit-archives")
        .join(format!("{}.audit", head.object.object_id));
    std::fs::remove_file(&cache_path).unwrap();
    target_physical
        .storage
        .persistent
        .reconcile(&kasumi_store::CensusCancellation::default())
        .unwrap();
    let node = target_physical
        .storage
        .open_existing(
            target_directory.path().join("target.kv"),
            kasumi_store::test_utils::NODE_STORE_ID,
        )
        .unwrap();
    let reopened_audit =
        common::existing_security_audit(node.clone(), target_physical.storage.admission.clone())
            .await;
    let reopened_store = TenantStore::open_existing_fixture(
        node.clone(),
        "checkpoint".into(),
        Arc::new(LocalKeyProvider::new([0xD8; 32])),
    )
    .await
    .unwrap();
    let reopened_domains = kasumi_store::test_utils::open_existing_custody_fixture(
        reopened_store.clone(),
        Arc::new(LocalKeyProvider::new([241; 32])),
    )
    .await
    .unwrap();
    // The custody fixture reinstalled the placement on its reopened domain;
    // this separately opened store instance installs its own explicitly.
    reopened_store
        .install_fixture_tenant_audit_archive()
        .unwrap();
    assert!(
        kasumi_engine::open_local(
            reopened_domains.clone(),
            policy(),
            Limits::default(),
            reopened_audit.clone()
        )
        .await
        .is_err(),
        "missing original bootstrap dependency must prevent serving after restart"
    );
    reopened_store
        .tenant_audit_archive()
        .unwrap()
        .cache()
        .publish_blocking(&kasumi_store::PreparedAuditSegment {
            reference: head.clone(),
            ciphertext,
        })
        .unwrap();
    let reopened = kasumi_engine::open_local(
        reopened_domains,
        policy(),
        Limits::default(),
        reopened_audit.clone(),
    )
    .await
    .unwrap();
    assert_eq!(
        reopened
            .engine()
            .generation()
            .unwrap()
            .state
            .audit_retention
            .archive_head,
        retained.archive_head
    );
    let portable = reopened
        .engine()
        .snapshot(target_physical.storage.admission.clone(), 60_000)
        .await
        .unwrap();
    let prepared = reopened
        .engine()
        .prepare_snapshot_restore(portable, target_physical.storage.admission.clone(), 60_000)
        .await
        .unwrap();
    assert_eq!(prepared.incarnation(), target_incarnation.to_string());
    reopened.shutdown().await.unwrap();
    reopened_audit.shutdown().await.unwrap();
    node.shutdown().await.unwrap();
}
