//! Portable closed retirement input carried by Raft snapshots. Publication
//! rebinds it to the receiver's custody catalog; it never copies another node's
//! key authority or grants current administrative access.
use crate::Entry;
use crate::control::{
    self, AppliedCursor, LogHeader, META, RetainedSeed, RetiredBoundary, SEEDS, load,
};
use crate::{
    BasicNode, RaftCommand, RetiredSnapshotState, RetirementLogSeed, TypeConfig, command::sha256,
};
use anyhow::{Context, Result, ensure};
use kasumi_store::{CustodyStore, TenantStore, WriteOp};
use openraft::{EntryPayload, SnapshotMeta};
use serde::{Deserialize, Serialize};

const MAX_SNAPSHOT_CUSTODY_BYTES: usize = 2 << 20;
pub(crate) const MAX_PROJECTION_BYTES: usize = 2 << 20;
const PROJECTION: &[u8] = b"snapshot_retirement";

#[derive(Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub(crate) struct SnapshotRetirement {
    pub(crate) state: RetiredSnapshotState,
    pub(crate) custody: crate::custody_tables::CustodyHead,
    pub(crate) history_sha256: String,
    #[serde(skip)]
    pub(crate) records: Option<std::sync::Arc<crate::custody_records::Records>>,
    boundary: RetiredBoundary,
    header: LogHeader,
    seed: Vec<u8>,
    bootstrap_sha256: String,
}

#[derive(Clone, Serialize, Deserialize, PartialEq, Eq)]
#[serde(deny_unknown_fields)]
struct Projection {
    meta: SnapshotMeta<u64, BasicNode>,
    snapshot_sha256: String,
    retirement: SnapshotRetirement,
}

fn encode_projection(value: &Projection) -> Result<Vec<u8>> {
    ensure!(
        crate::storage::current_snapshot_id(&value.meta.snapshot_id),
        "invalid snapshot retirement projection identity"
    );
    kasumi_types::validate_sha256(&value.snapshot_sha256)?;
    let bytes = serde_json::to_vec(value)?;
    ensure!(
        bytes.len() <= MAX_PROJECTION_BYTES,
        "snapshot retirement projection exceeds byte limit"
    );
    Ok(bytes)
}

/// Refuse an unpublishable projection before application snapshot staging
/// writes a pending manifest or any encrypted chunks. This uses only finalized
/// snapshot inputs; publication rechecks the same encoding under its gate.
pub(crate) fn preflight_projection(
    meta: &SnapshotMeta<u64, BasicNode>,
    retirement: Option<&SnapshotRetirement>,
    snapshot_sha256: &str,
) -> Result<()> {
    if let Some(retirement) = retirement {
        encode_projection(&Projection {
            meta: meta.clone(),
            snapshot_sha256: snapshot_sha256.into(),
            retirement: retirement.clone(),
        })?;
    }
    Ok(())
}

fn load_projection(store: &TenantStore) -> Result<Option<Projection>> {
    let Some(bytes) = store.get_bounded(META, PROJECTION, MAX_PROJECTION_BYTES)? else {
        return Ok(None);
    };
    let value: Projection =
        serde_json::from_slice(&bytes).context("invalid snapshot retirement projection")?;
    ensure!(
        encode_projection(&value)? == bytes,
        "noncanonical snapshot retirement projection"
    );
    Ok(Some(value))
}

impl PartialEq for SnapshotRetirement {
    fn eq(&self, other: &Self) -> bool {
        self.state == other.state
            && self.custody == other.custody
            && self.history_sha256 == other.history_sha256
            && self.boundary == other.boundary
            && self.header == other.header
            && self.seed == other.seed
            && self.bootstrap_sha256 == other.bootstrap_sha256
    }
}
impl Eq for SnapshotRetirement {}
impl SnapshotRetirement {
    pub(crate) fn verified_records(
        &self,
    ) -> Result<std::sync::Arc<crate::custody_records::Records>> {
        let records = self
            .records
            .as_ref()
            .context("custody snapshot records absent")?;
        ensure!(
            records.head == self.custody && records.sha256() == self.history_sha256,
            "custody snapshot record identity differs"
        );
        Ok(records.clone())
    }

    pub(crate) fn validate(&self, meta: &SnapshotMeta<u64, BasicNode>) -> Result<()> {
        ensure!(
            self.seed.len() <= crate::MAX_RETIREMENT_SEED_BYTES,
            "snapshot retirement seed quota exceeded"
        );
        // Reject oversized metadata without allocating a second JSON copy of a
        // hostile snapshot. Actual publication allocates only after this bound.
        struct QuotaWriter(usize);
        impl std::io::Write for QuotaWriter {
            fn write(&mut self, bytes: &[u8]) -> std::io::Result<usize> {
                self.0 = self
                    .0
                    .checked_sub(bytes.len())
                    .ok_or_else(|| std::io::Error::other("snapshot custody quota exceeded"))?;
                Ok(bytes.len())
            }
            fn flush(&mut self) -> std::io::Result<()> {
                Ok(())
            }
        }
        serde_json::to_writer(QuotaWriter(MAX_SNAPSHOT_CUSTODY_BYTES), self)?;
        self.state.validate(meta)?;
        self.custody.validate()?;
        kasumi_types::validate_sha256(&self.history_sha256)?;
        ensure!(
            self.custody.policy.origin == self.state
                && self.custody.policy.revision
                    <= self
                        .state
                        .revision_base
                        .checked_add(
                            meta.last_log_id
                                .context("custody snapshot position absent")?
                                .index
                        )
                        .context("custody snapshot revision overflow")?,
            "snapshot custody state differs from immutable origin or applied position"
        );
        kasumi_types::validate_sha256(&self.bootstrap_sha256)?;
        self.header.validate()?;
        let seed = RetirementLogSeed::decode(&self.seed)?;
        let entry: Entry<TypeConfig> = Entry {
            initialization: None,
            log_id: self.header.log_id,
            payload: EntryPayload::Normal(RaftCommand::retirement(
                seed.reconstructed_command()?,
                seed.clone(),
            )?),
        };
        self.header
            .check_entry(&entry, &crate::storage::encode_entry(&entry)?)?;
        let revision = seed
            .source()
            .revision_base
            .checked_add(self.header.log_id.index)
            .context("retirement revision overflow")?;
        seed.validate_receipt(revision, &self.boundary.receipt)?;
        ensure!(
            self.header.log_id == self.boundary.position.log_id
                && self.header.log_id.index
                    <= meta
                        .last_log_id
                        .context("retirement snapshot has no log coverage")?
                        .index
                && self.header.log_id <= meta.last_log_id.expect("checked snapshot position")
                && self.boundary.position.command_sha256 == seed.command_sha256()
                && self.boundary.seed_sha256 == sha256(&self.seed)
                && self.boundary.request == *seed.request()
                && self.state.request == self.boundary.request
                && self.state.receipt == self.boundary.receipt
                && self.state.revision_base == seed.source().revision_base,
            "snapshot retirement seed/applied boundary differs"
        );
        Ok(())
    }
    fn check_installation(&self, custody: &CustodyStore) -> Result<()> {
        let control = custody.store();
        let source = &self.state.receipt;
        ensure!(
            custody.binding().tenant() == source.tenant
                && load::<String>(control, META, b"group")?.as_deref()
                    == Some(format!("{}/{}", source.tenant, source.source_incarnation).as_str())
                && load::<String>(control, META, b"application_bootstrap_sha256")?.as_ref()
                    == Some(&self.bootstrap_sha256),
            "snapshot custody source/bootstrap differs from installed tenant"
        );
        Ok(())
    }
    fn local_seed(&self, custody: &CustodyStore) -> Result<RetainedSeed> {
        Ok(RetainedSeed {
            header: self.header.clone(),
            seed: self.seed.clone(),
            bootstrap_sha256: self.bootstrap_sha256.clone(),
            storage_binding_sha256: custody.binding().digest()?,
        })
    }
}

pub(crate) fn capture(
    custody: &CustodyStore,
    meta: &SnapshotMeta<u64, BasicNode>,
    state: Option<RetiredSnapshotState>,
) -> Result<Option<SnapshotRetirement>> {
    let Some(state) = state else {
        return Ok(None);
    };
    let boundary = control::retired_boundary(custody)?
        .context("retired snapshot lacks accepted custody boundary")?;
    let retained: RetainedSeed = load(
        custody.store(),
        SEEDS,
        &boundary.position.log_id.index.to_be_bytes(),
    )?
    .context("retired snapshot lacks original seed")?;
    let records = crate::custody_records::Records::capture(custody.store())?;
    let retirement = SnapshotRetirement {
        custody: records.head.clone(),
        history_sha256: records.sha256().into(),
        records: Some(records),
        state,
        boundary,
        header: retained.header,
        seed: retained.seed,
        bootstrap_sha256: retained.bootstrap_sha256,
    };
    retirement.validate(meta)?;
    retirement.check_installation(custody)?;
    Ok(Some(retirement))
}

pub(crate) fn check_backend(
    meta: &SnapshotMeta<u64, BasicNode>,
    retirement: Option<&SnapshotRetirement>,
    actual: Option<RetiredSnapshotState>,
) -> Result<()> {
    match (retirement, actual) {
        (None, None) => Ok(()),
        (Some(retirement), Some(actual)) => {
            retirement.validate(meta)?;
            ensure!(
                retirement.state == actual,
                "snapshot custody differs from validated application state"
            );
            Ok(())
        }
        _ => anyhow::bail!("snapshot retirement marker is missing or substituted"),
    }
}

/// Semantic closed metadata is stable across backend re-encoding. This compares
/// the complete validated capsule, not a digest of application serialization.
pub(crate) fn check_same_retirement(
    left: Option<&SnapshotRetirement>,
    right: Option<&SnapshotRetirement>,
) -> Result<()> {
    ensure!(
        left == right,
        "snapshot would substitute custody identity at the same applied position"
    );
    Ok(())
}

pub(crate) struct Installation {
    pub(crate) writes: Vec<WriteOp>,
    pub(crate) records: Option<std::sync::Arc<crate::custody_records::Records>>,
}

/// The caller publishes metadata and streamed custody tables atomically with
/// the final application snapshot manifest after complete backend validation.
pub(crate) fn installation_writes(
    custody: &CustodyStore,
    meta: &SnapshotMeta<u64, BasicNode>,
    retirement: Option<&SnapshotRetirement>,
    first_membership: Option<&control::FirstAppliedMembership>,
    initialization_association: Option<&crate::initialization_association::AssociationState>,
    backend_sha256: &str,
    snapshot_sha256: &str,
) -> Result<Installation> {
    kasumi_types::validate_sha256(backend_sha256)?;
    kasumi_types::validate_sha256(snapshot_sha256)?;
    let control = custody.store();
    let mut writes = Vec::new();
    let mut records = None;
    control::validate_snapshot_first_membership(meta, first_membership)?;
    writes.extend(crate::initialization_association::snapshot_writes(
        custody,
        meta,
        first_membership,
        initialization_association,
    )?);
    let existing_first = control::first_applied_membership(control)?;
    match (existing_first.as_ref(), first_membership) {
        (Some(existing), Some(incoming)) => ensure!(
            existing == incoming,
            "snapshot would substitute immutable first applied membership"
        ),
        (Some(existing), None) => ensure!(
            meta.last_log_id
                .is_none_or(|last| last.index < existing.header.log_id.index),
            "snapshot would erase first applied membership"
        ),
        (None, Some(incoming)) => writes.push(WriteOp::put(
            META,
            b"first_membership",
            serde_json::to_vec(incoming)?,
        )),
        (None, None) => {}
    }
    if let Some(association) =
        control::local_first_association_write(custody, existing_first.as_ref(), first_membership)?
    {
        writes.push(association);
    }
    let existing_boundary = control::retired_boundary(custody)?;
    match retirement {
        Some(retirement) => {
            retirement.validate(meta)?;
            retirement.check_installation(custody)?;
            if let Some(existing) = &existing_boundary {
                ensure!(
                    *existing == retirement.boundary,
                    "snapshot would replace permanent retirement binding"
                );
            }
            let local = retirement.local_seed(custody)?;
            if let Some(existing) = load::<RetainedSeed>(
                control,
                SEEDS,
                &retirement.header.log_id.index.to_be_bytes(),
            )? && existing != local
            {
                // A receiver may have an uncommitted conflicting candidate at
                // this index. Only a validated committed snapshot may replace it.
                let committed = control::committed_coverage(control)?;
                ensure!(
                    existing_boundary.is_none()
                        && committed.is_none_or(|id| id.index < retirement.header.log_id.index),
                    "snapshot would substitute committed retirement seed"
                );
            }
            writes.push(WriteOp::put(
                SEEDS,
                retirement.header.log_id.index.to_be_bytes(),
                serde_json::to_vec(&local)?,
            ));
            writes.push(WriteOp::put(
                META,
                b"retired_boundary",
                serde_json::to_vec(&retirement.boundary)?,
            ));
            let current_position = load::<AppliedCursor>(control, META, b"applied")?
                .and_then(|position| position.log_id());
            if current_position
                .is_none_or(|id| Some(id.index) <= meta.last_log_id.map(|id| id.index))
            {
                let replacement = crate::custody_tables::prepare_replacement(
                    control,
                    retirement.verified_records()?,
                )?;
                writes.push(replacement.head.write()?);
                records = Some(replacement);
            }
            writes.push(WriteOp::put(
                META,
                PROJECTION,
                encode_projection(&Projection {
                    meta: meta.clone(),
                    snapshot_sha256: snapshot_sha256.into(),
                    retirement: retirement.clone(),
                })?,
            ));
        }
        None => {
            // An older capture may precede a later durable retirement. It must
            // leave that boundary intact and can only cover the earlier prefix.
            if let Some(boundary) = &existing_boundary {
                ensure!(
                    meta.last_log_id
                        .is_none_or(|id| id.index < boundary.position.log_id.index),
                    "snapshot would reopen a retired source"
                );
            }
        }
    }
    let previous = load::<AppliedCursor>(control, META, b"applied")?;
    if let (Some(old), Some(new)) = (
        previous.as_ref().and_then(AppliedCursor::log_id),
        meta.last_log_id,
    ) {
        ensure!(
            old.index.cmp(&new.index) == old.cmp(&new),
            "snapshot applied position ordering differs"
        );
        if old.index == new.index {
            let previous = previous.as_ref().expect("checked applied cursor");
            let membership = match previous {
                AppliedCursor::Entry(position) => &position.membership,
                AppliedCursor::Snapshot { meta, .. } => &meta.last_membership,
            };
            ensure!(
                *membership == meta.last_membership,
                "snapshot membership differs at the same applied position"
            );
            if let Some(retirement) = retirement {
                ensure!(
                    existing_boundary.as_ref() == Some(&retirement.boundary),
                    "same-position snapshot cannot invent an accepted retirement"
                );
                ensure!(
                    control::custody_head(custody)? == retirement.custody,
                    "same-position snapshot would replace current custody state"
                );
            } else {
                ensure!(
                    existing_boundary.as_ref().is_none_or(|boundary| boundary
                        .position
                        .log_id
                        .index
                        > new.index),
                    "same-position snapshot would erase retired custody"
                );
            }
        }
    }
    if previous.as_ref().is_none_or(|previous| {
        previous.log_id().map(|id| id.index) <= meta.last_log_id.map(|id| id.index)
    }) {
        if let Some(AppliedCursor::Snapshot { meta: old, .. }) = &previous
            && old.last_log_id == meta.last_log_id
        {
            // Backends can encode the same logical image differently (e.g.
            // randomized persistent map order after restore). Each image keeps
            // its own exact digest; custody identity at this position cannot vary.
            let existing = load_projection(control)?;
            ensure!(
                old.last_membership == meta.last_membership,
                "snapshot membership differs at the same applied position"
            );
            ensure!(
                existing.as_ref().is_none_or(|value| value.meta == *old),
                "previous custody projection position differs"
            );
            check_same_retirement(existing.as_ref().map(|value| &value.retirement), retirement)?;
        }
        writes.push(WriteOp::put(
            META,
            b"applied",
            serde_json::to_vec(&AppliedCursor::Snapshot {
                meta: meta.clone(),
                backend_sha256: backend_sha256.into(),
                snapshot_sha256: snapshot_sha256.into(),
            })?,
        ));
    }
    Ok(Installation { writes, records })
}

pub(crate) fn check_published(
    custody: &CustodyStore,
    meta: &SnapshotMeta<u64, BasicNode>,
    snapshot_sha256: &str,
    retirement: Option<&SnapshotRetirement>,
    first_membership: Option<&control::FirstAppliedMembership>,
    initialization_association: Option<&crate::initialization_association::AssociationState>,
) -> Result<()> {
    control::validate_snapshot_first_membership(meta, first_membership)?;
    crate::initialization_association::check_published(
        custody,
        meta,
        first_membership,
        initialization_association,
    )?;
    let local_first = control::first_applied_membership(custody.store())?;
    match (local_first.as_ref(), first_membership) {
        (Some(local), Some(embedded)) => ensure!(
            local == embedded,
            "published snapshot first membership differs from custody"
        ),
        (Some(local), None) => ensure!(
            meta.last_log_id
                .is_none_or(|last| last.index < local.header.log_id.index),
            "published snapshot lost first membership"
        ),
        (None, Some(_)) => anyhow::bail!("published snapshot first membership is absent locally"),
        (None, None) => {}
    }
    control::local_first_association_write(custody, local_first.as_ref(), None)?;
    if let Some(retirement) = retirement {
        retirement.validate(meta)?;
        retirement.check_installation(custody)?;
        let projection =
            load_projection(custody.store())?.context("snapshot custody projection absent")?;
        ensure!(
            projection.meta == *meta
                && projection.snapshot_sha256 == snapshot_sha256
                && projection.retirement == *retirement,
            "snapshot custody projection differs from published image"
        );
        let boundary =
            control::retired_boundary(custody)?.context("snapshot retired boundary absent")?;
        ensure!(
            boundary == retirement.boundary,
            "snapshot retired boundary differs"
        );
    }
    Ok(())
}

/// Coverage for a replica that installed the seed through a snapshot rather
/// than receiving and then purging its original log header.
pub(crate) fn covers_seed(store: &TenantStore, record: &RetainedSeed) -> Result<bool> {
    let Some(projection) = load_projection(store)? else {
        return Ok(false);
    };
    projection.retirement.validate(&projection.meta)?;
    let coverage = crate::storage::load_snapshot_coverage(store)?
        .context("snapshot custody coverage absent")?;
    ensure!(
        coverage.meta == projection.meta && coverage.snapshot_sha256 == projection.snapshot_sha256,
        "retirement projection snapshot coverage differs"
    );
    kasumi_types::validate_sha256(&projection.snapshot_sha256)?;
    Ok(projection.retirement.header == record.header
        && projection.retirement.seed == record.seed
        && projection.retirement.bootstrap_sha256 == record.bootstrap_sha256)
}

/// Independently readable committed snapshot coverage, kept distinct from the
/// log store's committed cursor so a crash before Raft's log purge does not
/// fabricate physical log entries or change the log-store recovery contract.
pub(crate) fn committed_snapshot(store: &TenantStore) -> Result<Option<crate::LogId<u64>>> {
    let Some(coverage) = crate::storage::load_snapshot_coverage(store)? else {
        return Ok(None);
    };
    Ok(coverage.meta.last_log_id)
}
