//! Error types exposed by this crate.

pub mod decompose;
pub mod into_ok;
mod replication_closed;
mod streaming_error;

use std::collections::BTreeSet;
use std::error::Error;
use std::fmt;
use std::fmt::Debug;
use std::sync::Arc;
use std::time::Duration;

use anyerror::AnyError;

pub use self::replication_closed::ReplicationClosed;
pub use self::streaming_error::StreamingError;
use crate::network::RPCTypes;
use crate::node::Node;
use crate::raft::AppendEntriesResponse;
use crate::raft_types::SnapshotSegmentId;
use crate::try_as_ref::TryAsRef;
use crate::LogId;
use crate::Membership;
use crate::NodeId;
use crate::StorageError;
use crate::Vote;

/// RaftError is returned by API methods of `Raft`.
///
/// It is either a Fatal error indicating that `Raft` is no longer running, such as underlying IO
/// error, or an API error `E`.
#[derive(Debug, Clone, PartialEq, Eq, thiserror::Error)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
#[allow(clippy::large_enum_variant)]
pub enum RaftError<NID, E = Infallible>
where
    NID: NodeId,
{
    #[error(transparent)]
    APIError(E),

    // Reset serde trait bound for NID but not for E
    #[cfg_attr(feature = "serde", serde(bound = ""))]
    #[error(transparent)]
    Fatal(#[from] Fatal<NID>),
}

impl<NID, E> RaftError<NID, E>
where
    NID: NodeId,
    E: Debug,
{
    /// Return a reference to Self::APIError.
    pub fn api_error(&self) -> Option<&E> {
        match self {
            RaftError::APIError(e) => Some(e),
            RaftError::Fatal(_) => None,
        }
    }

    /// Try to convert self to APIError.
    pub fn into_api_error(self) -> Option<E> {
        match self {
            RaftError::APIError(e) => Some(e),
            RaftError::Fatal(_) => None,
        }
    }

    /// Return a reference to Self::Fatal.
    pub fn fatal(&self) -> Option<&Fatal<NID>> {
        match self {
            RaftError::APIError(_) => None,
            RaftError::Fatal(f) => Some(f),
        }
    }

    /// Try to convert self to Fatal error.
    pub fn into_fatal(self) -> Option<Fatal<NID>> {
        match self {
            RaftError::APIError(_) => None,
            RaftError::Fatal(f) => Some(f),
        }
    }

    /// Return a reference to ForwardToLeader if Self::APIError contains it.
    pub fn forward_to_leader<N>(&self) -> Option<&ForwardToLeader<NID, N>>
    where
        N: Node,
        E: TryAsRef<ForwardToLeader<NID, N>>,
    {
        match self {
            RaftError::APIError(api_err) => api_err.try_as_ref(),
            RaftError::Fatal(_) => None,
        }
    }

    /// Try to convert self to ForwardToLeader error if APIError is a ForwardToLeader error.
    pub fn into_forward_to_leader<N>(self) -> Option<ForwardToLeader<NID, N>>
    where
        N: Node,
        E: TryInto<ForwardToLeader<NID, N>>,
    {
        match self {
            RaftError::APIError(api_err) => api_err.try_into().ok(),
            RaftError::Fatal(_) => None,
        }
    }
}

impl<NID, N, E> TryAsRef<ForwardToLeader<NID, N>> for RaftError<NID, E>
where
    NID: NodeId,
    N: Node,
    E: Debug + TryAsRef<ForwardToLeader<NID, N>>,
{
    fn try_as_ref(&self) -> Option<&ForwardToLeader<NID, N>> {
        self.forward_to_leader()
    }
}

impl<NID, E> From<StorageError<NID>> for RaftError<NID, E>
where
    NID: NodeId,
{
    fn from(se: StorageError<NID>) -> Self {
        RaftError::Fatal(Fatal::from(se))
    }
}

/// Fatal is unrecoverable and shuts down raft at once.
#[derive(Debug, Clone, PartialEq, Eq, thiserror::Error)]
#[cfg_attr(
    feature = "serde",
    derive(serde::Deserialize, serde::Serialize),
    serde(bound = "")
)]
#[allow(clippy::large_enum_variant)]
pub enum Fatal<NID>
where
    NID: NodeId,
{
    #[error(transparent)]
    StorageError(#[from] StorageError<NID>),

    #[error("panicked")]
    Panicked,

    /// The retained-owner configuration cannot admit the required tasks.
    #[error(transparent)]
    TaskCapacity(#[from] TaskCapacity),

    /// The runtime cancelled the task before it returned a terminal result.
    #[error("raft task cancelled")]
    Cancelled,

    /// Raft stopped normally.
    #[error("raft stopped")]
    Stopped,
}

/// New background work cannot be admitted within the configured owner bound.
#[derive(Debug, Clone, PartialEq, Eq, thiserror::Error)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
#[error("retained task capacity exhausted (limit: {limit}, needed: {needed})")]
pub struct TaskCapacity {
    /// Configured maximum number of retained owners.
    pub limit: usize,
    /// Number of additional owners required by the new operation.
    pub needed: usize,
}

/// The network operation whose actual collector is retained.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum AuxiliaryTaskKind {
    /// One leadership check owns all of its peer futures inline.
    LeadershipRead,
    /// One campaign owns all of its vote peer futures inline.
    VoteRound,
}

/// Original failure of a retained leadership-read or vote-round collector.
#[derive(Debug)]
pub struct AuxiliaryShutdownError<NID: NodeId, J: Debug> {
    /// Non-reused sequence within this Raft instance.
    pub owner_id: u64,
    /// Operation family of the actual task.
    pub kind: AuxiliaryTaskKind,
    /// Original terminal task error.
    pub error: ShutdownTaskError<NID, J>,
}
impl<NID: NodeId, J: Debug> Clone for AuxiliaryShutdownError<NID, J> {
    fn clone(&self) -> Self {
        Self {
            owner_id: self.owner_id,
            kind: self.kind,
            error: self.error.clone(),
        }
    }
}

/// Original terminal failures of one retained replication owner.
#[derive(Debug)]
pub struct ReplicationShutdownError<NID: NodeId, J: Debug> {
    /// Stable, non-reused owner sequence within this Raft instance.
    pub owner_id: u64,
    /// Peer served by this stream.
    pub target: NID,
    /// Original replication stream failure.
    pub stream: Option<ShutdownTaskError<NID, J>>,
    /// Original snapshot sender failure, retained independently.
    pub snapshot: Option<ShutdownTaskError<NID, J>>,
}
impl<NID: NodeId, J: Debug> Clone for ReplicationShutdownError<NID, J> {
    fn clone(&self) -> Self {
        Self {
            owner_id: self.owner_id,
            target: self.target.clone(),
            stream: self.stream.clone(),
            snapshot: self.snapshot.clone(),
        }
    }
}

/// Retained incoming snapshot failures. The stream owner remains held on any
/// failure; the original I/O errors are independently available without wrapping.
#[derive(Debug, Clone)]
pub struct IncomingSnapshotShutdownError<NID: NodeId> {
    /// Exact receiving stream identifier.
    pub snapshot_id: crate::SnapshotId,
    /// Original classified receive failure.
    pub receive: Option<Arc<StorageError<NID>>>,
    /// Original classified close failure.
    pub close: Option<Arc<StorageError<NID>>>,
    /// Original receive I/O error allocation.
    pub receive_io: Option<Arc<std::io::Error>>,
    /// Original close I/O error allocation.
    pub close_io: Option<Arc<std::io::Error>>,
    /// A snapshot-data poll unwound. The caller's task owns the runtime panic;
    /// this flag prevents later polls from touching its uncertain resource.
    pub poll_panicked: bool,
}

/// Original failure of a retained storage, replication or snapshot task.
///
/// Both variants keep the original error allocation shared with the task owner.
#[derive(Debug, thiserror::Error)]
pub enum ShutdownTaskError<NID: NodeId, J: Debug> {
    /// An error returned by the actual storage operation.
    #[error("storage task failed: {0}")]
    Storage(Arc<StorageError<NID>>),
    /// The error returned by the runtime when joining the actual task.
    #[error("task join failed: {0:?}")]
    Join(Arc<J>),
}

impl<NID: NodeId, J: Debug> Clone for ShutdownTaskError<NID, J> {
    fn clone(&self) -> Self {
        match self {
            Self::Storage(error) => Self::Storage(error.clone()),
            Self::Join(error) => Self::Join(error.clone()),
        }
    }
}

impl<NID: NodeId, J: Debug> From<StorageError<NID>> for ShutdownTaskError<NID, J> {
    fn from(error: StorageError<NID>) -> Self {
        Self::Storage(Arc::new(error))
    }
}

impl<NID: NodeId, J: Debug> ShutdownTaskError<NID, J> {
    /// The original returned storage error, when the task returned an error.
    pub fn storage_error(&self) -> Option<&Arc<StorageError<NID>>> {
        match self {
            Self::Storage(error) => Some(error),
            Self::Join(_) => None,
        }
    }

    /// The original runtime error, when the task failed to return normally.
    pub fn join_error(&self) -> Option<&Arc<J>> {
        match self {
            Self::Storage(_) => None,
            Self::Join(error) => Some(error),
        }
    }
}

/// Failures observed after the retained core, ticker, storage and replication tasks join.
///
/// The original runtime errors are shared with their task owners, not converted
/// to strings or reconstructed from [`Fatal`] classifications. Repeated calls
/// return the same `Arc` allocations, including when an earlier caller was
/// cancelled while joining another task. Network/storage implementations may
/// own further resource families requiring their own custody.
#[derive(Debug, thiserror::Error)]
#[error("raft shutdown failed (core: {core:?}, core join: {core_join_error:?}, ticker join: {ticker:?}, state machine: {state_machine:?}, snapshot builder: {snapshot_builder:?}, replications: {replications:?}, auxiliary: {auxiliary:?}, incoming snapshot: {incoming_snapshot:?})")]
pub struct ShutdownError<NID: NodeId, J: Debug> {
    pub(crate) core: Option<Fatal<NID>>,
    pub(crate) core_join_error: Option<Arc<J>>,
    pub(crate) ticker: Option<Arc<J>>,
    pub(crate) state_machine: Option<ShutdownTaskError<NID, J>>,
    pub(crate) snapshot_builder: Option<ShutdownTaskError<NID, J>>,
    pub(crate) replications: Vec<ReplicationShutdownError<NID, J>>,
    pub(crate) auxiliary: Vec<AuxiliaryShutdownError<NID, J>>,
    pub(crate) incoming_snapshot: Option<IncomingSnapshotShutdownError<NID>>,
}

impl<NID: NodeId, J: Debug> Clone for ShutdownError<NID, J> {
    fn clone(&self) -> Self {
        Self {
            core: self.core.clone(),
            core_join_error: self.core_join_error.clone(),
            ticker: self.ticker.clone(),
            state_machine: self.state_machine.clone(),
            snapshot_builder: self.snapshot_builder.clone(),
            replications: self.replications.clone(),
            auxiliary: self.auxiliary.clone(),
            incoming_snapshot: self.incoming_snapshot.clone(),
        }
    }
}

impl<NID: NodeId, J: Debug> ShutdownError<NID, J> {
    /// The core task's unexpected terminal failure classification, if any.
    ///
    /// For runtime failure, [`Self::core_join_error`] retains the original error.
    pub fn core(&self) -> Option<&Fatal<NID>> {
        self.core.as_ref()
    }

    /// The exact runtime error returned when joining the core task, if any.
    ///
    /// A normal core return, including a returned storage error, has no runtime
    /// join error. Repeated shutdown calls share the same original allocation.
    pub fn core_join_error(&self) -> Option<&Arc<J>> {
        self.core_join_error.as_ref()
    }

    /// The exact runtime error returned when joining the ticker task, if any.
    ///
    /// This is retained independently of the core failure, in the ticker owner.
    pub fn ticker(&self) -> Option<&Arc<J>> {
        self.ticker.as_ref()
    }

    /// The state-machine worker's original returned or runtime failure.
    /// A worker stopped by a failed snapshot shares that child's original error.
    pub fn state_machine(&self) -> Option<&ShutdownTaskError<NID, J>> {
        self.state_machine.as_ref()
    }

    /// The snapshot builder's original returned or runtime failure.
    pub fn snapshot_builder(&self) -> Option<&ShutdownTaskError<NID, J>> {
        self.snapshot_builder.as_ref()
    }

    /// Original receive/close errors of the incoming snapshot still held by this owner.
    pub fn incoming_snapshot(&self) -> Option<&IncomingSnapshotShutdownError<NID>> {
        self.incoming_snapshot.as_ref()
    }

    /// Original failures from leadership-read and vote-round collectors.
    pub fn auxiliary(&self) -> &[AuxiliaryShutdownError<NID, J>] {
        &self.auxiliary
    }

    /// Original failures from active or retired replication owners.
    pub fn replications(&self) -> &[ReplicationShutdownError<NID, J>] {
        &self.replications
    }
}

// TODO: remove
#[derive(Debug, Clone, thiserror::Error, derive_more::TryInto, PartialEq, Eq)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub enum InstallSnapshotError {
    #[error(transparent)]
    SnapshotMismatch(#[from] SnapshotMismatch),
}

/// An error related to a is_leader request.
#[derive(Debug, Clone, thiserror::Error, derive_more::TryInto)]
#[cfg_attr(
    feature = "serde",
    derive(serde::Deserialize, serde::Serialize),
    serde(bound = "")
)]
pub enum CheckIsLeaderError<NID, N>
where
    NID: NodeId,
    N: Node,
{
    /// New leader work is closed while retained child capacity is exhausted.
    #[error(transparent)]
    TaskCapacity(#[from] TaskCapacity),

    #[error(transparent)]
    ForwardToLeader(#[from] ForwardToLeader<NID, N>),

    #[error(transparent)]
    QuorumNotEnough(#[from] QuorumNotEnough<NID>),
}

impl<NID, N> TryAsRef<ForwardToLeader<NID, N>> for CheckIsLeaderError<NID, N>
where
    NID: NodeId,
    N: Node,
{
    fn try_as_ref(&self) -> Option<&ForwardToLeader<NID, N>> {
        match self {
            Self::ForwardToLeader(f) => Some(f),
            _ => None,
        }
    }
}

/// An error related to a client write request.
#[derive(Debug, Clone, thiserror::Error, derive_more::TryInto, PartialEq, Eq)]
#[cfg_attr(
    feature = "serde",
    derive(serde::Deserialize, serde::Serialize),
    serde(bound = "")
)]
pub enum ClientWriteError<NID, N>
where
    NID: NodeId,
    N: Node,
{
    /// New leader work is closed while retained child capacity is exhausted.
    #[error(transparent)]
    TaskCapacity(#[from] TaskCapacity),

    #[error(transparent)]
    ForwardToLeader(#[from] ForwardToLeader<NID, N>),

    /// When writing a change-membership entry.
    #[error(transparent)]
    ChangeMembershipError(#[from] ChangeMembershipError<NID>),
}

impl<NID, N> TryAsRef<ForwardToLeader<NID, N>> for ClientWriteError<NID, N>
where
    NID: NodeId,
    N: Node,
{
    fn try_as_ref(&self) -> Option<&ForwardToLeader<NID, N>> {
        match self {
            Self::ForwardToLeader(f) => Some(f),
            _ => None,
        }
    }
}

/// The set of errors which may take place when requesting to propose a config change.
#[derive(Debug, Clone, PartialEq, Eq, thiserror::Error)]
#[cfg_attr(
    feature = "serde",
    derive(serde::Deserialize, serde::Serialize),
    serde(bound = "")
)]
pub enum ChangeMembershipError<NID: NodeId> {
    #[error(transparent)]
    InProgress(#[from] InProgress<NID>),

    #[error(transparent)]
    EmptyMembership(#[from] EmptyMembership),

    #[error(transparent)]
    LearnerNotFound(#[from] LearnerNotFound<NID>),
}

/// The set of errors which may take place when initializing a pristine Raft node.
#[derive(Debug, Clone, PartialEq, Eq, thiserror::Error, derive_more::TryInto)]
#[cfg_attr(
    feature = "serde",
    derive(serde::Deserialize, serde::Serialize),
    serde(bound = "")
)]
pub enum InitializeError<NID, N>
where
    NID: NodeId,
    N: Node,
{
    #[error(transparent)]
    NotAllowed(#[from] NotAllowed<NID>),

    #[error(transparent)]
    NotInMembers(#[from] NotInMembers<NID, N>),

    #[error(transparent)]
    TaskCapacity(#[from] TaskCapacity),
}

/// Error variants related to the Replication.
#[derive(Debug, thiserror::Error)]
#[allow(clippy::large_enum_variant)]
pub(crate) enum ReplicationError<NID, N>
where
    NID: NodeId,
    N: Node,
{
    #[error(transparent)]
    HigherVote(#[from] HigherVote<NID>),

    #[error(transparent)]
    Closed(#[from] ReplicationClosed),

    // TODO(xp): two sub type: StorageError / TransportError
    // TODO(xp): a sub error for just append_entries()
    #[error(transparent)]
    StorageError(#[from] StorageError<NID>),

    #[error(transparent)]
    RPCError(#[from] RPCError<NID, N>),
}

/// Error occurs when invoking a remote raft API.
#[derive(Debug, Clone, PartialEq, Eq, thiserror::Error)]
// NID already has serde bound.
// E still needs additional serde bound.
// `serde(bound="")` does not work in this case.
#[cfg_attr(
    feature = "serde",
    derive(serde::Serialize, serde::Deserialize),
    serde(bound(serialize = "E: serde::Serialize")),
    serde(bound(deserialize = "E: for <'d> serde::Deserialize<'d>"))
)]
pub enum RPCError<NID: NodeId, N: Node, E: Error = Infallible> {
    #[error(transparent)]
    Timeout(#[from] Timeout<NID>),

    /// The node is temporarily unreachable and should backoff before retrying.
    #[error(transparent)]
    Unreachable(#[from] Unreachable),

    /// The RPC payload is too large and should be split into smaller chunks.
    #[error(transparent)]
    PayloadTooLarge(#[from] PayloadTooLarge),

    /// Failed to send the RPC request and should retry immediately.
    #[error(transparent)]
    Network(#[from] NetworkError),

    #[error(transparent)]
    RemoteError(#[from] RemoteError<NID, N, E>),
}

impl<NID, N, E> RPCError<NID, N, RaftError<NID, E>>
where
    NID: NodeId,
    N: Node,
    E: Error,
{
    /// Return a reference to ForwardToLeader error if Self::RemoteError contains one.
    pub fn forward_to_leader(&self) -> Option<&ForwardToLeader<NID, N>>
    where
        E: TryAsRef<ForwardToLeader<NID, N>>,
    {
        match self {
            RPCError::Timeout(_) => None,
            RPCError::Unreachable(_) => None,
            RPCError::PayloadTooLarge(_) => None,
            RPCError::Network(_) => None,
            RPCError::RemoteError(remote_err) => remote_err.source.forward_to_leader(),
        }
    }
}

#[derive(Debug, Clone, PartialEq, Eq, thiserror::Error)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
#[error("error occur on remote peer {target}: {source}")]
pub struct RemoteError<NID: NodeId, N: Node, T: Error> {
    #[cfg_attr(feature = "serde", serde(bound = ""))]
    pub target: NID,
    #[cfg_attr(feature = "serde", serde(bound = ""))]
    pub target_node: Option<N>,
    pub source: T,
}

impl<NID: NodeId, N: Node, T: Error> RemoteError<NID, N, T> {
    pub fn new(target: NID, e: T) -> Self {
        Self {
            target,
            target_node: None,
            source: e,
        }
    }
    pub fn new_with_node(target: NID, node: N, e: T) -> Self {
        Self {
            target,
            target_node: Some(node),
            source: e,
        }
    }
}

impl<NID, N, E> From<RemoteError<NID, N, Fatal<NID>>> for RemoteError<NID, N, RaftError<NID, E>>
where
    NID: NodeId,
    N: Node,
    E: Error,
{
    fn from(e: RemoteError<NID, N, Fatal<NID>>) -> Self {
        RemoteError {
            target: e.target,
            target_node: e.target_node,
            source: RaftError::Fatal(e.source),
        }
    }
}

#[derive(Debug, Clone, PartialEq, Eq, thiserror::Error)]
#[cfg_attr(
    feature = "serde",
    derive(serde::Deserialize, serde::Serialize),
    serde(bound = "")
)]
#[error("seen a higher vote: {higher} GT mine: {sender_vote}")]
pub(crate) struct HigherVote<NID: NodeId> {
    pub(crate) higher: Vote<NID>,
    pub(crate) sender_vote: Vote<NID>,
}

/// Error that indicates a **temporary** network error and when it is returned, Openraft will retry
/// immediately.
///
/// Unlike [`Unreachable`], which indicates a error that should backoff before retrying.
#[derive(Debug, Clone, PartialEq, Eq, thiserror::Error)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
#[error("NetworkError: {source}")]
pub struct NetworkError {
    #[from]
    source: AnyError,
}

impl NetworkError {
    pub fn new<E: Error + 'static>(e: &E) -> Self {
        Self {
            source: AnyError::new(e),
        }
    }
}

/// Error indicating a node is unreachable. Retries should be delayed.
///
/// This error suggests that immediate retries are not advisable when a node is not reachable.
/// Upon encountering this error, Openraft will invoke [`backoff()`] to implement a delay before
/// attempting to resend any information.
///
/// This error is similar to [`NetworkError`] but with a key distinction: `Unreachable` advises a
/// backoff period, whereas with [`NetworkError`], Openraft may attempt an immediate retry.
///
/// [`backoff()`]: crate::network::RaftNetwork::backoff
#[derive(Debug, Clone, PartialEq, Eq, thiserror::Error)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
#[error("Unreachable node: {source}")]
pub struct Unreachable {
    #[from]
    source: AnyError,
}

impl Unreachable {
    pub fn new<E: Error + 'static>(e: &E) -> Self {
        Self {
            source: AnyError::new(e),
        }
    }
}

/// Error indicating that an RPC is too large and cannot be sent.
///
/// This is a retryable error:
/// A [`RaftNetwork`] implementation returns this error to inform Openraft to divide an
/// [`AppendEntriesRequest`] into smaller chunks.
/// Openraft will immediately retry sending in smaller chunks.
/// If the request cannot be divided(contains only one entry), Openraft interprets it as
/// [`Unreachable`].
///
/// A hint can be provided to help Openraft in splitting the request.
///
/// The application should also set an appropriate value for [`Config::max_payload_entries`]  to
/// avoid returning this error if possible.
///
/// Example:
///
/// ```ignore
/// impl<C: RaftTypeConfig> RaftNetwork<C> for MyNetwork {
///     fn append_entries(&self,
///             rpc: AppendEntriesRequest<C>,
///             option: RPCOption
///     ) -> Result<_, RPCError<C::NodeId, C::Node, RaftError<C::NodeId>>> {
///         if rpc.entries.len() > 10 {
///             return Err(PayloadTooLarge::new_entries_hint(10).into());
///         }
///         // ...
///     }
/// }
/// ```
///
/// [`RaftNetwork`]: crate::network::RaftNetwork
/// [`AppendEntriesRequest`]: crate::raft::AppendEntriesRequest
/// [`Config::max_payload_entries`]: crate::config::Config::max_payload_entries
///
/// [`InstallSnapshotRequest`]: crate::raft::InstallSnapshotRequest
/// [`Config::snapshot_max_chunk_size`]: crate::config::Config::snapshot_max_chunk_size
#[derive(Debug, Clone, PartialEq, Eq, thiserror::Error)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub struct PayloadTooLarge {
    action: RPCTypes,

    /// An optional hint indicating the anticipated number of entries.
    /// Used only for append-entries replication.
    entries_hint: u64,

    /// An optional hint indicating the anticipated size in bytes.
    /// Used for snapshot replication.
    bytes_hint: u64,

    #[source]
    source: Option<AnyError>,
}

impl fmt::Display for PayloadTooLarge {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "RPC",)?;
        write!(f, "({})", self.action)?;
        write!(f, " payload too large:",)?;

        write!(f, " hint:(")?;
        match self.action {
            RPCTypes::Vote => {
                unreachable!("vote rpc should not have payload")
            }
            RPCTypes::AppendEntries => {
                write!(f, "entries:{}", self.entries_hint)?;
            }
            RPCTypes::InstallSnapshot => {
                write!(f, "bytes:{}", self.bytes_hint)?;
            }
        }
        write!(f, ")")?;

        if let Some(s) = &self.source {
            write!(f, ", source: {}", s)?;
        }

        Ok(())
    }
}

impl PayloadTooLarge {
    /// Create a new PayloadTooLarge, with entries hint, without the causing error.
    pub fn new_entries_hint(entries_hint: u64) -> Self {
        debug_assert!(entries_hint > 0, "entries_hint should be greater than 0");

        Self {
            action: RPCTypes::AppendEntries,
            entries_hint,
            bytes_hint: u64::MAX,
            source: None,
        }
    }

    // No used yet.
    /// Create a new PayloadTooLarge, with bytes hint, without the causing error.
    #[allow(dead_code)]
    pub(crate) fn new_bytes_hint(bytes_hint: u64) -> Self {
        debug_assert!(bytes_hint > 0, "bytes_hint should be greater than 0");

        Self {
            action: RPCTypes::InstallSnapshot,
            entries_hint: u64::MAX,
            bytes_hint,
            source: None,
        }
    }

    /// Set the source error that causes this PayloadTooLarge error.
    pub fn with_source_error(mut self, e: &(impl Error + 'static)) -> Self {
        self.source = Some(AnyError::new(e));
        self
    }

    pub fn action(&self) -> RPCTypes {
        self.action
    }

    /// Get the hint for entries number.
    pub fn entries_hint(&self) -> u64 {
        self.entries_hint
    }

    // No used yet.
    #[allow(dead_code)]
    pub(crate) fn bytes_hint(&self) -> u64 {
        self.bytes_hint
    }
}

#[derive(Debug, Clone, PartialEq, Eq, thiserror::Error)]
#[cfg_attr(
    feature = "serde",
    derive(serde::Deserialize, serde::Serialize),
    serde(bound = "")
)]
#[error("timeout after {timeout:?} when {action} {id}->{target}")]
pub struct Timeout<NID: NodeId> {
    pub action: RPCTypes,
    pub id: NID,
    pub target: NID,
    pub timeout: Duration,
}

#[derive(Debug, Clone, PartialEq, Eq, thiserror::Error)]
#[cfg_attr(
    feature = "serde",
    derive(serde::Deserialize, serde::Serialize),
    serde(bound = "")
)]
#[error("store has no log at: {index:?}, last purged: {last_purged_log_id:?}")]
pub struct LackEntry<NID: NodeId> {
    pub index: Option<u64>,
    pub last_purged_log_id: Option<LogId<NID>>,
}

#[derive(Debug, Clone, PartialEq, Eq, thiserror::Error)]
#[cfg_attr(
    feature = "serde",
    derive(serde::Deserialize, serde::Serialize),
    serde(bound = "")
)]
#[error("has to forward request to: {leader_id:?}, {leader_node:?}")]
pub struct ForwardToLeader<NID, N>
where
    NID: NodeId,
    N: Node,
{
    pub leader_id: Option<NID>,
    pub leader_node: Option<N>,
}

impl<NID, N> ForwardToLeader<NID, N>
where
    NID: NodeId,
    N: Node,
{
    pub const fn empty() -> Self {
        Self {
            leader_id: None,
            leader_node: None,
        }
    }

    pub fn new(leader_id: NID, node: N) -> Self {
        Self {
            leader_id: Some(leader_id),
            leader_node: Some(node),
        }
    }
}

#[derive(Debug, Clone, PartialEq, Eq, thiserror::Error)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
#[error("snapshot segment id mismatch, expect: {expect}, got: {got}")]
pub struct SnapshotMismatch {
    pub expect: SnapshotSegmentId,
    pub got: SnapshotSegmentId,
}

#[derive(Debug, Clone, PartialEq, Eq, thiserror::Error)]
#[cfg_attr(
    feature = "serde",
    derive(serde::Deserialize, serde::Serialize),
    serde(bound = "")
)]
#[error("not enough for a quorum, cluster: {cluster}, got: {got:?}")]
pub struct QuorumNotEnough<NID: NodeId> {
    pub cluster: String,
    pub got: BTreeSet<NID>,
}

#[derive(Debug, Clone, PartialEq, Eq, thiserror::Error)]
#[cfg_attr(
    feature = "serde",
    derive(serde::Deserialize, serde::Serialize),
    serde(bound = "")
)]
#[error("the cluster is already undergoing a configuration change at log {membership_log_id:?}, last committed membership log id: {committed:?}")]
pub struct InProgress<NID: NodeId> {
    pub committed: Option<LogId<NID>>,
    pub membership_log_id: Option<LogId<NID>>,
}

#[derive(Debug, Clone, PartialEq, Eq, thiserror::Error)]
#[cfg_attr(
    feature = "serde",
    derive(serde::Deserialize, serde::Serialize),
    serde(bound = "")
)]
#[error("Learner {node_id} not found: add it as learner before adding it as a voter")]
pub struct LearnerNotFound<NID: NodeId> {
    pub node_id: NID,
}

#[derive(Debug, Clone, PartialEq, Eq, thiserror::Error)]
#[cfg_attr(
    feature = "serde",
    derive(serde::Deserialize, serde::Serialize),
    serde(bound = "")
)]
#[error("not allowed to initialize due to current raft state: last_log_id: {last_log_id:?} vote: {vote}")]
pub struct NotAllowed<NID: NodeId> {
    pub last_log_id: Option<LogId<NID>>,
    pub vote: Vote<NID>,
}

#[derive(Debug, Clone, PartialEq, Eq, thiserror::Error)]
#[cfg_attr(
    feature = "serde",
    derive(serde::Deserialize, serde::Serialize),
    serde(bound = "")
)]
#[error("node {node_id} has to be a member. membership:{membership:?}")]
pub struct NotInMembers<NID, N>
where
    NID: NodeId,
    N: Node,
{
    pub node_id: NID,
    pub membership: Membership<NID, N>,
}

#[derive(Debug, Clone, PartialEq, Eq, thiserror::Error)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
#[error("new membership can not be empty")]
pub struct EmptyMembership {}

#[derive(Debug, Clone, PartialEq, Eq, thiserror::Error)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
#[error("infallible")]
pub enum Infallible {}

/// A place holder to mark RaftError won't have a ForwardToLeader variant.
#[derive(Debug, Clone, PartialEq, Eq, thiserror::Error)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
#[error("no-forward")]
pub enum NoForward {}

#[derive(Debug, Clone, PartialEq, Eq, thiserror::Error)]
#[cfg_attr(
    feature = "serde",
    derive(serde::Deserialize, serde::Serialize),
    serde(bound = "")
)]
pub(crate) enum RejectVoteRequest<NID: NodeId> {
    #[error("reject vote request by a greater vote: {0}")]
    ByVote(Vote<NID>),

    #[allow(dead_code)]
    #[error("reject vote request by a greater last-log-id: {0:?}")]
    ByLastLogId(Option<LogId<NID>>),
}

impl<NID: NodeId> From<RejectVoteRequest<NID>> for AppendEntriesResponse<NID> {
    fn from(r: RejectVoteRequest<NID>) -> Self {
        match r {
            RejectVoteRequest::ByVote(v) => AppendEntriesResponse::HigherVote(v),
            RejectVoteRequest::ByLastLogId(_) => {
                unreachable!("the leader should always has a greater last log id")
            }
        }
    }
}

#[derive(Debug, Clone, PartialEq, Eq, thiserror::Error)]
pub(crate) enum RejectAppendEntries<NID: NodeId> {
    #[error("reject AppendEntries by a greater vote: {0}")]
    ByVote(Vote<NID>),

    #[error(
        "reject AppendEntries because of conflicting log-id: {local:?}; expect to be: {expect:?}"
    )]
    ByConflictingLogId {
        expect: LogId<NID>,
        local: Option<LogId<NID>>,
    },
}

impl<NID: NodeId> From<RejectVoteRequest<NID>> for RejectAppendEntries<NID> {
    fn from(r: RejectVoteRequest<NID>) -> Self {
        match r {
            RejectVoteRequest::ByVote(v) => RejectAppendEntries::ByVote(v),
            RejectVoteRequest::ByLastLogId(_) => {
                unreachable!("the leader should always has a greater last log id")
            }
        }
    }
}

impl<NID: NodeId> From<Result<(), RejectAppendEntries<NID>>> for AppendEntriesResponse<NID> {
    fn from(r: Result<(), RejectAppendEntries<NID>>) -> Self {
        match r {
            Ok(_) => AppendEntriesResponse::Success,
            Err(e) => match e {
                RejectAppendEntries::ByVote(v) => AppendEntriesResponse::HigherVote(v),
                RejectAppendEntries::ByConflictingLogId {
                    expect: _,
                    local: _,
                } => AppendEntriesResponse::Conflict,
            },
        }
    }
}

#[cfg(test)]
mod tests {
    use anyerror::AnyError;

    use crate::error::PayloadTooLarge;

    #[test]
    fn test_append_too_large() -> anyhow::Result<()> {
        let a = PayloadTooLarge::new_entries_hint(5);
        assert_eq!(
            "RPC(AppendEntries) payload too large: hint:(entries:5)",
            a.to_string()
        );

        let a = PayloadTooLarge::new_bytes_hint(5);
        assert_eq!(
            "RPC(InstallSnapshot) payload too large: hint:(bytes:5)",
            a.to_string()
        );

        let a = PayloadTooLarge::new_entries_hint(5).with_source_error(&AnyError::error("test"));
        assert_eq!(
            "RPC(AppendEntries) payload too large: hint:(entries:5), source: test",
            a.to_string()
        );

        Ok(())
    }
}
