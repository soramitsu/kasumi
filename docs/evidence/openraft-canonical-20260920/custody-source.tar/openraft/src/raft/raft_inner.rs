use std::fmt;
use std::fmt::Debug;
use std::future::Future;
use std::sync::Arc;
use std::time::Duration;

use tokio::sync::mpsc;
use tokio::sync::watch;
use tokio::sync::Mutex;
use tracing::Level;

use crate::config::RuntimeConfig;
use crate::core::raft_msg::external_command::ExternalCommand;
use crate::core::raft_msg::RaftMsg;
use crate::core::TickHandle;
use crate::error::Fatal;
use crate::error::RaftError;
use crate::metrics::RaftDataMetrics;
use crate::metrics::RaftServerMetrics;
use crate::raft::core_state::CoreOutcome;
use crate::raft::core_state::CoreState;
use crate::type_config::alias::OneshotSenderOf;
use crate::AsyncRuntime;
use crate::Config;
use crate::MessageSummary;
use crate::OptionalSend;
use crate::RaftMetrics;
use crate::RaftTypeConfig;

/// How long a caller waits for `RaftCore` to actually stop after a response channel closed,
/// before concluding the channel was closed by a dropped responder instead.
///
/// A real stop is observable almost immediately: `RaftCore` reports it in metrics and drops the
/// metrics sender as its task ends. This only needs to tolerate scheduling latency, not an actual
/// shutdown, and solely bounds how long a caller waits on the dropped-responder path.
const RECV_CORE_STOP_TIMEOUT: Duration = Duration::from_secs(1);

/// RaftInner is the internal handle and provides internally used APIs to communicate with
/// `RaftCore`.
pub(in crate::raft) struct RaftInner<C>
where
    C: RaftTypeConfig,
{
    pub(in crate::raft) id: C::NodeId,
    pub(in crate::raft) config: Arc<Config>,
    pub(in crate::raft) runtime_config: Arc<RuntimeConfig>,
    pub(in crate::raft) membership_observer:
        Arc<crate::membership_observer::MembershipObserverSlot>,
    pub(in crate::raft) tick_handle: TickHandle<C>,
    pub(in crate::raft) replication_tasks: Arc<crate::replication::tasks::Registry<C>>,
    pub(crate) auxiliary_tasks: Arc<crate::core::auxiliary::Registry<C>>,
    pub(in crate::raft) state_machine_tasks: crate::core::sm::tasks::Tasks<C>,
    pub(in crate::raft) tx_api: mpsc::UnboundedSender<RaftMsg<C>>,
    pub(in crate::raft) tx_notify: mpsc::UnboundedSender<crate::core::notify::Notify<C>>,
    pub(in crate::raft) rx_metrics: watch::Receiver<RaftMetrics<C::NodeId, C::Node>>,
    pub(in crate::raft) rx_data_metrics: watch::Receiver<RaftDataMetrics<C::NodeId>>,
    pub(in crate::raft) rx_server_metrics: watch::Receiver<RaftServerMetrics<C::NodeId, C::Node>>,

    // TODO(xp): it does not need to be a async mutex.
    #[allow(clippy::type_complexity)]
    pub(in crate::raft) tx_shutdown: Mutex<Option<OneshotSenderOf<C, ()>>>,
    pub(in crate::raft) core_state: Mutex<CoreState<C::NodeId, C::AsyncRuntime>>,

    /// The ongoing snapshot transmission.
    pub(in crate::raft) snapshot: Mutex<Option<crate::network::snapshot_transport::Streaming<C>>>,
}

impl<C> RaftInner<C>
where
    C: RaftTypeConfig,
{
    /// Send a RaftMsg to RaftCore
    pub(crate) async fn send_msg(&self, mes: RaftMsg<C>) -> Result<(), Fatal<C::NodeId>> {
        let send_res = self.tx_api.send(mes);

        if let Err(e) = send_res {
            let fatal = self
                .get_core_stopped_error("sending RaftMsg to RaftCore", Some(e.0.summary()))
                .await;
            return Err(fatal);
        }
        Ok(())
    }

    /// Receive a message from RaftCore, return error if RaftCore has stopped.
    pub(crate) async fn recv_msg<T, E>(
        &self,
        rx: impl Future<Output = Result<T, E>>,
    ) -> Result<T, Fatal<C::NodeId>>
    where
        T: OptionalSend,
        E: OptionalSend,
    {
        let recv_res = rx.await;
        tracing::debug!(
            "{} receives result is error: {:?}",
            func_name!(),
            recv_res.is_err()
        );

        match recv_res {
            Ok(x) => Ok(x),
            Err(_) => {
                let fatal = self
                    .get_core_stopped_error_bounded(
                        "receiving rx from RaftCore",
                        None::<&'static str>,
                    )
                    .await;
                tracing::error!(error = debug(&fatal), "error when {}", func_name!());
                Err(fatal)
            }
        }
    }

    /// Invoke RaftCore by sending a RaftMsg and blocks waiting for response.
    #[tracing::instrument(level = "debug", skip_all)]
    pub(crate) async fn call_core<T, E>(
        &self,
        mes: RaftMsg<C>,
        rx: <C::AsyncRuntime as AsyncRuntime>::OneshotReceiver<Result<T, E>>,
    ) -> Result<T, RaftError<C::NodeId, E>>
    where
        E: Debug + OptionalSend,
        T: OptionalSend,
    {
        let sum = if tracing::enabled!(Level::DEBUG) {
            Some(mes.summary())
        } else {
            None
        };

        self.send_msg(mes).await?;

        let recv_res = rx.await;
        tracing::debug!(
            "call_core receives result is error: {:?}",
            recv_res.is_err()
        );

        match recv_res {
            Ok(x) => x.map_err(|e| RaftError::APIError(e)),
            Err(_) => {
                let fatal = self
                    .get_core_stopped_error_bounded("receiving rx from RaftCore", sum)
                    .await;
                tracing::error!(error = debug(&fatal), "core_call fatal error");
                Err(RaftError::Fatal(fatal))
            }
        }
    }

    /// Send an [`ExternalCommand`] to RaftCore to execute in the `RaftCore` thread.
    ///
    /// It returns at once.
    pub(in crate::raft) async fn send_external_command(
        &self,
        cmd: ExternalCommand<C>,
        cmd_desc: impl fmt::Display + Default,
    ) -> Result<(), Fatal<C::NodeId>> {
        let send_res = self.tx_api.send(RaftMsg::ExternalCommand { cmd });

        if send_res.is_err() {
            let fatal = self
                .get_core_stopped_error("sending external command to RaftCore", Some(cmd_desc))
                .await;
            return Err(fatal);
        }
        Ok(())
    }

    /// Get the error for a response channel that closed without delivering a reply.
    ///
    /// Usually this means RaftCore has stopped, and the error that stopped it is returned. But a
    /// malfunctioning state machine can drop a responder without replying while RaftCore is still
    /// running, and joining the core then would block forever. The wait is therefore bounded: if
    /// the core has not stopped, the dropped responder is itself the failure and
    /// [`Fatal::Stopped`] is returned at once.
    async fn get_core_stopped_error_bounded(
        &self,
        when: impl fmt::Display,
        message_summary: Option<impl fmt::Display + Default>,
    ) -> Fatal<C::NodeId> {
        if self.wait_core_stopped(RECV_CORE_STOP_TIMEOUT).await {
            return self.get_core_stopped_error(when, message_summary).await;
        }

        tracing::error!(
            "response dropped without a reply while RaftCore is running, when: {}",
            when
        );
        Fatal::Stopped
    }

    /// Wait up to `timeout` for RaftCore to stop, without joining (and thus consuming) it.
    ///
    /// This observes the metrics watch channel, a non-destructive signal that is safe to poll from
    /// any number of callers: RaftCore sets [`running_state`](RaftMetrics::running_state) to `Err`
    /// when it stops, and the metrics sender is dropped when its task ends, including on a panic.
    /// Either is a reliable indication that the core has stopped.
    ///
    /// Returns `true` if a stop was observed, `false` if the core is still running after
    /// `timeout`.
    async fn wait_core_stopped(&self, timeout: Duration) -> bool {
        let mut rx = self.rx_metrics.clone();

        let observe = async move {
            loop {
                if rx.borrow().running_state.is_err() {
                    return;
                }

                // `changed()` returns an error only when the metrics sender is dropped,
                // i.e. the RaftCore task has ended.
                if rx.changed().await.is_err() {
                    return;
                }
            }
        };

        C::AsyncRuntime::timeout(timeout, observe).await.is_ok()
    }

    /// Get the error that caused RaftCore to stop.
    pub(in crate::raft) async fn get_core_stopped_error(
        &self,
        when: impl fmt::Display,
        message_summary: Option<impl fmt::Display + Default>,
    ) -> Fatal<C::NodeId> {
        // Wait for the core task to finish.
        let error = self.join_core_task().await.fatal;

        tracing::error!(
            core_result = debug(&error),
            "failure {}; message: {}",
            when,
            message_summary.unwrap_or_default()
        );

        error
    }

    /// Wait for `RaftCore` task to finish and record the returned value from the task.
    #[tracing::instrument(level = "debug", skip_all)]
    pub(in crate::raft) async fn join_core_task(&self) -> CoreOutcome<C::NodeId, C::AsyncRuntime> {
        let mut state = self.core_state.lock().await;
        match &mut *state {
            CoreState::Running(handle) => {
                let res = handle.await;
                tracing::info!(res = debug(&res), "RaftCore exited");

                let outcome = match res {
                    Err(error) => {
                        let fatal = if C::AsyncRuntime::is_panic(&error) {
                            Fatal::Panicked
                        } else {
                            Fatal::Cancelled
                        };
                        CoreOutcome {
                            fatal,
                            join_error: Some(Arc::new(error)),
                        }
                    }
                    Ok(returned_res) => CoreOutcome {
                        fatal: returned_res.unwrap_err(),
                        join_error: None,
                    },
                };

                // No yield between observing completion and retaining its
                // original runtime error. All later joiners share this cell.
                *state = CoreState::Done(outcome);
            }
            CoreState::Done(_) => {
                // RaftCore has already quit, nothing to do
            }
        }
        let CoreState::Done(outcome) = &*state else {
            unreachable!("RaftCore was joined above")
        };
        outcome.clone()
    }
}
