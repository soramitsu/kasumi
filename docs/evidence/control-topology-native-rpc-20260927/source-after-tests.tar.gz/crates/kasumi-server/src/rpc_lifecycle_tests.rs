use super::*;
use base64::{Engine, engine::general_purpose::URL_SAFE_NO_PAD};
use kasumi_client::{KasumiClientConfig, KasumiLifecycleClient};
use kasumi_engine::{LifecycleSigner, ReplicaPlacement, ReplicatedBootstrap};
use kasumi_serving::{ControlTrust, digest};
use kasumi_store::{StorageAccess, TenantStorageSet, TenantStore, test_utils::LocalKeyProvider};
use kasumi_transport::ClientAuthentication;
use kasumi_types::*;
use serde_json::json;
use std::{
    collections::{BTreeMap, BTreeSet},
    time::Duration,
};
use uuid::Uuid;

// This fixture's native TLS listeners isolate the request and receipt path
// from per-connection durable audit latency. The Authenticator and Control
// Raft retain their real SecurityAudit; only this listener sink changes.
struct FixtureListenerAudit;
#[async_trait::async_trait]
impl crate::tls::TlsHandshakeAudit for FixtureListenerAudit {
    async fn record(&self, _: &crate::tls::TlsHandshakeEvent) -> anyhow::Result<()> {
        Ok(())
    }
}

#[tokio::test(flavor = "multi_thread", worker_threads = 4)]
async fn pinned_native_control_signs_actual_quorum_commitments_and_rejects_wrong_resource_and_partition()
 {
    let directory = kasumi_store::test_utils::private_tempdir().unwrap();
    let (ca, server_identity, mut identities) = super::authority_tests::certificates();
    let jwtkey = rcgen::KeyPair::generate_for(&rcgen::PKCS_ED25519).unwrap();
    let jwks=serde_json::from_value(json!({"keys":[{"kty":"OKP","crv":"Ed25519","alg":"EdDSA","use":"sig","kid":"control-auth","x":URL_SAFE_NO_PAD.encode(jwtkey.public_key_raw())}]})).unwrap();
    let auth = Authenticator::with_test_keys(
        crate::auth::AuthConfig {
            issuer: "https://identity.example".into(),
            audience: "https://control.example".into(),
            source: crate::auth::AuthKeySource::ExternalOAuth {
                jwks_uri: "https://identity.example/keys".into(),
                trusted_ca_pem: None,
            },
            algorithms: vec![jsonwebtoken::Algorithm::EdDSA],
            access_token_types: BTreeSet::from(["at+jwt".into()]),
        },
        jwks,
    )
    .await;
    kasumi_store::private_files::create_directory(&directory.path().join("control")).unwrap();
    let physical = crate::runtime_storage_fixtures::physical(
        &directory.path().join("control"),
        Default::default(),
    )
    .unwrap();
    let audit_node = physical
        .create_new(
            directory.path().join("control/persistent/audit.kv"),
            kasumi_store::test_utils::NODE_STORE_ID,
        )
        .unwrap();
    let mut physical_nodes = vec![audit_node.clone()];
    let audit_store = TenantStore::initialize_catalog(
        audit_node,
        kasumi_engine::SECURITY_TENANT.into(),
        Arc::new(LocalKeyProvider::new([88; 32])),
        StorageAccess::security_audit(),
    )
    .await
    .unwrap();
    let audit = kasumi_engine::SecurityAudit::initialize(
        audit_store.clone(),
        kasumi_types::AuditRetentionBudget::default(),
        physical.admission.clone(),
    )
    .unwrap();
    auth.install_audit(audit.clone()).unwrap();
    let incarnation = Uuid::new_v4();
    let key = rcgen::KeyPair::generate_for(&rcgen::PKCS_ED25519).unwrap();
    let root = ControlSigningRoot {
        control_incarnation: incarnation,
        public_key: hex::encode(key.public_key_raw()),
    };
    let signer = Arc::new(LifecycleSigner::from_pkcs8(root.clone(), &key.serialize_der()).unwrap());
    let issuer_key = rcgen::KeyPair::generate_for(&rcgen::PKCS_ED25519).unwrap();
    let issuer_root =
        kasumi_serving::test_utils::FixtureSigningRoot::from_pkcs8(&issuer_key.serialize_der())
            .unwrap();
    let manifest = kasumi_serving::AuthorityManifest {
        authority_id: Uuid::new_v4(),
        lifecycle_controls: BTreeMap::from([(incarnation, root.public_key.clone())]),
        partitions: BTreeMap::from([(
            0,
            kasumi_serving::AuthorityPartition {
                group: "lifecycle-issuer".into(),
                public_key: issuer_root.public_key(),
            },
        )]),
        // This fixture hosts six Raft nodes plus native TLS on one process.
        // Leave enough real elapsed lifetime for quorum observations under CI
        // scheduling pressure; the issuer's complete drain is still exercised.
        max_lease_ms: 5000,
        clock_rate_error_ppm: 0,
    };
    let issuer_signing = issuer_root.install(manifest.clone(), 0).unwrap();
    let issuer_trust = issuer_signing.trust.clone();
    let partition = manifest.control_partition(0).unwrap();
    let issuer_install = kasumi_authority::AuthorityInstallation {
        manifest: manifest.clone(),
        partition: 0,
    };
    let issuer_router = Arc::new(kasumi_raft::InProcessRouter::default());
    let mut issuers = Vec::new();
    for id in 1..=3 {
        let issuer_root = directory.path().join(format!("issuer-{id}"));
        kasumi_store::private_files::create_directory(&issuer_root).unwrap();
        let issuer_physical =
            crate::runtime_storage_fixtures::physical(&issuer_root, Default::default()).unwrap();
        let node = issuer_physical
            .create_new(
                issuer_root.join("persistent/issuer.kv"),
                kasumi_store::test_utils::NODE_STORE_ID,
            )
            .unwrap();
        physical_nodes.push(node.clone());
        let stores = TenantStorageSet::initialize_catalogs(
            node,
            issuer_install.tenant(),
            Arc::new(LocalKeyProvider::new([id as u8 + 50; 32])),
            Arc::new(LocalKeyProvider::new([id as u8 + 60; 32])),
            StorageAccess::independent_authority(&manifest, 0).unwrap(),
        )
        .await
        .unwrap();
        let bootstrap = kasumi_authority::AuthorityBootstrap {
            initial_signer_certificate: issuer_signing.signer.certificate().clone(),
            administrators: BTreeSet::from(["operator".into()]),
            capacity: kasumi_serving::AuthorityCapacity {
                max_tenants: 10,
                max_state_bytes: 4 << 20,
                maintenance_reserve_bytes: 1 << 20,
            },
            membership: kasumi_serving::AuthorityMembership {
                voters: BTreeSet::from([1, 2, 3]),
                members: (1..=3)
                    .map(|n| {
                        (
                            n,
                            kasumi_serving::AuthorityMember {
                                verifier: kasumi_serving::test_utils::fixture_verifier(n),
                                endpoint: format!("https://authority-{n}.test"),
                                failure_domain: format!("domain-{n}"),
                                certificate_pins: BTreeSet::from([format!("{n:064x}")]),
                            },
                        )
                    })
                    .collect(),
            },
        };
        kasumi_authority::IndependentAuthority::initialize_storage(
            &stores,
            &issuer_install,
            &bootstrap,
            &kasumi_serving::test_utils::fixture_verifier(id),
        )
        .unwrap();
        let issuer = kasumi_authority::IndependentAuthority::open_existing_replicated(
            stores,
            issuer_install.clone(),
            issuer_signing
                .for_verifier(kasumi_serving::test_utils::fixture_verifier(id))
                .unwrap()
                .signer,
            id,
            kasumi_authority::AuthorityNodeSettings {
                resource_budget_bytes: 4 << 20,
                installed_members: (1..=3)
                    .map(|n| {
                        (
                            n,
                            kasumi_serving::AuthorityMember {
                                verifier: kasumi_serving::test_utils::fixture_verifier(n),
                                endpoint: format!("https://authority-{n}.test"),
                                failure_domain: format!("domain-{n}"),
                                certificate_pins: BTreeSet::from([format!("{n:064x}")]),
                            },
                        )
                    })
                    .collect(),
            },
            issuer_router.clone(),
            kasumi_raft::server_config(),
            crate::authority_runtime::request_budget(&issuer_physical.admission).unwrap(),
            issuer_physical.admission.snapshot_buffer_owner().unwrap(),
        )
        .await
        .unwrap();
        issuer_router.register(
            "lifecycle-issuer".into(),
            id,
            issuer.raft_group().raft().clone(),
        );
        issuers.push(issuer);
    }
    issuers[0].initialize().await.unwrap();
    let issuer = tokio::time::timeout(Duration::from_secs(30), async {
        loop {
            for issuer in &issuers {
                let m = issuer.raft_group().raft().metrics().borrow().clone();
                if m.current_leader == Some(m.id)
                    && matches!(
                        tokio::time::timeout(
                            Duration::from_secs(2),
                            issuer.raft_group().linearizable_barrier()
                        )
                        .await,
                        Ok(Ok(_))
                    )
                {
                    return issuer.clone();
                }
            }
            tokio::time::sleep(Duration::from_millis(10)).await;
        }
    })
    .await
    .unwrap_or_else(|_| {
        panic!(
            "issuer quorum readiness timed out: {:?}",
            issuers
                .iter()
                .map(|issuer| issuer.raft_group().raft().metrics().borrow().clone())
                .collect::<Vec<_>>()
        )
    });
    let installation = LifecycleInstallation {
        root: root.clone(),
        generation: 1,
        partitions: BTreeMap::from([(partition.key(), partition.clone())]),
        max_intents: 100,
        max_changes: 10,
        max_state_bytes: 1 << 20,
    };
    let policy = Policy {
        grants: vec![
            Grant {
                principal: "operator".into(),
                collection: None,
                actions: BTreeSet::from([Action::Admin, Action::Read, Action::Write]),
            },
            Grant {
                principal: "router".into(),
                collection: Some("topology".into()),
                actions: BTreeSet::from([Action::Read]),
            },
        ],
        strict_read_audit: true,
    };
    let installation_command_id = Uuid::new_v4();
    let bootstrap = ReplicatedBootstrap {
        genesis: kasumi_engine::ReplicatedGenesis::Control(kasumi_engine::ControlGenesis {
            topology: kasumi_engine::control::ControlTopology {
                nodes: (1..=3)
                    .map(|id| {
                        (
                            id,
                            kasumi_engine::control::ControlNode {
                                endpoint: format!("https://control-{id}.example"),
                                failure_domain: format!("zone-{id}"),
                                certificate_pins: BTreeSet::from([format!("{id:064x}")]),
                            },
                        )
                    })
                    .collect(),
                tenants: BTreeMap::new(),
            },
            lifecycle: kasumi_engine::ControlLifecycleGenesis::Installed {
                command_id: installation_command_id,
                installation: installation.clone(),
            },
        }),
        incarnation: incarnation.to_string(),
        initial_policy: policy.clone(),
        initial_limits: Limits::default(),
        voters: (1..=3)
            .map(|id| {
                (
                    id,
                    ReplicaPlacement {
                        address: format!("https://control-{id}.example"),
                        failure_domain: format!("zone-{id}"),
                    },
                )
            })
            .collect(),
    };
    let router = Arc::new(kasumi_raft::InProcessRouter::default());
    let group = format!("__kasumi_control/{incarnation}");
    let mut nodes = Vec::new();
    for id in 1..=3 {
        let node = physical
            .create_new(
                directory
                    .path()
                    .join(format!("control/persistent/node-{id}.kv")),
                kasumi_store::test_utils::NODE_STORE_ID,
            )
            .unwrap();
        physical_nodes.push(node.clone());
        let stores = TenantStorageSet::initialize_catalogs(
            node,
            "__kasumi_control".into(),
            Arc::new(LocalKeyProvider::new([id as u8; 32])),
            Arc::new(LocalKeyProvider::new([id as u8 + 10; 32])),
            StorageAccess::node_control(),
        )
        .await
        .unwrap();
        kasumi_store::test_utils::install_fixture_audit_placement(stores.application()).unwrap();
        let db = kasumi_engine::open_replicated(
            id,
            stores,
            &bootstrap,
            router.clone(),
            kasumi_raft::server_config(),
            audit.clone(),
        )
        .await
        .unwrap();
        router.register(group.clone(), id, db.raft_group().raft().clone());
        nodes.push(db);
    }
    kasumi_engine::initialize_replicated(&nodes[0], &bootstrap)
        .await
        .unwrap();
    let leader = tokio::time::timeout(Duration::from_secs(30), async {
        loop {
            for node in &nodes {
                let metric = node.raft_group().raft().metrics().borrow().clone();
                if metric.current_leader == Some(metric.id)
                    && matches!(
                        tokio::time::timeout(
                            Duration::from_secs(2),
                            node.raft_group().linearizable_barrier()
                        )
                        .await,
                        Ok(Ok(_))
                    )
                {
                    return node.clone();
                }
            }
            tokio::time::sleep(Duration::from_millis(10)).await;
        }
    })
    .await
    .unwrap_or_else(|_| {
        panic!(
            "Control quorum readiness timed out: {:?}",
            nodes
                .iter()
                .map(|node| node.raft_group().raft().metrics().borrow().clone())
                .collect::<Vec<_>>()
        )
    });
    let socket = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
    let endpoint = format!("https://localhost:{}", socket.local_addr().unwrap().port());
    let pin = server_identity.certificate_pin();
    let tls = kasumi_transport::server_config(
        &server_identity,
        ClientAuthentication::Required {
            trusted_ca_pem: ca.as_bytes(),
        },
    )
    .unwrap();
    let first_lifecycle_response = Arc::new(std::sync::atomic::AtomicBool::new(false));
    let primary_handler_body_consumed = Arc::new(std::sync::atomic::AtomicBool::new(false));
    let lifecycle_pool_active = Arc::new(std::sync::atomic::AtomicBool::new(false));
    let primary_lifecycle_effects = Arc::new(std::sync::atomic::AtomicUsize::new(0));
    let routes = tonic::service::Routes::new(
        NativeLifecycleControl::new(leader.clone(), signer.clone(), auth.clone())
            .unwrap()
            .service(),
    )
    .add_service(NativeAuthority::new(issuer.clone(), auth.clone()).service())
    .into_axum_router()
    .layer(axum::middleware::from_fn({
        let first = first_lifecycle_response.clone();
        let completed = primary_handler_body_consumed.clone();
        let active = lifecycle_pool_active.clone();
        let effects = primary_lifecycle_effects.clone();
        move |request: axum::http::Request<axum::body::Body>, next: axum::middleware::Next| {
            let first = first.clone();
            let completed = completed.clone();
            let active = active.clone();
            let effects = effects.clone();
            async move {
                let execute = request.uri().path() == "/kasumi.v1.KasumiAuthority/ExecuteLifecycle";
                if execute && active.load(std::sync::atomic::Ordering::SeqCst) {
                    effects.fetch_add(1, std::sync::atomic::Ordering::SeqCst);
                }
                let reply = next.run(request).await;
                if execute && first.swap(false, std::sync::atomic::Ordering::SeqCst) {
                    // Consume the real unary response body before publishing
                    // completion. A returned service response alone can still
                    // contain a pending effect or response release in its body.
                    assert_eq!(reply.status(), axum::http::StatusCode::OK);
                    let body = axum::body::to_bytes(reply.into_body(), 1 << 20)
                        .await
                        .expect("real lifecycle handler body must complete");
                    assert!(body.len() > 5, "real lifecycle receipt frame missing");
                    completed.store(true, std::sync::atomic::Ordering::SeqCst);
                    // Lose only this response after the real handler and body
                    // completed. The caller must read its exact receipt.
                    return axum::http::Response::builder()
                        .status(200)
                        .header("content-type", "application/grpc")
                        .header("grpc-status", "14")
                        .body(axum::body::Body::empty())
                        .unwrap();
                }
                reply
            }
        }
    }));
    let (stop, stopped) = tokio::sync::watch::channel(false);
    let serving = tokio::spawn(crate::tls::serve_tls(
        socket,
        tls,
        routes,
        crate::tls::ListenerLimits::default(),
        Arc::new(FixtureListenerAudit),
        stopped,
    ));
    let config = KasumiClientConfig {
        endpoint,
        identity: identities.remove(0),
        trusted_ca_pem: ca.as_bytes().to_vec(),
        server_certificate_pins: BTreeSet::from([pin]),
    };
    let mut client =
        KasumiLifecycleClient::connect(&config, ControlTrust::install(root.clone()).unwrap())
            .await
            .unwrap();
    let encoding =
        jsonwebtoken::EncodingKey::from_ed_pem(jwtkey.serialize_pem().as_bytes()).unwrap();
    let token_for = |principal: &str, resource: serde_json::Value, scope: &str| {
        let mut header = jsonwebtoken::Header::new(jsonwebtoken::Algorithm::EdDSA);
        header.kid = Some("control-auth".into());
        header.typ = Some("at+jwt".into());
        let now = kasumi_clock::EpochClock::system()
            .unwrap()
            .now_ms()
            .unwrap()
            / 1000;
        jsonwebtoken::encode(&header,&json!({"sub":principal,"tenant":"__kasumi_control","kasumi_resource":resource,"scope":scope,"iss":"https://identity.example","aud":"https://control.example","exp":now+300}),&encoding).unwrap()
    };
    let token = |resource, scope| token_for("operator", resource, scope);
    let routing = token_for(
        "router",
        json!({"kind":"control","incarnation":incarnation}),
        "kasumi:read",
    );
    let admin = token(
        json!({"kind":"control","incarnation":incarnation}),
        "kasumi:admin",
    );
    let data = token(
        json!({"kind":"database","incarnation":incarnation}),
        "kasumi:admin",
    );
    let readonly = token(
        json!({"kind":"control","incarnation":incarnation}),
        "kasumi:read",
    );
    let install = LifecycleControlCommand::Install {
        command_id: installation_command_id,
        installation: installation.clone(),
    };
    assert!(client.execute(&data, &install).await.is_err());
    assert!(client.execute(&readonly, &install).await.is_err());
    client.execute(&admin, &install).await.unwrap();
    // Real mTLS and signed Control quorum reads. The native client binds the
    // request, principal, exact bearer and its actual client certificate.
    {
        assert!(client.execute(&routing, &install).await.is_err());
        assert!(
            client
                .observe_topology(&data, "operator", 5000)
                .await
                .is_err()
        );
        assert!(
            client
                .observe_topology(&admin, "operator", 5000)
                .await
                .is_err()
        );
        assert!(
            client
                .observe_topology(&routing, "another", 5000)
                .await
                .is_err()
        );
        let current = client
            .observe_topology(&routing, "router", 5000)
            .await
            .unwrap();
        let observation = current.observation().unwrap();
        assert_eq!(observation.root, root);
        assert_eq!(
            observation.caller.certificate_sha256,
            hex::encode(config.identity.certificate_pin())
        );
        assert_eq!(
            observation.topology.topology,
            match &bootstrap.genesis {
                kasumi_engine::ReplicatedGenesis::Control(control) => control.topology.clone(),
                _ => unreachable!(),
            }
        );
        assert!(client.release_topology(&readonly, &current).await.is_err());
        let released = client.release_topology(&routing, &current).await.unwrap();
        assert_eq!(
            released.observation().unwrap(),
            current.observation().unwrap()
        );
        assert_eq!(
            released.release().unwrap().not_after_ms,
            current.observation().unwrap().not_after_ms
        );
        let mut alternate = config.clone();
        alternate.identity = identities.remove(0);
        let mut alternate_client = KasumiLifecycleClient::connect(
            &alternate,
            ControlTrust::install(root.clone()).unwrap(),
        )
        .await
        .unwrap();
        assert!(
            alternate_client
                .release_topology(&routing, &current)
                .await
                .is_err()
        );
        // Exercise server-side caller binding using the actual signed wire,
        // independently of the native client's local admission checks.
        let raw_channel = |config: KasumiClientConfig| async move {
            kasumi_transport::grpc_channel(
                &config.endpoint,
                &config.identity,
                &config.trusted_ca_pem,
                config.server_certificate_pins,
            )
            .await
            .unwrap()
        };
        let mut raw = proto::kasumi_lifecycle_control_client::KasumiLifecycleControlClient::new(
            raw_channel(config.clone()).await,
        );
        let wire = |bytes: Vec<u8>, bearer: &str| {
            let mut request = Request::new(ControlJsonRequest {
                request_json: bytes,
            });
            request
                .metadata_mut()
                .insert("authorization", format!("Bearer {bearer}").parse().unwrap());
            request
        };
        let read = ReadControlTopology {
            request_id: Uuid::new_v4(),
            control_incarnation: incarnation,
            maximum_lifetime_ms: 5000,
        };
        let bytes = serde_json::to_vec(&read).unwrap();
        let signed: SignedControlTopology = serde_json::from_slice(
            &raw.observe_topology(wire(bytes.clone(), &routing))
                .await
                .unwrap()
                .into_inner()
                .response_json,
        )
        .unwrap();
        let release = ReleaseControlTopology {
            request_id: Uuid::new_v4(),
            original: signed,
        };
        let release_bytes = serde_json::to_vec(&release).unwrap();
        let mut alternate_raw =
            proto::kasumi_lifecycle_control_client::KasumiLifecycleControlClient::new(
                raw_channel(alternate).await,
            );
        assert_eq!(
            alternate_raw
                .release_topology(wire(release_bytes.clone(), &routing))
                .await
                .unwrap_err()
                .code(),
            tonic::Code::PermissionDenied
        );
        assert_eq!(
            raw.release_topology(wire(release_bytes, &readonly))
                .await
                .unwrap_err()
                .code(),
            tonic::Code::PermissionDenied
        );
        let mut duplicate = wire(bytes.clone(), &routing);
        duplicate.metadata_mut().append(
            "authorization",
            format!("Bearer {routing}").parse().unwrap(),
        );
        assert_eq!(
            raw.observe_topology(duplicate).await.unwrap_err().code(),
            tonic::Code::Unauthenticated
        );
        let handler =
            NativeLifecycleControl::new(leader.clone(), signer.clone(), auth.clone()).unwrap();
        assert_eq!(
            proto::kasumi_lifecycle_control_server::KasumiLifecycleControl::observe_topology(
                &handler,
                wire(bytes, &routing)
            )
            .await
            .unwrap_err()
            .code(),
            tonic::Code::Unauthenticated
        );
    }
    let epoch = leader.engine().generation().unwrap().state.policy_epoch;
    let source = Uuid::new_v4();
    // Shape-only approved checkpoint fixture: this tests the committed native
    // control signature boundary, not physical backup materialization.
    let intent = CommitLifecycleIntent {
        command_id: Uuid::new_v4(),
        expected_policy_epoch: epoch,
        installation_sha256: digest(&installation).unwrap(),
        authority_partition: partition.key(),
        tenant: "city".into(),
        source_incarnation: source,
        source_authority_epoch: 1,
        target_incarnation: Uuid::new_v4(),
        checkpoint: FullBackupCheckpoint {
            tenant: "city".into(),
            source_incarnation: source.to_string(),
            revision: 123,
            resident_sha256: "12".repeat(32),
            backup_id: Uuid::new_v4(),
            manifest_ciphertext_sha256: "34".repeat(32),
            key_lineage_digest: "56".repeat(32),
        },
        target_nodes: (1..=3)
            .map(|id| {
                (
                    id,
                    LifecycleNode {
                        node_id: id,
                        verifier: kasumi_serving::test_utils::fixture_verifier(id),
                        principal: format!("target-{id}"),
                        attestation_public_key: format!("{:064x}", id + 100),
                        certificate_sha256: if id == 1 {
                            hex::encode(config.identity.certificate_pin())
                        } else {
                            format!("{id:064x}")
                        },
                    },
                )
            })
            .collect(),
        phase: LifecyclePhase::Materialize,
        phase_input_sha256: "ab".repeat(32),
        resume_origin: None,
    };
    let receipt = client
        .execute(
            &admin,
            &LifecycleControlCommand::CommitIntent(Box::new(intent.clone())),
        )
        .await
        .unwrap();
    let proof = client
        .observe_intent(&admin, intent.command_id)
        .await
        .unwrap();
    assert_eq!(proof.observation().intent.revision, receipt.revision);
    assert_eq!(proof.observation().intent.request, intent);
    assert!(serde_json::to_vec(proof.signed()).unwrap().len() < 4096);
    assert!(
        client
            .observe_intent(&data, intent.command_id)
            .await
            .is_err()
    );
    assert!(
        client
            .observe_intent(&readonly, intent.command_id)
            .await
            .is_err()
    );
    let request = ReadLifecycleStatus {
        command_id: intent.command_id,
        expected_incarnation: incarnation,
    };
    client.read_status(&admin, &request).await.unwrap();
    assert!(client.read_status(&data, &request).await.is_err());
    let issuer_token = |principal: &str, scope: &str| {
        let mut h = jsonwebtoken::Header::new(jsonwebtoken::Algorithm::EdDSA);
        h.kid = Some("control-auth".into());
        h.typ = Some("at+jwt".into());
        let now = kasumi_clock::EpochClock::system()
            .unwrap()
            .now_ms()
            .unwrap()
            / 1000;
        jsonwebtoken::encode(&h,&json!({"sub":principal,"tenant":issuer_install.tenant(),"kasumi_resource":{"kind":"authority","authority_id":manifest.authority_id,"partition":0},"scope":scope,"iss":"https://identity.example","aud":"https://control.example","exp":now+300}),&encoding).unwrap()
    };
    let authority_admin = issuer_token("operator", "kasumi:admin");
    let node_token = issuer_token("target-1", "kasumi:read");
    let mut authority_client =
        kasumi_client::KasumiAuthorityClient::connect(&config, issuer_trust.clone())
            .await
            .unwrap();
    let target = kasumi_serving::RecoveryTarget {
        incarnation: intent.target_incarnation,
        checkpoint: intent.checkpoint.clone(),
        nodes: intent
            .target_nodes
            .values()
            .map(|n| kasumi_serving::NodeIdentity {
                node_id: n.node_id,
                verifier: n.verifier.clone(),
                principal: n.principal.clone(),
                certificate_sha256: n.certificate_sha256.clone(),
            })
            .collect(),
    };
    let authority_command = |action| kasumi_serving::AuthorityCommand {
        tenant: "city".into(),
        command_id: Uuid::new_v4(),
        expected_policy_epoch: 1,
        not_after_ms: kasumi_clock::EpochClock::system()
            .unwrap()
            .now_ms()
            .unwrap()
            + 60000,
        action,
    };
    let native_action = authority_client
        .execute(
            &authority_admin,
            &authority_command(kasumi_serving::AuthorityAction::Enroll {
                incarnation: source,
                nodes: target.nodes.clone(),
            }),
        )
        .await
        .unwrap();
    assert!(
        !matches!(
            native_action.receipt.outcome,
            kasumi_serving::AuthorityOutcome::Rejected { .. }
        ),
        "{:?}",
        native_action.receipt.outcome
    );
    let native_action = authority_client
        .execute(
            &authority_admin,
            &authority_command(kasumi_serving::AuthorityAction::PrepareTarget {
                source_incarnation: source,
                source_epoch: 1,
                target: target.clone(),
            }),
        )
        .await
        .unwrap();
    assert!(
        !matches!(
            native_action.receipt.outcome,
            kasumi_serving::AuthorityOutcome::Rejected { .. }
        ),
        "{:?}",
        native_action.receipt.outcome
    );
    let accept =
        kasumi_serving::LifecycleAuthorityRequest::AcceptIntent(Box::new(proof.signed().clone()));
    assert!(
        authority_client
            .execute_lifecycle(&admin, &accept)
            .await
            .is_err()
    );
    // A second installed route deliberately returns one stale but well-formed
    // absent receipt. It counts any lifecycle effect that reaches the route.
    let shadow_socket = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
    let mut shadow_config = config.clone();
    shadow_config.endpoint = format!(
        "https://localhost:{}",
        shadow_socket.local_addr().unwrap().port()
    );
    let shadow_tls = kasumi_transport::server_config(
        &server_identity,
        ClientAuthentication::Required {
            trusted_ca_pem: ca.as_bytes(),
        },
    )
    .unwrap();
    let shadow_probe_response = Arc::new(std::sync::atomic::AtomicBool::new(true));
    let shadow_absence = Arc::new(std::sync::atomic::AtomicBool::new(false));
    let shadow_reads = Arc::new(std::sync::atomic::AtomicUsize::new(0));
    let shadow_effects = Arc::new(std::sync::atomic::AtomicUsize::new(0));
    let shadow_routes =
        tonic::service::Routes::new(NativeAuthority::new(issuer.clone(), auth.clone()).service())
            .into_axum_router()
            .layer(axum::middleware::from_fn({
                let probe = shadow_probe_response.clone();
                let stale = shadow_absence.clone();
                let completed = primary_handler_body_consumed.clone();
                let reads = shadow_reads.clone();
                let effects = shadow_effects.clone();
                move |request: axum::http::Request<axum::body::Body>,
                      next: axum::middleware::Next| {
                    let probe = probe.clone();
                    let stale = stale.clone();
                    let completed = completed.clone();
                    let reads = reads.clone();
                    let effects = effects.clone();
                    async move {
                        let path = request.uri().path();
                        let is_receipt = path == "/kasumi.v1.KasumiAuthority/ReadLifecycleReceipt";
                        let probe_read =
                            is_receipt && probe.swap(false, std::sync::atomic::Ordering::SeqCst);
                        let stale_read = is_receipt
                            && !probe_read
                            && stale.swap(false, std::sync::atomic::Ordering::SeqCst);
                        if probe_read || stale_read {
                            if stale_read {
                                assert!(
                                    completed.load(std::sync::atomic::Ordering::SeqCst),
                                    "shadow absence must follow consumed primary handler body"
                                );
                            }
                            reads.fetch_add(1, std::sync::atomic::Ordering::SeqCst);
                            let payload = kasumi_client::proto::AuthorityJsonResponse {
                                response_json: b"null".to_vec(),
                            };
                            let encoded = prost::Message::encode_to_vec(&payload);
                            let mut framed = vec![0u8];
                            framed.extend_from_slice(&(encoded.len() as u32).to_be_bytes());
                            framed.extend_from_slice(&encoded);
                            return axum::http::Response::builder()
                                .status(200)
                                .header("content-type", "application/grpc")
                                .header("grpc-status", "0")
                                .body(axum::body::Body::from(framed))
                                .unwrap();
                        }
                        if path == "/kasumi.v1.KasumiAuthority/ExecuteLifecycle" {
                            effects.fetch_add(1, std::sync::atomic::Ordering::SeqCst);
                        }
                        next.run(request).await
                    }
                }
            }));
    let (shadow_stop, shadow_stopped) = tokio::sync::watch::channel(false);
    let shadow_task = tokio::spawn(crate::tls::serve_tls(
        shadow_socket,
        shadow_tls,
        shadow_routes,
        crate::tls::ListenerLimits::default(),
        Arc::new(FixtureListenerAudit),
        shadow_stopped,
    ));
    // Prove the injected frame decodes as an absent exact receipt.
    let mut shadow_probe =
        kasumi_client::KasumiAuthorityClient::connect(&shadow_config, issuer_trust.clone())
            .await
            .unwrap();
    assert!(
        shadow_probe
            .read_lifecycle_receipt(&authority_admin, &accept.reference())
            .await
            .unwrap()
            .is_none()
    );
    shadow_reads.store(0, std::sync::atomic::Ordering::SeqCst);
    shadow_absence.store(true, std::sync::atomic::Ordering::SeqCst);
    drop(shadow_probe);
    let credential = authority_admin.clone();
    let mut effect_pool = kasumi_client::KasumiAuthorityPool::new(
        BTreeMap::from([(1, config.clone()), (2, shadow_config)]),
        issuer_trust.clone(),
        Arc::new(move || Ok(zeroize::Zeroizing::new(credential.clone()))),
    )
    .unwrap();
    primary_handler_body_consumed.store(false, std::sync::atomic::Ordering::SeqCst);
    lifecycle_pool_active.store(true, std::sync::atomic::Ordering::SeqCst);
    first_lifecycle_response.store(true, std::sync::atomic::Ordering::SeqCst);
    let outcome = effect_pool
        .execute_lifecycle(&accept, Duration::from_secs(30))
        .await;
    lifecycle_pool_active.store(false, std::sync::atomic::Ordering::SeqCst);
    assert!(
        primary_handler_body_consumed.load(std::sync::atomic::Ordering::SeqCst),
        "the original issuer effect must finish before reconciliation"
    );
    match outcome {
        Ok(receipt) => assert_eq!(receipt.receipt.request_sha256, accept.digest().unwrap()),
        Err(kasumi_client::ClientError::Transport(status)) => {
            assert_eq!(status.code(), tonic::Code::Unavailable);
            let detail: kasumi_types::Error = serde_json::from_slice(status.details()).unwrap();
            assert_eq!(detail.code, kasumi_types::ErrorCode::UnknownOutcome);
        }
        Err(other) => panic!("ambiguous lifecycle effect returned a definite error: {other}"),
    }
    let accepted = authority_client
        .read_lifecycle_receipt(&authority_admin, &accept.reference())
        .await
        .unwrap()
        .unwrap();
    assert_eq!(accepted.receipt.request_sha256, accept.digest().unwrap());
    assert_eq!(
        primary_lifecycle_effects.load(std::sync::atomic::Ordering::SeqCst),
        1
    );
    assert_eq!(shadow_reads.load(std::sync::atomic::Ordering::SeqCst), 1);
    assert_eq!(
        shadow_effects.load(std::sync::atomic::Ordering::SeqCst),
        0,
        "an absent lifecycle receipt after ambiguity cannot authorize another ExecuteLifecycle"
    );
    drop(effect_pool);
    shadow_stop.send_replace(true);
    shadow_task.await.unwrap().unwrap();
    let boot = kasumi_serving::LifecycleBoot::new(
        issuer_trust.clone(),
        target
            .nodes
            .iter()
            .find(|n| n.node_id == 1)
            .unwrap()
            .clone(),
    )
    .unwrap();
    let attempt = boot.begin(&proof).unwrap();
    let lease = authority_client
        .acquire_lifecycle(&node_token, &attempt)
        .await
        .unwrap();
    lease.check().unwrap();
    assert!(
        authority_client
            .acquire_lifecycle(&authority_admin, &attempt)
            .await
            .is_err()
    );
    super::recovery_tests::exercise(super::recovery_tests::Fixture {
        directory: directory.path(),
        control: leader.clone(),
        signer,
        auth: auth.clone(),
        audit: audit.clone(),
        issuer: issuer.clone(),
        trust: issuer_trust.clone(),
        installation: installation.clone(),
        template: intent.clone(),
        control_admin: &admin,
        wrong_resource: &data,
        readonly: &readonly,
        issuer_admin: &authority_admin,
    })
    .await;
    let change = BeginControlPolicyChange {
        command_id: Uuid::new_v4(),
        expected_policy_epoch: epoch,
        installation_sha256: digest(&installation).unwrap(),
        candidate: ControlPolicyCandidate {
            policy,
            retire_control: false,
        },
    };
    client
        .execute(
            &admin,
            &LifecycleControlCommand::BeginPolicyChange(change.clone()),
        )
        .await
        .unwrap();
    assert!(
        client
            .observe_intent(&admin, intent.command_id)
            .await
            .is_err()
    );
    let change_proof = client
        .observe_change(&admin, change.command_id, &partition.key())
        .await
        .unwrap();
    assert_eq!(
        change_proof.observation().stop.change_sha256,
        digest(&change).unwrap()
    );
    assert!(
        client
            .observe_change(&admin, change.command_id, "outside/pinned-set")
            .await
            .is_err()
    );
    assert!(
        client
            .execute(
                &admin,
                &LifecycleControlCommand::CompletePolicyChange(CompleteControlPolicyChange {
                    command_id: change.command_id,
                    change_sha256: digest(&change).unwrap(),
                    stops: BTreeMap::new()
                })
            )
            .await
            .is_err()
    );
    let status = client
        .read_status(
            &admin,
            &ReadLifecycleStatus {
                command_id: change.command_id,
                expected_incarnation: incarnation,
            },
        )
        .await
        .unwrap();
    assert!(
        matches!(status.command,Some(LifecycleCommandStatus::PolicyChange(c)) if c.completed_revision.is_none())
    );
    let stop_request = kasumi_serving::LifecycleAuthorityRequest::StopEpoch(Box::new(
        change_proof.signed().clone(),
    ));
    authority_client
        .execute_lifecycle(&authority_admin, &stop_request)
        .await
        .unwrap();
    assert!(
        authority_client
            .acquire_lifecycle(&node_token, &boot.begin(&proof).unwrap())
            .await
            .is_err()
    );
    assert!(
        authority_client
            .verify_control_stop(&authority_admin, &change_proof.observation().stop)
            .await
            .is_err()
    );
    tokio::time::sleep(Duration::from_millis(5100)).await;
    assert!(lease.check().is_err());
    let stopped_proof = authority_client
        .verify_control_stop(&authority_admin, &change_proof.observation().stop)
        .await
        .unwrap();
    client
        .execute(
            &admin,
            &LifecycleControlCommand::CompletePolicyChange(CompleteControlPolicyChange {
                command_id: change.command_id,
                change_sha256: digest(&change).unwrap(),
                stops: BTreeMap::from([(partition.key(), stopped_proof)]),
            }),
        )
        .await
        .unwrap();
    assert!(
        client
            .observe_intent(&admin, intent.command_id)
            .await
            .is_err()
    );
    let recovered = authority_client
        .read_lifecycle_receipt(&authority_admin, &accept.reference())
        .await
        .unwrap()
        .unwrap();
    assert_eq!(
        recovered.receipt.accepted_revision,
        accepted.receipt.accepted_revision
    );
    super::control_signer_tests::exercise(super::control_signer_tests::Fixture {
        directory: directory.path(),
        control: leader.clone(),
        issuer: issuer.clone(),
        auth: auth.clone(),
        audit: audit.clone(),
        installation: installation.clone(),
        manifest: manifest.clone(),
        initial_certificate: issuer_signing.signer.certificate().clone(),
        root: kasumi_serving::InstallationSigningRoot::from_pkcs8(
            manifest.signing_domain(0).unwrap(),
            &issuer_key.serialize_der(),
        )
        .unwrap(),
        issuer_admin: &authority_admin,
        receiver_tokens: (1..=3)
            .map(|id| (id, issuer_token(&format!("control-{id}"), "kasumi:read")))
            .collect(),
        control_admin: &admin,
        wrong_resource: &data,
        readonly: &readonly,
    })
    .await;
    drop(authority_client);
    for issuer in &issuers {
        issuer.shutdown().await.unwrap();
    }
    stop.send(true).unwrap();
    serving.await.unwrap().unwrap();
    drop(client);
    drop(leader);
    for node in &nodes {
        node.shutdown().await.unwrap();
    }
    nodes.clear();
    audit.shutdown().await.unwrap();
    audit_store.shutdown().await.unwrap();
    for node in physical_nodes {
        node.shutdown().await.unwrap();
    }
}
